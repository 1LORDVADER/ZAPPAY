const User = require('../models/User');
const FarmerProfile = require('../models/FarmerProfile');
const DispensaryProfile = require('../models/DispensaryProfile');
const Order = require('../models/Order');
const Payment = require('../models/Payment');
const Compliance = require('../models/Compliance');
const db = require('../config/database');

// Admin controller
const AdminController = {
  // Get all users
  async getAllUsers(req, res) {
    try {
      const query = `
        SELECT u.id, u.email, u.role, u.first_name, u.last_name, u.phone, 
               u.date_of_birth, u.is_age_verified, u.is_active, u.created_at
        FROM users u
        ORDER BY u.created_at DESC
      `;
      
      const result = await db.query(query);
      const users = result.rows;
      
      res.status(200).json({ users });
    } catch (error) {
      console.error('Get all users error:', error);
      res.status(500).json({ message: 'Error getting users', error: error.message });
    }
  },
  
  // Get user by ID
  async getUserById(req, res) {
    try {
      const userId = req.params.id;
      
      // Get user data
      const user = await User.findById(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Get role-specific profile
      let profile = null;
      if (user.role === 'farmer') {
        profile = await FarmerProfile.findByUserId(userId);
      } else if (user.role === 'dispensary') {
        profile = await DispensaryProfile.findByUserId(userId);
      } else if (user.role === 'consumer') {
        profile = await ConsumerProfile.findByUserId(userId);
      }
      
      res.status(200).json({ user, profile });
    } catch (error) {
      console.error('Get user by ID error:', error);
      res.status(500).json({ message: 'Error getting user', error: error.message });
    }
  },
  
  // Update user status (activate/deactivate)
  async updateUserStatus(req, res) {
    try {
      const userId = req.params.id;
      const { is_active } = req.body;
      
      // Update user
      const user = await User.update(userId, { is_active });
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      res.status(200).json({
        message: `User ${is_active ? 'activated' : 'deactivated'} successfully`,
        user
      });
    } catch (error) {
      console.error('Update user status error:', error);
      res.status(500).json({ message: 'Error updating user status', error: error.message });
    }
  },
  
  // Get farmer verifications
  async getFarmerVerifications(req, res) {
    try {
      const farmers = await FarmerProfile.getPendingVerification();
      
      res.status(200).json({ farmers });
    } catch (error) {
      console.error('Get farmer verifications error:', error);
      res.status(500).json({ message: 'Error getting farmer verifications', error: error.message });
    }
  },
  
  // Get dispensary verifications
  async getDispensaryVerifications(req, res) {
    try {
      const dispensaries = await DispensaryProfile.getPendingVerification();
      
      res.status(200).json({ dispensaries });
    } catch (error) {
      console.error('Get dispensary verifications error:', error);
      res.status(500).json({ message: 'Error getting dispensary verifications', error: error.message });
    }
  },
  
  // Update farmer verification
  async updateFarmerVerification(req, res) {
    try {
      const farmerId = req.params.id;
      const { is_verified } = req.body;
      
      const farmer = await FarmerProfile.updateVerificationStatus(farmerId, is_verified);
      if (!farmer) {
        return res.status(404).json({ message: 'Farmer not found' });
      }
      
      // Log the verification action
      await Compliance.createAuditLog({
        user_id: req.user.id,
        action: is_verified ? 'farmer_verified' : 'farmer_verification_rejected',
        entity_type: 'farmer',
        entity_id: farmerId,
        details: { is_verified },
        ip_address: req.ip,
        user_agent: req.headers['user-agent']
      });
      
      res.status(200).json({
        message: `Farmer ${is_verified ? 'verified' : 'verification rejected'} successfully`,
        farmer
      });
    } catch (error) {
      console.error('Update farmer verification error:', error);
      res.status(500).json({ message: 'Error updating farmer verification', error: error.message });
    }
  },
  
  // Update dispensary verification
  async updateDispensaryVerification(req, res) {
    try {
      const dispensaryId = req.params.id;
      const { is_verified } = req.body;
      
      const dispensary = await DispensaryProfile.updateVerificationStatus(dispensaryId, is_verified);
      if (!dispensary) {
        return res.status(404).json({ message: 'Dispensary not found' });
      }
      
      // Log the verification action
      await Compliance.createAuditLog({
        user_id: req.user.id,
        action: is_verified ? 'dispensary_verified' : 'dispensary_verification_rejected',
        entity_type: 'dispensary',
        entity_id: dispensaryId,
        details: { is_verified },
        ip_address: req.ip,
        user_agent: req.headers['user-agent']
      });
      
      res.status(200).json({
        message: `Dispensary ${is_verified ? 'verified' : 'verification rejected'} successfully`,
        dispensary
      });
    } catch (error) {
      console.error('Update dispensary verification error:', error);
      res.status(500).json({ message: 'Error updating dispensary verification', error: error.message });
    }
  },
  
  // Get expiring licenses
  async getExpiringLicenses(req, res) {
    try {
      const farmerLicenses = await FarmerProfile.getExpiringLicenses();
      const dispensaryLicenses = await DispensaryProfile.getExpiringLicenses();
      
      res.status(200).json({
        farmers: farmerLicenses,
        dispensaries: dispensaryLicenses
      });
    } catch (error) {
      console.error('Get expiring licenses error:', error);
      res.status(500).json({ message: 'Error getting expiring licenses', error: error.message });
    }
  },
  
  // Get transactions
  async getTransactions(req, res) {
    try {
      const { start_date, end_date, status } = req.query;
      
      let query = `
        SELECT o.*, 
               cp.user_id as consumer_user_id, 
               dp.business_name as dispensary_name,
               p.status as payment_status,
               p.payment_method
        FROM orders o
        LEFT JOIN consumer_profiles cp ON o.consumer_id = cp.id
        LEFT JOIN dispensary_profiles dp ON o.dispensary_id = dp.id
        LEFT JOIN payments p ON o.id = p.order_id
        WHERE 1=1
      `;
      
      const queryParams = [];
      let paramIndex = 1;
      
      if (start_date) {
        query += ` AND o.created_at >= $${paramIndex}`;
        queryParams.push(new Date(start_date));
        paramIndex++;
      }
      
      if (end_date) {
        query += ` AND o.created_at <= $${paramIndex}`;
        queryParams.push(new Date(end_date));
        paramIndex++;
      }
      
      if (status) {
        query += ` AND o.status = $${paramIndex}`;
        queryParams.push(status);
        paramIndex++;
      }
      
      query += ` ORDER BY o.created_at DESC`;
      
      const result = await db.query(query, queryParams);
      const transactions = result.rows;
      
      res.status(200).json({ transactions });
    } catch (error) {
      console.error('Get transactions error:', error);
      res.status(500).json({ message: 'Error getting transactions', error: error.message });
    }
  },
  
  // Get suspicious transactions
  async getSuspiciousTransactions(req, res) {
    try {
      // This is a placeholder for more sophisticated fraud detection
      // In a real implementation, this would include more complex logic
      const query = `
        SELECT o.*, 
               cp.user_id as consumer_user_id, 
               dp.business_name as dispensary_name,
               p.status as payment_status,
               p.payment_method
        FROM orders o
        LEFT JOIN consumer_profiles cp ON o.consumer_id = cp.id
        LEFT JOIN dispensary_profiles dp ON o.dispensary_id = dp.id
        LEFT JOIN payments p ON o.id = p.order_id
        WHERE o.total > 1000
        OR (p.status = 'failed' AND o.status != 'cancelled')
        ORDER BY o.created_at DESC
      `;
      
      const result = await db.query(query);
      const suspiciousTransactions = result.rows;
      
      res.status(200).json({ suspiciousTransactions });
    } catch (error) {
      console.error('Get suspicious transactions error:', error);
      res.status(500).json({ message: 'Error getting suspicious transactions', error: error.message });
    }
  },
  
  // Get dashboard stats
  async getDashboardStats(req, res) {
    try {
      // Get user counts
      const userCountsQuery = `
        SELECT role, COUNT(*) as count
        FROM users
        WHERE is_active = true
        GROUP BY role
      `;
      
      const userCountsResult = await db.query(userCountsQuery);
      const userCounts = userCountsResult.rows;
      
      // Get order stats
      const orderStatsQuery = `
        SELECT 
          COUNT(*) as total_orders,
          SUM(subtotal) as total_sales,
          SUM(commission) as total_commission,
          AVG(total) as average_order_value
        FROM orders
        WHERE status != 'cancelled'
        AND created_at >= NOW() - INTERVAL '30 days'
      `;
      
      const orderStatsResult = await db.query(orderStatsQuery);
      const orderStats = orderStatsResult.rows[0];
      
      // Get verification stats
      const verificationStatsQuery = `
        SELECT 
          (SELECT COUNT(*) FROM farmer_profiles WHERE is_verified = false) as pending_farmer_verifications,
          (SELECT COUNT(*) FROM dispensary_profiles WHERE is_verified = false) as pending_dispensary_verifications
      `;
      
      const verificationStatsResult = await db.query(verificationStatsQuery);
      const verificationStats = verificationStatsResult.rows[0];
      
      res.status(200).json({
        userCounts,
        orderStats,
        verificationStats
      });
    } catch (error) {
      console.error('Get dashboard stats error:', error);
      res.status(500).json({ message: 'Error getting dashboard stats', error: error.message });
    }
  },
  
  // Get revenue stats
  async getRevenueStats(req, res) {
    try {
      const { period } = req.query;
      let interval;
      let groupBy;
      
      // Determine interval and grouping based on period
      if (period === 'daily') {
        interval = '30 days';
        groupBy = 'DATE(created_at)';
      } else if (period === 'weekly') {
        interval = '12 weeks';
        groupBy = 'DATE_TRUNC(\'week\', created_at)';
      } else if (period === 'monthly') {
        interval = '12 months';
        groupBy = 'DATE_TRUNC(\'month\', created_at)';
      } else {
        // Default to daily for last 30 days
        interval = '30 days';
        groupBy = 'DATE(created_at)';
      }
      
      const query = `
        SELECT 
          ${groupBy} as period,
          SUM(subtotal) as sales,
          SUM(commission) as commission,
          COUNT(*) as order_count
        FROM orders
        WHERE status != 'cancelled'
        AND created_at >= NOW() - INTERVAL '${interval}'
        GROUP BY ${groupBy}
        ORDER BY ${groupBy}
      `;
      
      const result = await db.query(query);
      const revenueStats = result.rows;
      
      res.status(200).json({ revenueStats });
    } catch (error) {
      console.error('Get revenue stats error:', error);
      res.status(500).json({ message: 'Error getting revenue stats', error: error.message });
    }
  },
  
  // Get user stats
  async getUserStats(req, res) {
    try {
      // Get new user registrations over time
      const newUsersQuery = `
        SELECT 
          DATE_TRUNC('day', created_at) as day,
          COUNT(*) as count,
          role
        FROM users
        WHERE created_at >= NOW() - INTERVAL '30 days'
        GROUP BY day, role
        ORDER BY day
      `;
      
      const newUsersResult = await db.query(newUsersQuery);
      const newUsers = newUsersResult.rows;
      
      // Get active users (users who have placed orders)
      const activeUsersQuery = `
        SELECT 
          COUNT(DISTINCT cp.user_id) as active_consumers
        FROM orders o
        JOIN consumer_profiles cp ON o.consumer_id = cp.id
        WHERE o.created_at >= NOW() - INTERVAL '30 days'
      `;
      
      const activeUsersResult = await db.query(activeUsersQuery);
      const activeUsers = activeUsersResult.rows[0];
      
      res.status(200).json({
        newUsers,
        activeUsers
      });
    } catch (error) {
      console.error('Get user stats error:', error);
      res.status(500).json({ message: 'Error getting user stats', error: error.message });
    }
  },
  
  // Get system health
  async getSystemHealth(req, res) {
    try {
      // Check database connection
      const dbQuery = 'SELECT 1 as db_status';
      await db.query(dbQuery);
      
      // Get failed Metrc syncs
      const failedSyncs = await Compliance.getFailedMetrcSyncs('24 hours');
      
      // Get pending verifications
      const pendingVerificationsQuery = `
        SELECT 
          (SELECT COUNT(*) FROM farmer_profiles WHERE is_verified = false) as pending_farmer_verifications,
          (SELECT COUNT(*) FROM dispensary_profiles WHERE is_verified = false) as pending_dispensary_verifications
      `;
      
      const pendingVerificationsResult = await db.query(pendingVerificationsQuery);
      const pendingVerifications = pendingVerificationsResult.rows[0];
      
      res.status(200).json({
        status: 'healthy',
        database: 'connected',
        failedMetrcSyncs: failedSyncs.length,
        pendingVerifications
      });
    } catch (error) {
      console.error('Get system health error:', error);
      res.status(500).json({
        status: 'unhealthy',
        error: error.message
      });
    }
  },
  
  // Update system settings
  async updateSystemSettings(req, res) {
    try {
      // This is a placeholder for system settings
      // In a real implementation, this would update configuration in the database
      const { settings } = req.body;
      
      // Log the settings update
      await Compliance.createAuditLog({
        user_id: req.user.id,
        action: 'update_system_settings',
        entity_type: 'system',
        entity_id: null,
        details: settings,
        ip_address: req.ip,
        user_agent: req.headers['user-agent']
      });
      
      res.status(200).json({
        message: 'System settings updated successfully',
        settings
      });
    } catch (error) {
      console.error('Update system settings error:', error);
      res.status(500).json({ message: 'Error updating system settings', error: error.message });
    }
  }
};

module.exports = AdminController;
