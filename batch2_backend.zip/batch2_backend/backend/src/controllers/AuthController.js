const jwt = require('jsonwebtoken');
const User = require('../models/User');
const FarmerProfile = require('../models/FarmerProfile');
const DispensaryProfile = require('../models/DispensaryProfile');
const ConsumerProfile = require('../models/ConsumerProfile');
const config = require('../config/config');

// Authentication controller
const AuthController = {
  // Register a new user
  async register(req, res) {
    try {
      const { email, password, role, first_name, last_name, phone, date_of_birth } = req.body;
      
      // Check if user already exists
      const existingUser = await User.findByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: 'User already exists with this email' });
      }
      
      // Create user
      const user = await User.create({
        email,
        password,
        role,
        first_name,
        last_name,
        phone,
        date_of_birth
      });
      
      // Create corresponding profile based on role
      if (role === 'farmer') {
        await FarmerProfile.create({
          user_id: user.id,
          business_name: req.body.business_name || '',
          license_number: req.body.license_number || '',
          license_type: req.body.license_type || '',
          license_expiration: req.body.license_expiration || null,
          business_address: req.body.business_address || '',
          city: req.body.city || '',
          state: req.body.state || '',
          zip_code: req.body.zip_code || '',
          verification_documents: req.body.verification_documents || null,
          metrc_api_key: req.body.metrc_api_key || null
        });
      } else if (role === 'dispensary') {
        await DispensaryProfile.create({
          user_id: user.id,
          business_name: req.body.business_name || '',
          license_number: req.body.license_number || '',
          license_type: req.body.license_type || '',
          license_expiration: req.body.license_expiration || null,
          business_address: req.body.business_address || '',
          city: req.body.city || '',
          state: req.body.state || '',
          zip_code: req.body.zip_code || '',
          verification_documents: req.body.verification_documents || null,
          metrc_api_key: req.body.metrc_api_key || null,
          pos_system: req.body.pos_system || null,
          business_hours: req.body.business_hours || null,
          pickup_instructions: req.body.pickup_instructions || ''
        });
      } else if (role === 'consumer') {
        await ConsumerProfile.create({
          user_id: user.id,
          address: req.body.address || '',
          city: req.body.city || '',
          state: req.body.state || '',
          zip_code: req.body.zip_code || '',
          age_verification_method: null,
          age_verification_date: null,
          preferences: req.body.preferences || null
        });
      }
      
      // Generate token
      const token = jwt.sign(
        { id: user.id, email: user.email, role: user.role },
        config.jwt.secret,
        { expiresIn: config.jwt.expiresIn }
      );
      
      res.status(201).json({
        message: 'User registered successfully',
        token,
        user: {
          id: user.id,
          email: user.email,
          role: user.role,
          first_name: user.first_name,
          last_name: user.last_name
        }
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ message: 'Error registering user', error: error.message });
    }
  },
  
  // Login user
  async login(req, res) {
    try {
      const { email, password } = req.body;
      
      // Find user
      const user = await User.findByEmail(email);
      if (!user) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      // Check if user is active
      if (!user.is_active) {
        return res.status(401).json({ message: 'Account is inactive' });
      }
      
      // Verify password
      const isPasswordValid = await User.comparePassword(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      // Generate token
      const token = jwt.sign(
        { id: user.id, email: user.email, role: user.role },
        config.jwt.secret,
        { expiresIn: config.jwt.expiresIn }
      );
      
      res.status(200).json({
        message: 'Login successful',
        token,
        user: {
          id: user.id,
          email: user.email,
          role: user.role,
          first_name: user.first_name,
          last_name: user.last_name,
          is_age_verified: user.is_age_verified
        }
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Error logging in', error: error.message });
    }
  },
  
  // Get current user profile
  async getProfile(req, res) {
    try {
      const userId = req.user.id;
      
      // Get user data
      const user = await User.findById(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Get role-specific profile
      let profile = null;
      if (user.role === 'farmer') {
        profile = await FarmerProfile.findByUserId(userId);
      } else if (user.role === 'dispensary') {
        profile = await DispensaryProfile.findByUserId(userId);
      } else if (user.role === 'consumer') {
        profile = await ConsumerProfile.findByUserId(userId);
      }
      
      res.status(200).json({
        user: {
          id: user.id,
          email: user.email,
          role: user.role,
          first_name: user.first_name,
          last_name: user.last_name,
          phone: user.phone,
          date_of_birth: user.date_of_birth,
          is_age_verified: user.is_age_verified,
          is_active: user.is_active,
          created_at: user.created_at
        },
        profile
      });
    } catch (error) {
      console.error('Get profile error:', error);
      res.status(500).json({ message: 'Error getting profile', error: error.message });
    }
  },
  
  // Verify age
  async verifyAge(req, res) {
    try {
      const userId = req.user.id;
      const { verification_method, verification_date } = req.body;
      
      // Update user age verification status
      const user = await User.verifyAge(userId, true);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Update consumer profile with verification details
      if (req.user.role === 'consumer') {
        const consumerProfile = await ConsumerProfile.findByUserId(userId);
        if (consumerProfile) {
          await ConsumerProfile.updateAgeVerification(
            consumerProfile.id,
            verification_method,
            verification_date || new Date()
          );
        }
      }
      
      res.status(200).json({
        message: 'Age verification successful',
        is_age_verified: true
      });
    } catch (error) {
      console.error('Age verification error:', error);
      res.status(500).json({ message: 'Error verifying age', error: error.message });
    }
  },
  
  // Update password
  async updatePassword(req, res) {
    try {
      const userId = req.user.id;
      const { current_password, new_password } = req.body;
      
      // Get user
      const user = await User.findByEmail(req.user.email);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Verify current password
      const isPasswordValid = await User.comparePassword(current_password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({ message: 'Current password is incorrect' });
      }
      
      // Update password
      await User.updatePassword(userId, new_password);
      
      res.status(200).json({ message: 'Password updated successfully' });
    } catch (error) {
      console.error('Update password error:', error);
      res.status(500).json({ message: 'Error updating password', error: error.message });
    }
  }
};

module.exports = AuthController;
