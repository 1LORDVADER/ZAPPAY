const MetrcService = require('../../payment_processor/MetrcService');
const Order = require('../models/Order');
const User = require('../models/User');
const config = require('../config/config');

/**
 * Compliance Controller
 * Handles compliance-related API endpoints
 */
class ComplianceController {
  /**
   * Report sale to Metrc
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async reportSaleToMetrc(req, res) {
    try {
      const { order_id } = req.body;
      
      // Validate required fields
      if (!order_id) {
        return res.status(400).json({
          success: false,
          message: 'Order ID is required'
        });
      }
      
      // Get order details
      const order = await Order.getOrderById(order_id);
      
      if (!order) {
        return res.status(404).json({
          success: false,
          message: 'Order not found'
        });
      }
      
      // Only dispensaries and admins can report sales
      if (req.user.role !== 'admin' && req.user.role !== 'dispensary') {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to report sales'
        });
      }
      
      // For dispensaries, verify they are associated with the order
      if (req.user.role === 'dispensary' && order.dispensary_id !== req.user.profile_id) {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to report sales for this order'
        });
      }
      
      // Report sale to Metrc
      const result = await MetrcService.reportSale({
        order_id: order.id,
        items: order.items,
        total: order.total,
        user_id: order.user_id
      });
      
      // Update order with Metrc receipt ID
      await Order.updateOrderStatus(order_id, order.status, {
        metrc_receipt_id: result.metrc_receipt_id
      });
      
      // Return result
      res.status(200).json({
        success: true,
        metrc_receipt_id: result.metrc_receipt_id,
        message: result.message
      });
    } catch (error) {
      console.error('Metrc sale reporting error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to report sale to Metrc'
      });
    }
  }
  
  /**
   * Verify package in Metrc
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async verifyPackage(req, res) {
    try {
      const { packageId } = req.params;
      
      // Validate required fields
      if (!packageId) {
        return res.status(400).json({
          success: false,
          message: 'Package ID is required'
        });
      }
      
      // Only farmers, dispensaries, and admins can verify packages
      if (req.user.role !== 'admin' && req.user.role !== 'dispensary' && req.user.role !== 'farmer') {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to verify packages'
        });
      }
      
      // Verify package in Metrc
      const result = await MetrcService.verifyPackage(packageId);
      
      // Return result
      res.status(200).json({
        success: true,
        package: result
      });
    } catch (error) {
      console.error('Metrc package verification error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to verify package in Metrc'
      });
    }
  }
  
  /**
   * Get active inventory from Metrc
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async getActiveInventory(req, res) {
    try {
      // Only farmers, dispensaries, and admins can view inventory
      if (req.user.role !== 'admin' && req.user.role !== 'dispensary' && req.user.role !== 'farmer') {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to view inventory'
        });
      }
      
      // Extract filter parameters
      const { lastModifiedStart, lastModifiedEnd } = req.query;
      
      // Get active inventory from Metrc
      const inventory = await MetrcService.getActiveInventory({
        lastModifiedStart,
        lastModifiedEnd
      });
      
      // Return inventory
      res.status(200).json({
        success: true,
        inventory
      });
    } catch (error) {
      console.error('Metrc inventory error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to get inventory from Metrc'
      });
    }
  }
  
  /**
   * Sync inventory with Metrc
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async syncInventory(req, res) {
    try {
      // Only admins can sync inventory
      if (req.user.role !== 'admin') {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to sync inventory'
        });
      }
      
      // Sync inventory with Metrc
      const result = await MetrcService.syncInventory();
      
      // Return result
      res.status(200).json({
        success: true,
        sync_results: result
      });
    } catch (error) {
      console.error('Metrc inventory sync error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to sync inventory with Metrc'
      });
    }
  }
  
  /**
   * Verify age and identity
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async verifyAgeAndIdentity(req, res) {
    try {
      const { date_of_birth, id_type, id_number } = req.body;
      
      // Validate required fields
      if (!date_of_birth || !id_type || !id_number) {
        return res.status(400).json({
          success: false,
          message: 'Date of birth, ID type, and ID number are required'
        });
      }
      
      // Verify age and identity
      const result = await MetrcService.verifyAgeAndIdentity({
        user_id: req.user.id,
        date_of_birth,
        id_type,
        id_number
      });
      
      // Return result
      res.status(200).json({
        success: result.success,
        verification_id: result.verification_id,
        is_over_21: result.is_over_21,
        id_verified: result.id_verified,
        age: result.age,
        message: result.message
      });
    } catch (error) {
      console.error('Age verification error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to verify age and identity'
      });
    }
  }
  
  /**
   * Verify business license
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async verifyBusinessLicense(req, res) {
    try {
      const { license_type, license_number, license_authority, issue_date, expiry_date } = req.body;
      
      // Validate required fields
      if (!license_type || !license_number || !license_authority || !issue_date || !expiry_date) {
        return res.status(400).json({
          success: false,
          message: 'License type, number, authority, issue date, and expiry date are required'
        });
      }
      
      // Only farmers and dispensaries can verify business licenses
      if (req.user.role !== 'farmer' && req.user.role !== 'dispensary') {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to verify business licenses'
        });
      }
      
      // Verify business license
      const result = await MetrcService.verifyBusinessLicense({
        user_id: req.user.id,
        license_type,
        license_number,
        license_authority,
        issue_date,
        expiry_date
      });
      
      // Return result
      res.status(200).json({
        success: result.success,
        verification_id: result.verification_id,
        is_valid: result.is_valid,
        is_expired: result.is_expired,
        message: result.message
      });
    } catch (error) {
      console.error('License verification error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to verify business license'
      });
    }
  }
  
  /**
   * Get compliance records for an order
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async getComplianceRecordsByOrderId(req, res) {
    try {
      const { orderId } = req.params;
      
      // Get order details
      const order = await Order.getOrderById(orderId);
      
      if (!order) {
        return res.status(404).json({
          success: false,
          message: 'Order not found'
        });
      }
      
      // Verify user has access to this order
      if (req.user.role !== 'admin' && 
          order.user_id !== req.user.id && 
          (req.user.role !== 'dispensary' || order.dispensary_id !== req.user.profile_id)) {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to view compliance records for this order'
        });
      }
      
      // Get compliance records
      const records = await MetrcService.getComplianceRecordsByOrderId(orderId);
      
      // Return records
      res.status(200).json({
        success: true,
        records
      });
    } catch (error) {
      console.error('Get compliance records error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to get compliance records'
      });
    }
  }
  
  /**
   * Generate compliance report
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async generateComplianceReport(req, res) {
    try {
      // Only admins can generate compliance reports
      if (req.user.role !== 'admin') {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to generate compliance reports'
        });
      }
      
      // Extract filter parameters
      const { start_date, end_date, type, status, limit } = req.query;
      
      // Generate compliance report
      const report = await MetrcService.generateComplianceReport({
        start_date,
        end_date,
        type,
        status,
        limit: parseInt(limit) || 100
      });
      
      // Return report
      res.status(200).json({
        success: true,
        report
      });
    } catch (error) {
      console.error('Compliance report error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to generate compliance report'
      });
    }
  }
}

module.exports = new ComplianceController();
