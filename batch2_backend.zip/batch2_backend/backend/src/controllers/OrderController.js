const Order = require('../models/Order');
const Product = require('../models/Product');
const Payment = require('../models/Payment');
const ConsumerProfile = require('../models/ConsumerProfile');
const DispensaryProfile = require('../models/DispensaryProfile');
const config = require('../config/config');

// Order controller
const OrderController = {
  // Create a new order
  async create(req, res) {
    try {
      const {
        consumer_id,
        dispensary_id,
        items,
        payment_method
      } = req.body;
      
      // Verify consumer exists
      const consumer = await ConsumerProfile.findById(consumer_id);
      if (!consumer) {
        return res.status(404).json({ message: 'Consumer not found' });
      }
      
      // Verify dispensary exists and is verified
      const dispensary = await DispensaryProfile.findById(dispensary_id);
      if (!dispensary) {
        return res.status(404).json({ message: 'Dispensary not found' });
      }
      
      if (!dispensary.is_verified) {
        return res.status(403).json({ message: 'Dispensary is not verified' });
      }
      
      // Calculate order totals
      let subtotal = 0;
      
      // Validate items and calculate subtotal
      for (const item of items) {
        const product = await Product.findById(item.product_id);
        if (!product) {
          return res.status(404).json({ message: `Product not found: ${item.product_id}` });
        }
        
        if (product.quantity < item.quantity) {
          return res.status(400).json({ message: `Insufficient quantity for product: ${product.name}` });
        }
        
        item.price_per_unit = product.price;
        item.subtotal = parseFloat((product.price * item.quantity).toFixed(2));
        item.farmer_id = product.farmer_id;
        
        subtotal += item.subtotal;
      }
      
      // Calculate taxes
      const taxes = Order.calculateTaxes(subtotal, dispensary.city);
      const { exciseTax, localTax } = taxes;
      
      // Calculate commission
      const commission = Order.calculateCommission(subtotal, exciseTax + localTax);
      
      // Calculate total
      const total = parseFloat((subtotal + exciseTax + localTax + commission).toFixed(2));
      
      // Create order
      const order = await Order.create({
        consumer_id,
        dispensary_id,
        subtotal,
        excise_tax: exciseTax,
        local_tax: localTax,
        commission,
        total,
        payment_method,
        payment_status: 'pending'
      });
      
      // Add order items
      await Order.addOrderItems(order.id, items);
      
      // Process payment
      let paymentResult = null;
      if (payment_method === 'ach') {
        // Implement ACH payment processing
        // This would integrate with the payment processor
        paymentResult = {
          transaction_id: `TRANS-${Date.now()}`,
          status: 'processing',
          escrow_id: `ESCROW-${Date.now()}`
        };
      } else if (payment_method === 'cash') {
        paymentResult = {
          transaction_id: null,
          status: 'pending',
          escrow_id: null
        };
      }
      
      // Create payment record
      if (paymentResult) {
        await Payment.create({
          order_id: order.id,
          amount: total,
          payment_method,
          transaction_id: paymentResult.transaction_id,
          status: paymentResult.status,
          escrow_id: paymentResult.escrow_id
        });
        
        // Update order payment status
        await Order.updatePaymentStatus(order.id, paymentResult.status);
      }
      
      res.status(201).json({
        message: 'Order created successfully',
        order: {
          ...order,
          items
        }
      });
    } catch (error) {
      console.error('Create order error:', error);
      res.status(500).json({ message: 'Error creating order', error: error.message });
    }
  },
  
  // Get order by ID
  async getById(req, res) {
    try {
      const orderId = req.params.id;
      
      const order = await Order.findById(orderId);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      // Get order items
      const items = await Order.getOrderItems(orderId);
      
      // Get payment information
      const payment = await Payment.findByOrderId(orderId);
      
      res.status(200).json({
        order: {
          ...order,
          items,
          payment
        }
      });
    } catch (error) {
      console.error('Get order error:', error);
      res.status(500).json({ message: 'Error getting order', error: error.message });
    }
  },
  
  // Update order status
  async updateStatus(req, res) {
    try {
      const orderId = req.params.id;
      const { status } = req.body;
      
      // Verify order exists
      const order = await Order.findById(orderId);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      // Update status
      const updatedOrder = await Order.updateStatus(orderId, status);
      
      // If status is completed, process farmer payouts
      if (status === 'completed') {
        await Payment.processFarmerPayouts(orderId);
      }
      
      res.status(200).json({
        message: 'Order status updated successfully',
        order: updatedOrder
      });
    } catch (error) {
      console.error('Update order status error:', error);
      res.status(500).json({ message: 'Error updating order status', error: error.message });
    }
  },
  
  // Mark order as ready for pickup
  async markReadyForPickup(req, res) {
    try {
      const orderId = req.params.id;
      const { pickup_time } = req.body;
      
      // Verify order exists
      const order = await Order.findById(orderId);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      // Update status
      const updatedOrder = await Order.markReadyForPickup(orderId, pickup_time);
      
      res.status(200).json({
        message: 'Order marked as ready for pickup',
        order: updatedOrder
      });
    } catch (error) {
      console.error('Mark ready for pickup error:', error);
      res.status(500).json({ message: 'Error marking order as ready for pickup', error: error.message });
    }
  },
  
  // Complete pickup
  async completePickup(req, res) {
    try {
      const orderId = req.params.id;
      
      // Verify order exists
      const order = await Order.findById(orderId);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      // Complete pickup
      const updatedOrder = await Order.completePickup(orderId);
      
      // Process farmer payouts
      await Payment.processFarmerPayouts(orderId);
      
      res.status(200).json({
        message: 'Pickup completed successfully',
        order: updatedOrder
      });
    } catch (error) {
      console.error('Complete pickup error:', error);
      res.status(500).json({ message: 'Error completing pickup', error: error.message });
    }
  },
  
  // Cancel order
  async cancelOrder(req, res) {
    try {
      const orderId = req.params.id;
      
      // Verify order exists
      const order = await Order.findById(orderId);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      // Cancel order
      const updatedOrder = await Order.cancelOrder(orderId);
      
      res.status(200).json({
        message: 'Order cancelled successfully',
        order: updatedOrder
      });
    } catch (error) {
      console.error('Cancel order error:', error);
      res.status(500).json({ message: 'Error cancelling order', error: error.message });
    }
  },
  
  // Get orders by consumer ID
  async getByConsumerId(req, res) {
    try {
      const consumerId = req.params.consumerId || req.consumer.id;
      
      const orders = await Order.getByConsumerId(consumerId);
      
      res.status(200).json({ orders });
    } catch (error) {
      console.error('Get consumer orders error:', error);
      res.status(500).json({ message: 'Error getting consumer orders', error: error.message });
    }
  },
  
  // Get orders by dispensary ID
  async getByDispensaryId(req, res) {
    try {
      const dispensaryId = req.params.dispensaryId || req.dispensary.id;
      const status = req.query.status;
      
      const orders = await Order.getByDispensaryId(dispensaryId, status);
      
      res.status(200).json({ orders });
    } catch (error) {
      console.error('Get dispensary orders error:', error);
      res.status(500).json({ message: 'Error getting dispensary orders', error: error.message });
    }
  },
  
  // Get orders by farmer ID
  async getByFarmerId(req, res) {
    try {
      const farmerId = req.params.farmerId || req.farmer.id;
      
      const orders = await Order.getByFarmerId(farmerId);
      
      res.status(200).json({ orders });
    } catch (error) {
      console.error('Get farmer orders error:', error);
      res.status(500).json({ message: 'Error getting farmer orders', error: error.message });
    }
  },
  
  // Update Metrc reporting status
  async updateMetrcReporting(req, res) {
    try {
      const orderId = req.params.id;
      const { reported, report_id } = req.body;
      
      // Verify order exists
      const order = await Order.findById(orderId);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      // Update Metrc reporting status
      const updatedOrder = await Order.updateMetrcReporting(orderId, reported, report_id);
      
      res.status(200).json({
        message: 'Metrc reporting status updated successfully',
        order: updatedOrder
      });
    } catch (error) {
      console.error('Update Metrc reporting error:', error);
      res.status(500).json({ message: 'Error updating Metrc reporting status', error: error.message });
    }
  }
};

module.exports = OrderController;
