const Product = require('../models/Product');
const FarmerProfile = require('../models/FarmerProfile');
const DispensaryInventory = require('../models/DispensaryInventory');

// Product controller
const ProductController = {
  // Create a new product
  async create(req, res) {
    try {
      const farmerId = req.body.farmer_id || req.farmer.id;
      
      // Verify farmer exists and is verified
      const farmer = await FarmerProfile.findById(farmerId);
      if (!farmer) {
        return res.status(404).json({ message: 'Farmer not found' });
      }
      
      if (!farmer.is_verified) {
        return res.status(403).json({ message: 'Farmer is not verified' });
      }
      
      // Create product
      const product = await Product.create({
        farmer_id: farmerId,
        name: req.body.name,
        description: req.body.description,
        category: req.body.category,
        strain_type: req.body.strain_type,
        thc_content: req.body.thc_content,
        cbd_content: req.body.cbd_content,
        price: req.body.price,
        quantity: req.body.quantity,
        unit: req.body.unit,
        metrc_id: req.body.metrc_id,
        lab_test_id: req.body.lab_test_id,
        lab_test_date: req.body.lab_test_date,
        images: req.body.images
      });
      
      res.status(201).json({
        message: 'Product created successfully',
        product
      });
    } catch (error) {
      console.error('Create product error:', error);
      res.status(500).json({ message: 'Error creating product', error: error.message });
    }
  },
  
  // Get product by ID
  async getById(req, res) {
    try {
      const productId = req.params.id;
      
      const product = await Product.findById(productId);
      if (!product) {
        return res.status(404).json({ message: 'Product not found' });
      }
      
      res.status(200).json({ product });
    } catch (error) {
      console.error('Get product error:', error);
      res.status(500).json({ message: 'Error getting product', error: error.message });
    }
  },
  
  // Update product
  async update(req, res) {
    try {
      const productId = req.params.id;
      
      // Check if product exists
      const existingProduct = await Product.findById(productId);
      if (!existingProduct) {
        return res.status(404).json({ message: 'Product not found' });
      }
      
      // Verify ownership if not admin
      if (req.user.role !== 'admin' && existingProduct.farmer_id !== req.farmer.id) {
        return res.status(403).json({ message: 'Not authorized to update this product' });
      }
      
      // Update product
      const product = await Product.update(productId, {
        name: req.body.name,
        description: req.body.description,
        category: req.body.category,
        strain_type: req.body.strain_type,
        thc_content: req.body.thc_content,
        cbd_content: req.body.cbd_content,
        price: req.body.price,
        quantity: req.body.quantity,
        unit: req.body.unit,
        metrc_id: req.body.metrc_id,
        lab_test_id: req.body.lab_test_id,
        lab_test_date: req.body.lab_test_date,
        is_active: req.body.is_active,
        images: req.body.images
      });
      
      res.status(200).json({
        message: 'Product updated successfully',
        product
      });
    } catch (error) {
      console.error('Update product error:', error);
      res.status(500).json({ message: 'Error updating product', error: error.message });
    }
  },
  
  // Search products
  async search(req, res) {
    try {
      const criteria = {
        category: req.query.category,
        strain_type: req.query.strain_type,
        min_thc: req.query.min_thc,
        max_thc: req.query.max_thc,
        min_cbd: req.query.min_cbd,
        max_cbd: req.query.max_cbd,
        min_price: req.query.min_price,
        max_price: req.query.max_price,
        farmer_id: req.query.farmer_id,
        is_active: true, // Only return active products
        search_term: req.query.search
      };
      
      const products = await Product.search(criteria);
      
      res.status(200).json({ products });
    } catch (error) {
      console.error('Search products error:', error);
      res.status(500).json({ message: 'Error searching products', error: error.message });
    }
  },
  
  // Get products by farmer ID
  async getByFarmerId(req, res) {
    try {
      const farmerId = req.params.farmerId || req.farmer.id;
      
      const products = await Product.getByFarmerId(farmerId);
      
      res.status(200).json({ products });
    } catch (error) {
      console.error('Get farmer products error:', error);
      res.status(500).json({ message: 'Error getting farmer products', error: error.message });
    }
  },
  
  // Get products by dispensary ID
  async getByDispensaryId(req, res) {
    try {
      const dispensaryId = req.params.dispensaryId;
      
      const products = await Product.getByDispensaryId(dispensaryId);
      
      res.status(200).json({ products });
    } catch (error) {
      console.error('Get dispensary products error:', error);
      res.status(500).json({ message: 'Error getting dispensary products', error: error.message });
    }
  },
  
  // Add product to dispensary inventory
  async addToDispensaryInventory(req, res) {
    try {
      const { product_id, dispensary_id, available_quantity } = req.body;
      
      // Check if product exists
      const product = await Product.findById(product_id);
      if (!product) {
        return res.status(404).json({ message: 'Product not found' });
      }
      
      // Add to inventory
      const inventory = await DispensaryInventory.addProduct(
        dispensary_id,
        product_id,
        available_quantity
      );
      
      res.status(201).json({
        message: 'Product added to dispensary inventory',
        inventory
      });
    } catch (error) {
      console.error('Add to inventory error:', error);
      res.status(500).json({ message: 'Error adding product to inventory', error: error.message });
    }
  },
  
  // Approve product in dispensary inventory
  async approveInDispensaryInventory(req, res) {
    try {
      const { inventory_id } = req.params;
      
      // Update approval status
      const inventory = await DispensaryInventory.approveProduct(inventory_id);
      
      res.status(200).json({
        message: 'Product approved in dispensary inventory',
        inventory
      });
    } catch (error) {
      console.error('Approve inventory error:', error);
      res.status(500).json({ message: 'Error approving product in inventory', error: error.message });
    }
  }
};

module.exports = ProductController;
