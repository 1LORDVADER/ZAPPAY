const PaymentProcessor = require('../../payment_processor/PaymentProcessor');
const Order = require('../models/Order');
const User = require('../models/User');
const config = require('../config/config');

/**
 * Payment Controller
 * Handles payment-related API endpoints
 */
class PaymentController {
  /**
   * Process a new payment
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async processPayment(req, res) {
    try {
      const { order_id, payment_method, payment_details } = req.body;
      
      // Validate required fields
      if (!order_id || !payment_method) {
        return res.status(400).json({
          success: false,
          message: 'Order ID and payment method are required'
        });
      }
      
      // Get order details
      const order = await Order.getOrderById(order_id);
      
      if (!order) {
        return res.status(404).json({
          success: false,
          message: 'Order not found'
        });
      }
      
      // Verify user owns this order
      if (order.user_id !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to process payment for this order'
        });
      }
      
      // Prepare payment data
      const paymentData = {
        order_id,
        user_id: req.user.id,
        amount: order.total,
        payment_method,
        payment_details
      };
      
      // Process payment through payment processor
      const payment = await PaymentProcessor.processPayment(paymentData);
      
      // Update order status
      await Order.updateOrderStatus(order_id, 'processing', {
        payment_id: payment.id
      });
      
      // Return payment details
      res.status(200).json({
        success: true,
        payment: {
          id: payment.id,
          status: payment.status,
          amount: payment.amount,
          platform_fee: payment.platform_fee,
          created_at: payment.created_at
        }
      });
    } catch (error) {
      console.error('Payment processing error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to process payment'
      });
    }
  }
  
  /**
   * Get payment by ID
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async getPaymentById(req, res) {
    try {
      const { id } = req.params;
      
      // Get payment details
      const payment = await PaymentProcessor.getPaymentById(id);
      
      // Verify user owns this payment or is admin
      if (payment.user_id !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to view this payment'
        });
      }
      
      // Return payment details
      res.status(200).json({
        success: true,
        payment
      });
    } catch (error) {
      console.error('Get payment error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to get payment'
      });
    }
  }
  
  /**
   * Get payments by order ID
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async getPaymentsByOrderId(req, res) {
    try {
      const { orderId } = req.params;
      
      // Get order details
      const order = await Order.getOrderById(orderId);
      
      if (!order) {
        return res.status(404).json({
          success: false,
          message: 'Order not found'
        });
      }
      
      // Verify user owns this order or is admin
      if (order.user_id !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to view payments for this order'
        });
      }
      
      // Get payments for this order
      const payments = await PaymentProcessor.getPaymentsByOrderId(orderId);
      
      // Return payments
      res.status(200).json({
        success: true,
        payments
      });
    } catch (error) {
      console.error('Get payments error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to get payments'
      });
    }
  }
  
  /**
   * Update payment status
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async updatePaymentStatus(req, res) {
    try {
      const { id } = req.params;
      const { status, additional_data } = req.body;
      
      // Validate required fields
      if (!status) {
        return res.status(400).json({
          success: false,
          message: 'Status is required'
        });
      }
      
      // Only admins and dispensaries can update payment status
      if (req.user.role !== 'admin' && req.user.role !== 'dispensary') {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to update payment status'
        });
      }
      
      // Get payment details
      const payment = await PaymentProcessor.getPaymentById(id);
      
      // For dispensaries, verify they are associated with the order
      if (req.user.role === 'dispensary') {
        const order = await Order.getOrderById(payment.order_id);
        
        if (order.dispensary_id !== req.user.profile_id) {
          return res.status(403).json({
            success: false,
            message: 'Unauthorized to update payment for this order'
          });
        }
      }
      
      // Update payment status
      const updatedPayment = await PaymentProcessor.updatePaymentStatus(id, status, additional_data);
      
      // If payment is completed, update order status
      if (status === 'completed') {
        await Order.updateOrderStatus(payment.order_id, 'completed');
      }
      
      // Return updated payment
      res.status(200).json({
        success: true,
        payment: updatedPayment
      });
    } catch (error) {
      console.error('Update payment status error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to update payment status'
      });
    }
  }
  
  /**
   * Process refund
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async processRefund(req, res) {
    try {
      const { id } = req.params;
      const { amount, reason } = req.body;
      
      // Only admins and dispensaries can process refunds
      if (req.user.role !== 'admin' && req.user.role !== 'dispensary') {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to process refunds'
        });
      }
      
      // Get payment details
      const payment = await PaymentProcessor.getPaymentById(id);
      
      // For dispensaries, verify they are associated with the order
      if (req.user.role === 'dispensary') {
        const order = await Order.getOrderById(payment.order_id);
        
        if (order.dispensary_id !== req.user.profile_id) {
          return res.status(403).json({
            success: false,
            message: 'Unauthorized to refund payment for this order'
          });
        }
      }
      
      // Process refund
      const refund = await PaymentProcessor.processRefund(id, amount, reason);
      
      // Update order status
      await Order.updateOrderStatus(payment.order_id, 'refunded', {
        refund_id: refund.id,
        refund_amount: refund.amount,
        refund_reason: reason
      });
      
      // Return refund details
      res.status(200).json({
        success: true,
        refund
      });
    } catch (error) {
      console.error('Refund processing error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to process refund'
      });
    }
  }
  
  /**
   * Generate payment receipt
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async generateReceipt(req, res) {
    try {
      const { id } = req.params;
      
      // Get payment details
      const payment = await PaymentProcessor.getPaymentById(id);
      
      // Verify user owns this payment or is admin/dispensary
      if (payment.user_id !== req.user.id && 
          req.user.role !== 'admin' && 
          req.user.role !== 'dispensary') {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to generate receipt for this payment'
        });
      }
      
      // For dispensaries, verify they are associated with the order
      if (req.user.role === 'dispensary') {
        const order = await Order.getOrderById(payment.order_id);
        
        if (order.dispensary_id !== req.user.profile_id) {
          return res.status(403).json({
            success: false,
            message: 'Unauthorized to generate receipt for this order'
          });
        }
      }
      
      // Generate receipt
      const receipt = await PaymentProcessor.generateReceipt(id);
      
      // Return receipt
      res.status(200).json({
        success: true,
        receipt
      });
    } catch (error) {
      console.error('Receipt generation error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to generate receipt'
      });
    }
  }
  
  /**
   * Get payment statistics
   * @param {Object} req - Express request object
   * @param {Object} res - Express response object
   */
  async getPaymentStats(req, res) {
    try {
      // Only admins can view payment statistics
      if (req.user.role !== 'admin') {
        return res.status(403).json({
          success: false,
          message: 'Unauthorized to view payment statistics'
        });
      }
      
      // Extract filter parameters
      const { start_date, end_date, payment_method, status } = req.query;
      
      // Get payment statistics
      const stats = await PaymentProcessor.getPaymentStats({
        start_date,
        end_date,
        payment_method,
        status
      });
      
      // Return statistics
      res.status(200).json({
        success: true,
        stats
      });
    } catch (error) {
      console.error('Payment stats error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to get payment statistics'
      });
    }
  }
}

module.exports = new PaymentController();
