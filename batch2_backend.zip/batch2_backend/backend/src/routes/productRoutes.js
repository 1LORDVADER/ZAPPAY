const express = require('express');
const router = express.Router();
const ProductController = require('../controllers/ProductController');
const authMiddleware = require('../middleware/authMiddleware');

// Public routes
router.get('/search', ProductController.search);
router.get('/:id', ProductController.getById);
router.get('/dispensary/:dispensaryId', ProductController.getByDispensaryId);

// Protected routes
router.post('/', 
  authMiddleware.verifyToken, 
  authMiddleware.isFarmer, 
  ProductController.create
);

router.put('/:id', 
  authMiddleware.verifyToken, 
  authMiddleware.isFarmer, 
  ProductController.update
);

router.get('/farmer/:farmerId', 
  authMiddleware.verifyToken, 
  ProductController.getByFarmerId
);

router.post('/inventory', 
  authMiddleware.verifyToken, 
  authMiddleware.isDispensary, 
  ProductController.addToDispensaryInventory
);

router.put('/inventory/:inventory_id/approve', 
  authMiddleware.verifyToken, 
  authMiddleware.isDispensary, 
  ProductController.approveInDispensaryInventory
);

module.exports = router;
