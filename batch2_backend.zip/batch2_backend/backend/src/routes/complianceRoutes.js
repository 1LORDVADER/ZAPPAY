const express = require('express');
const router = express.Router();
const ComplianceController = require('../controllers/ComplianceController');
const authMiddleware = require('../middleware/authMiddleware');

// Compliance routes
// All routes require authentication

// Report sale to Metrc
router.post('/sales/report', authMiddleware, ComplianceController.reportSaleToMetrc);

// Verify package in Metrc
router.get('/packages/:packageId/verify', authMiddleware, ComplianceController.verifyPackage);

// Get active inventory from Metrc
router.get('/inventory', authMiddleware, ComplianceController.getActiveInventory);

// Sync inventory with Metrc
router.post('/inventory/sync', authMiddleware, ComplianceController.syncInventory);

// Verify age and identity
router.post('/verify/identity', authMiddleware, ComplianceController.verifyAgeAndIdentity);

// Verify business license
router.post('/verify/license', authMiddleware, ComplianceController.verifyBusinessLicense);

// Get compliance records for an order
router.get('/records/order/:orderId', authMiddleware, ComplianceController.getComplianceRecordsByOrderId);

// Generate compliance report (admin only)
router.get('/reports', authMiddleware, ComplianceController.generateComplianceReport);

module.exports = router;
