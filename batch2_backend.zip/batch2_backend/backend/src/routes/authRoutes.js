const express = require('express');
const router = express.Router();
const AuthController = require('../controllers/AuthController');
const authMiddleware = require('../middleware/authMiddleware');

// Public routes
router.post('/register', AuthController.register);
router.post('/login', AuthController.login);

// Protected routes
router.get('/profile', authMiddleware.verifyToken, AuthController.getProfile);
router.post('/verify-age', authMiddleware.verifyToken, AuthController.verifyAge);
router.put('/update-password', authMiddleware.verifyToken, AuthController.updatePassword);

module.exports = router;
