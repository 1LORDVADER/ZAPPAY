const express = require('express');
const router = express.Router();
const AdminController = require('../controllers/AdminController');
const authMiddleware = require('../middleware/authMiddleware');

// All routes require admin authentication
router.use(authMiddleware.verifyToken);
router.use(authMiddleware.isAdmin);

// User management
router.get('/users', AdminController.getAllUsers);
router.get('/users/:id', AdminController.getUserById);
router.put('/users/:id/status', AdminController.updateUserStatus);

// Verification
router.get('/verifications/farmers', AdminController.getFarmerVerifications);
router.get('/verifications/dispensaries', AdminController.getDispensaryVerifications);
router.put('/verifications/farmers/:id', AdminController.updateFarmerVerification);
router.put('/verifications/dispensaries/:id', AdminController.updateDispensaryVerification);

// Monitoring
router.get('/expiring-licenses', AdminController.getExpiringLicenses);
router.get('/transactions', AdminController.getTransactions);
router.get('/transactions/suspicious', AdminController.getSuspiciousTransactions);

// Dashboard
router.get('/dashboard/stats', AdminController.getDashboardStats);
router.get('/dashboard/revenue', AdminController.getRevenueStats);
router.get('/dashboard/users', AdminController.getUserStats);

// System
router.get('/system/health', AdminController.getSystemHealth);
router.put('/system/settings', AdminController.updateSystemSettings);

module.exports = router;
