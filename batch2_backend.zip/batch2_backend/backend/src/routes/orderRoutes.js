const express = require('express');
const router = express.Router();
const OrderController = require('../controllers/OrderController');
const authMiddleware = require('../middleware/authMiddleware');

// Protected routes
router.post('/', 
  authMiddleware.verifyToken, 
  authMiddleware.isConsumer,
  authMiddleware.isAgeVerified,
  OrderController.create
);

router.get('/:id', 
  authMiddleware.verifyToken, 
  OrderController.getById
);

router.put('/:id/status', 
  authMiddleware.verifyToken, 
  OrderController.updateStatus
);

router.put('/:id/ready-for-pickup', 
  authMiddleware.verifyToken, 
  authMiddleware.isDispensary, 
  OrderController.markReadyForPickup
);

router.put('/:id/complete-pickup', 
  authMiddleware.verifyToken, 
  authMiddleware.isDispensary, 
  OrderController.completePickup
);

router.put('/:id/cancel', 
  authMiddleware.verifyToken, 
  OrderController.cancelOrder
);

router.get('/consumer/:consumerId', 
  authMiddleware.verifyToken, 
  authMiddleware.isConsumer, 
  OrderController.getByConsumerId
);

router.get('/dispensary/:dispensaryId', 
  authMiddleware.verifyToken, 
  authMiddleware.isDispensary, 
  OrderController.getByDispensaryId
);

router.get('/farmer/:farmerId', 
  authMiddleware.verifyToken, 
  authMiddleware.isFarmer, 
  OrderController.getByFarmerId
);

router.put('/:id/metrc', 
  authMiddleware.verifyToken, 
  authMiddleware.isAdmin, 
  OrderController.updateMetrcReporting
);

module.exports = router;
