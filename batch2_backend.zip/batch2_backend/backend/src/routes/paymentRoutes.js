const express = require('express');
const router = express.Router();
const PaymentController = require('../controllers/PaymentController');
const authMiddleware = require('../middleware/authMiddleware');

// Payment routes
// All routes require authentication

// Process a new payment
router.post('/process', authMiddleware, PaymentController.processPayment);

// Get payment by ID
router.get('/:id', authMiddleware, PaymentController.getPaymentById);

// Get payments by order ID
router.get('/order/:orderId', authMiddleware, PaymentController.getPaymentsByOrderId);

// Update payment status
router.put('/:id/status', authMiddleware, PaymentController.updatePaymentStatus);

// Process refund
router.post('/:id/refund', authMiddleware, PaymentController.processRefund);

// Generate payment receipt
router.get('/:id/receipt', authMiddleware, PaymentController.generateReceipt);

// Get payment statistics (admin only)
router.get('/stats', authMiddleware, PaymentController.getPaymentStats);

module.exports = router;
