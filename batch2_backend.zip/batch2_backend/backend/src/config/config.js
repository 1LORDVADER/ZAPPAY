require('dotenv').config();

module.exports = {
  // Server configuration
  server: {
    port: process.env.PORT || 5000,
    env: process.env.NODE_ENV || 'development',
  },
  
  // JWT configuration
  jwt: {
    secret: process.env.JWT_SECRET || 'cannabis-marketplace-secret-key',
    expiresIn: process.env.JWT_EXPIRES_IN || '24h',
  },
  
  // Commission rate configuration
  commission: {
    rate: process.env.COMMISSION_RATE || 0.052, // 5.2% commission
  },
  
  // Tax configuration
  tax: {
    exciseTaxRate: process.env.EXCISE_TAX_RATE || 0.15, // 15% excise tax
    defaultLocalTaxRate: process.env.DEFAULT_LOCAL_TAX_RATE || 0.085, // 8.5% default local tax
  },
  
  // Metrc API configuration
  metrc: {
    apiKey: process.env.METRC_API_KEY,
    baseUrl: process.env.METRC_BASE_URL || 'https://api-ca.metrc.com',
    vendorKey: process.env.METRC_VENDOR_KEY,
  },
  
  // Payment processor configuration
  payment: {
    escrowHoldPeriod: process.env.ESCROW_HOLD_PERIOD || '24h',
    bankApiUrl: process.env.BANK_API_URL,
    bankApiKey: process.env.BANK_API_KEY,
  },
  
  // Security configuration
  security: {
    bcryptSaltRounds: parseInt(process.env.BCRYPT_SALT_ROUNDS || '10'),
    corsOrigin: process.env.CORS_ORIGIN || 'http://localhost:3000',
  },
  
  // Age verification configuration
  ageVerification: {
    minimumAge: parseInt(process.env.MINIMUM_AGE || '21'),
    verificationService: process.env.AGE_VERIFICATION_SERVICE,
    verificationApiKey: process.env.AGE_VERIFICATION_API_KEY,
  },
};
