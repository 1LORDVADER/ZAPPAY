const db = require('../config/database');

// Farmer Profile model with methods for database operations
const FarmerProfile = {
  // Create a new farmer profile
  async create(profileData) {
    const {
      user_id,
      business_name,
      license_number,
      license_type,
      license_expiration,
      business_address,
      city,
      state,
      zip_code,
      verification_documents,
      metrc_api_key
    } = profileData;
    
    const query = `
      INSERT INTO farmer_profiles (
        user_id, business_name, license_number, license_type, license_expiration,
        business_address, city, state, zip_code, verification_documents, metrc_api_key
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING *
    `;
    
    const values = [
      user_id,
      business_name,
      license_number,
      license_type,
      license_expiration,
      business_address,
      city,
      state,
      zip_code,
      verification_documents,
      metrc_api_key
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Find farmer profile by user ID
  async findByUserId(userId) {
    const query = 'SELECT * FROM farmer_profiles WHERE user_id = $1';
    
    try {
      const result = await db.query(query, [userId]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Find farmer profile by ID
  async findById(id) {
    const query = 'SELECT * FROM farmer_profiles WHERE id = $1';
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update farmer profile
  async update(id, profileData) {
    const {
      business_name,
      license_number,
      license_type,
      license_expiration,
      business_address,
      city,
      state,
      zip_code,
      metrc_api_key
    } = profileData;
    
    const query = `
      UPDATE farmer_profiles
      SET 
        business_name = $1,
        license_number = $2,
        license_type = $3,
        license_expiration = $4,
        business_address = $5,
        city = $6,
        state = $7,
        zip_code = $8,
        metrc_api_key = $9,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $10
      RETURNING *
    `;
    
    const values = [
      business_name,
      license_number,
      license_type,
      license_expiration,
      business_address,
      city,
      state,
      zip_code,
      metrc_api_key,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update verification status
  async updateVerificationStatus(id, isVerified) {
    const query = `
      UPDATE farmer_profiles
      SET is_verified = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING id, is_verified
    `;
    
    try {
      const result = await db.query(query, [isVerified, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update verification documents
  async updateVerificationDocuments(id, documents) {
    const query = `
      UPDATE farmer_profiles
      SET verification_documents = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING id, verification_documents
    `;
    
    try {
      const result = await db.query(query, [documents, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update subscription tier
  async updateSubscription(id, tier, expiryDate) {
    const query = `
      UPDATE farmer_profiles
      SET subscription_tier = $1, subscription_expiry = $2, updated_at = CURRENT_TIMESTAMP
      WHERE id = $3
      RETURNING id, subscription_tier, subscription_expiry
    `;
    
    try {
      const result = await db.query(query, [tier, expiryDate, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Get all verified farmers
  async getAllVerified() {
    const query = `
      SELECT fp.*, u.email, u.first_name, u.last_name, u.phone
      FROM farmer_profiles fp
      JOIN users u ON fp.user_id = u.id
      WHERE fp.is_verified = true AND u.is_active = true
      ORDER BY fp.business_name
    `;
    
    try {
      const result = await db.query(query);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Get farmers pending verification
  async getPendingVerification() {
    const query = `
      SELECT fp.*, u.email, u.first_name, u.last_name, u.phone
      FROM farmer_profiles fp
      JOIN users u ON fp.user_id = u.id
      WHERE fp.is_verified = false AND u.is_active = true
      ORDER BY fp.created_at DESC
    `;
    
    try {
      const result = await db.query(query);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Check if license is expiring soon (within 30 days)
  async getExpiringLicenses() {
    const query = `
      SELECT fp.*, u.email, u.first_name, u.last_name, u.phone
      FROM farmer_profiles fp
      JOIN users u ON fp.user_id = u.id
      WHERE fp.is_verified = true 
      AND u.is_active = true
      AND fp.license_expiration BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '30 days')
      ORDER BY fp.license_expiration
    `;
    
    try {
      const result = await db.query(query);
      return result.rows;
    } catch (error) {
      throw error;
    }
  }
};

module.exports = FarmerProfile;
