const db = require('../config/database');

// Dispensary Profile model with methods for database operations
const DispensaryProfile = {
  // Create a new dispensary profile
  async create(profileData) {
    const {
      user_id,
      business_name,
      license_number,
      license_type,
      license_expiration,
      business_address,
      city,
      state,
      zip_code,
      verification_documents,
      metrc_api_key,
      pos_system,
      business_hours,
      pickup_instructions
    } = profileData;
    
    const query = `
      INSERT INTO dispensary_profiles (
        user_id, business_name, license_number, license_type, license_expiration,
        business_address, city, state, zip_code, verification_documents, metrc_api_key,
        pos_system, business_hours, pickup_instructions
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
      RETURNING *
    `;
    
    const values = [
      user_id,
      business_name,
      license_number,
      license_type,
      license_expiration,
      business_address,
      city,
      state,
      zip_code,
      verification_documents,
      metrc_api_key,
      pos_system,
      business_hours,
      pickup_instructions
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Find dispensary profile by user ID
  async findByUserId(userId) {
    const query = 'SELECT * FROM dispensary_profiles WHERE user_id = $1';
    
    try {
      const result = await db.query(query, [userId]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Find dispensary profile by ID
  async findById(id) {
    const query = 'SELECT * FROM dispensary_profiles WHERE id = $1';
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update dispensary profile
  async update(id, profileData) {
    const {
      business_name,
      license_number,
      license_type,
      license_expiration,
      business_address,
      city,
      state,
      zip_code,
      metrc_api_key,
      pos_system,
      business_hours,
      pickup_instructions
    } = profileData;
    
    const query = `
      UPDATE dispensary_profiles
      SET 
        business_name = $1,
        license_number = $2,
        license_type = $3,
        license_expiration = $4,
        business_address = $5,
        city = $6,
        state = $7,
        zip_code = $8,
        metrc_api_key = $9,
        pos_system = $10,
        business_hours = $11,
        pickup_instructions = $12,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $13
      RETURNING *
    `;
    
    const values = [
      business_name,
      license_number,
      license_type,
      license_expiration,
      business_address,
      city,
      state,
      zip_code,
      metrc_api_key,
      pos_system,
      business_hours,
      pickup_instructions,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update verification status
  async updateVerificationStatus(id, isVerified) {
    const query = `
      UPDATE dispensary_profiles
      SET is_verified = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING id, is_verified
    `;
    
    try {
      const result = await db.query(query, [isVerified, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update verification documents
  async updateVerificationDocuments(id, documents) {
    const query = `
      UPDATE dispensary_profiles
      SET verification_documents = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING id, verification_documents
    `;
    
    try {
      const result = await db.query(query, [documents, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Get all verified dispensaries
  async getAllVerified() {
    const query = `
      SELECT dp.*, u.email, u.first_name, u.last_name, u.phone
      FROM dispensary_profiles dp
      JOIN users u ON dp.user_id = u.id
      WHERE dp.is_verified = true AND u.is_active = true
      ORDER BY dp.business_name
    `;
    
    try {
      const result = await db.query(query);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Get dispensaries pending verification
  async getPendingVerification() {
    const query = `
      SELECT dp.*, u.email, u.first_name, u.last_name, u.phone
      FROM dispensary_profiles dp
      JOIN users u ON dp.user_id = u.id
      WHERE dp.is_verified = false AND u.is_active = true
      ORDER BY dp.created_at DESC
    `;
    
    try {
      const result = await db.query(query);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Check if license is expiring soon (within 30 days)
  async getExpiringLicenses() {
    const query = `
      SELECT dp.*, u.email, u.first_name, u.last_name, u.phone
      FROM dispensary_profiles dp
      JOIN users u ON dp.user_id = u.id
      WHERE dp.is_verified = true 
      AND u.is_active = true
      AND dp.license_expiration BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '30 days')
      ORDER BY dp.license_expiration
    `;
    
    try {
      const result = await db.query(query);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Get dispensaries by location (city, state)
  async getByLocation(city, state) {
    const query = `
      SELECT dp.*, u.email
      FROM dispensary_profiles dp
      JOIN users u ON dp.user_id = u.id
      WHERE dp.is_verified = true 
      AND u.is_active = true
      AND (dp.city = $1 OR $1 IS NULL)
      AND (dp.state = $2 OR $2 IS NULL)
      ORDER BY dp.business_name
    `;
    
    try {
      const result = await db.query(query, [city, state]);
      return result.rows;
    } catch (error) {
      throw error;
    }
  }
};

module.exports = DispensaryProfile;
