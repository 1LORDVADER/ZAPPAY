const db = require('../config/database');

// Product model with methods for database operations
const Product = {
  // Create a new product
  async create(productData) {
    const {
      farmer_id,
      name,
      description,
      category,
      strain_type,
      thc_content,
      cbd_content,
      price,
      quantity,
      unit,
      metrc_id,
      lab_test_id,
      lab_test_date,
      images
    } = productData;
    
    const query = `
      INSERT INTO products (
        farmer_id, name, description, category, strain_type,
        thc_content, cbd_content, price, quantity, unit,
        metrc_id, lab_test_id, lab_test_date, images
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
      RETURNING *
    `;
    
    const values = [
      farmer_id,
      name,
      description,
      category,
      strain_type,
      thc_content,
      cbd_content,
      price,
      quantity,
      unit,
      metrc_id,
      lab_test_id,
      lab_test_date,
      images
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Find product by ID
  async findById(id) {
    const query = `
      SELECT p.*, fp.business_name as farmer_name
      FROM products p
      JOIN farmer_profiles fp ON p.farmer_id = fp.id
      WHERE p.id = $1
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Get products by farmer ID
  async getByFarmerId(farmerId) {
    const query = `
      SELECT *
      FROM products
      WHERE farmer_id = $1
      ORDER BY name
    `;
    
    try {
      const result = await db.query(query, [farmerId]);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Update product
  async update(id, productData) {
    const {
      name,
      description,
      category,
      strain_type,
      thc_content,
      cbd_content,
      price,
      quantity,
      unit,
      metrc_id,
      lab_test_id,
      lab_test_date,
      is_active,
      images
    } = productData;
    
    const query = `
      UPDATE products
      SET 
        name = $1,
        description = $2,
        category = $3,
        strain_type = $4,
        thc_content = $5,
        cbd_content = $6,
        price = $7,
        quantity = $8,
        unit = $9,
        metrc_id = $10,
        lab_test_id = $11,
        lab_test_date = $12,
        is_active = $13,
        images = $14,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $15
      RETURNING *
    `;
    
    const values = [
      name,
      description,
      category,
      strain_type,
      thc_content,
      cbd_content,
      price,
      quantity,
      unit,
      metrc_id,
      lab_test_id,
      lab_test_date,
      is_active,
      images,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update product quantity
  async updateQuantity(id, quantity) {
    const query = `
      UPDATE products
      SET 
        quantity = $1,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING id, quantity
    `;
    
    try {
      const result = await db.query(query, [quantity, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Search products by various criteria
  async search(criteria) {
    const {
      category,
      strain_type,
      min_thc,
      max_thc,
      min_cbd,
      max_cbd,
      min_price,
      max_price,
      farmer_id,
      is_active,
      search_term
    } = criteria;
    
    let query = `
      SELECT p.*, fp.business_name as farmer_name
      FROM products p
      JOIN farmer_profiles fp ON p.farmer_id = fp.id
      WHERE 1=1
    `;
    
    const values = [];
    let paramIndex = 1;
    
    if (category) {
      query += ` AND p.category = $${paramIndex}`;
      values.push(category);
      paramIndex++;
    }
    
    if (strain_type) {
      query += ` AND p.strain_type = $${paramIndex}`;
      values.push(strain_type);
      paramIndex++;
    }
    
    if (min_thc !== undefined) {
      query += ` AND p.thc_content >= $${paramIndex}`;
      values.push(min_thc);
      paramIndex++;
    }
    
    if (max_thc !== undefined) {
      query += ` AND p.thc_content <= $${paramIndex}`;
      values.push(max_thc);
      paramIndex++;
    }
    
    if (min_cbd !== undefined) {
      query += ` AND p.cbd_content >= $${paramIndex}`;
      values.push(min_cbd);
      paramIndex++;
    }
    
    if (max_cbd !== undefined) {
      query += ` AND p.cbd_content <= $${paramIndex}`;
      values.push(max_cbd);
      paramIndex++;
    }
    
    if (min_price !== undefined) {
      query += ` AND p.price >= $${paramIndex}`;
      values.push(min_price);
      paramIndex++;
    }
    
    if (max_price !== undefined) {
      query += ` AND p.price <= $${paramIndex}`;
      values.push(max_price);
      paramIndex++;
    }
    
    if (farmer_id) {
      query += ` AND p.farmer_id = $${paramIndex}`;
      values.push(farmer_id);
      paramIndex++;
    }
    
    if (is_active !== undefined) {
      query += ` AND p.is_active = $${paramIndex}`;
      values.push(is_active);
      paramIndex++;
    }
    
    if (search_term) {
      query += ` AND (p.name ILIKE $${paramIndex} OR p.description ILIKE $${paramIndex})`;
      values.push(`%${search_term}%`);
      paramIndex++;
    }
    
    query += ` ORDER BY p.name`;
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Get products available at a specific dispensary
  async getByDispensaryId(dispensaryId) {
    const query = `
      SELECT p.*, fp.business_name as farmer_name, di.available_quantity
      FROM products p
      JOIN farmer_profiles fp ON p.farmer_id = fp.id
      JOIN dispensary_inventory di ON p.id = di.product_id
      WHERE di.dispensary_id = $1
      AND di.is_approved = true
      AND p.is_active = true
      ORDER BY p.name
    `;
    
    try {
      const result = await db.query(query, [dispensaryId]);
      return result.rows;
    } catch (error) {
      throw error;
    }
  }
};

module.exports = Product;
