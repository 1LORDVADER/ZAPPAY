const db = require('../config/database');

// Payment model with methods for database operations
const Payment = {
  // Create a new payment record
  async create(paymentData) {
    const {
      order_id,
      amount,
      payment_method,
      transaction_id,
      status,
      escrow_id
    } = paymentData;
    
    const query = `
      INSERT INTO payments (
        order_id, amount, payment_method, transaction_id, status, escrow_id
      )
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *
    `;
    
    const values = [
      order_id,
      amount,
      payment_method,
      transaction_id,
      status,
      escrow_id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Find payment by ID
  async findById(id) {
    const query = 'SELECT * FROM payments WHERE id = $1';
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Find payment by order ID
  async findByOrderId(orderId) {
    const query = 'SELECT * FROM payments WHERE order_id = $1';
    
    try {
      const result = await db.query(query, [orderId]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update payment status
  async updateStatus(id, status) {
    const query = `
      UPDATE payments
      SET status = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING *
    `;
    
    try {
      const result = await db.query(query, [status, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update payout information
  async updatePayout(id, payoutId, payoutStatus, payoutDate) {
    const query = `
      UPDATE payments
      SET payout_id = $1, payout_status = $2, payout_date = $3, updated_at = CURRENT_TIMESTAMP
      WHERE id = $4
      RETURNING *
    `;
    
    try {
      const result = await db.query(query, [payoutId, payoutStatus, payoutDate, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Process farmer payouts for a completed order
  async processFarmerPayouts(orderId) {
    // Start a transaction
    const client = await db.getClient();
    
    try {
      await client.query('BEGIN');
      
      // Get order items
      const itemsQuery = `
        SELECT oi.*, o.commission
        FROM order_items oi
        JOIN orders o ON oi.order_id = o.id
        WHERE oi.order_id = $1
      `;
      
      const itemsResult = await client.query(itemsQuery, [orderId]);
      const items = itemsResult.rows;
      
      // Calculate commission rate per item
      const orderQuery = `
        SELECT commission, subtotal FROM orders WHERE id = $1
      `;
      
      const orderResult = await client.query(orderQuery, [orderId]);
      const { commission, subtotal } = orderResult.rows[0];
      const commissionRate = commission / subtotal;
      
      // Create farmer payouts
      for (const item of items) {
        const commissionAmount = parseFloat((item.subtotal * commissionRate).toFixed(2));
        const payoutAmount = item.subtotal - commissionAmount;
        
        const payoutQuery = `
          INSERT INTO farmer_payouts (
            farmer_id, order_item_id, amount, commission_amount, status
          )
          VALUES ($1, $2, $3, $4, 'pending')
          RETURNING *
        `;
        
        const payoutValues = [
          item.farmer_id,
          item.id,
          payoutAmount,
          commissionAmount
        ];
        
        await client.query(payoutQuery, payoutValues);
      }
      
      await client.query('COMMIT');
      return true;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  },
  
  // Get farmer payouts by farmer ID
  async getFarmerPayouts(farmerId) {
    const query = `
      SELECT fp.*, oi.product_id, p.name as product_name, o.id as order_id
      FROM farmer_payouts fp
      JOIN order_items oi ON fp.order_item_id = oi.id
      JOIN products p ON oi.product_id = p.id
      JOIN orders o ON oi.order_id = o.id
      WHERE fp.farmer_id = $1
      ORDER BY fp.created_at DESC
    `;
    
    try {
      const result = await db.query(query, [farmerId]);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Update farmer payout status
  async updateFarmerPayoutStatus(id, status, transactionId, payoutDate) {
    const query = `
      UPDATE farmer_payouts
      SET status = $1, transaction_id = $2, payout_date = $3, updated_at = CURRENT_TIMESTAMP
      WHERE id = $4
      RETURNING *
    `;
    
    try {
      const result = await db.query(query, [status, transactionId, payoutDate, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Get payment statistics
  async getPaymentStats(startDate, endDate) {
    const query = `
      SELECT 
        COUNT(*) as total_payments,
        SUM(amount) as total_amount,
        payment_method,
        status
      FROM payments
      WHERE created_at BETWEEN $1 AND $2
      GROUP BY payment_method, status
    `;
    
    try {
      const result = await db.query(query, [startDate, endDate]);
      return result.rows;
    } catch (error) {
      throw error;
    }
  }
};

module.exports = Payment;
