const DispensaryInventory = require('../models/DispensaryInventory');
const db = require('../config/database');

// DispensaryInventory model with methods for database operations
const DispensaryInventory = {
  // Add product to dispensary inventory
  async addProduct(dispensaryId, productId, availableQuantity) {
    const query = `
      INSERT INTO dispensary_inventory (dispensary_id, product_id, available_quantity)
      VALUES ($1, $2, $3)
      ON CONFLICT (dispensary_id, product_id) 
      DO UPDATE SET available_quantity = dispensary_inventory.available_quantity + $3,
                    updated_at = CURRENT_TIMESTAMP
      RETURNING *
    `;
    
    try {
      const result = await db.query(query, [dispensaryId, productId, availableQuantity]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Find inventory item by ID
  async findById(id) {
    const query = 'SELECT * FROM dispensary_inventory WHERE id = $1';
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Get inventory by dispensary ID
  async getByDispensaryId(dispensaryId) {
    const query = `
      SELECT di.*, p.name as product_name, p.category, p.strain_type, 
             p.thc_content, p.cbd_content, p.price, p.unit, p.images,
             fp.business_name as farmer_name
      FROM dispensary_inventory di
      JOIN products p ON di.product_id = p.id
      JOIN farmer_profiles fp ON p.farmer_id = fp.id
      WHERE di.dispensary_id = $1
      ORDER BY p.name
    `;
    
    try {
      const result = await db.query(query, [dispensaryId]);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Get approved inventory by dispensary ID
  async getApprovedByDispensaryId(dispensaryId) {
    const query = `
      SELECT di.*, p.name as product_name, p.category, p.strain_type, 
             p.thc_content, p.cbd_content, p.price, p.unit, p.images,
             fp.business_name as farmer_name
      FROM dispensary_inventory di
      JOIN products p ON di.product_id = p.id
      JOIN farmer_profiles fp ON p.farmer_id = fp.id
      WHERE di.dispensary_id = $1 AND di.is_approved = true
      ORDER BY p.name
    `;
    
    try {
      const result = await db.query(query, [dispensaryId]);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Get pending inventory by dispensary ID
  async getPendingByDispensaryId(dispensaryId) {
    const query = `
      SELECT di.*, p.name as product_name, p.category, p.strain_type, 
             p.thc_content, p.cbd_content, p.price, p.unit, p.images,
             fp.business_name as farmer_name
      FROM dispensary_inventory di
      JOIN products p ON di.product_id = p.id
      JOIN farmer_profiles fp ON p.farmer_id = fp.id
      WHERE di.dispensary_id = $1 AND di.is_approved = false
      ORDER BY p.name
    `;
    
    try {
      const result = await db.query(query, [dispensaryId]);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Approve product in inventory
  async approveProduct(id) {
    const query = `
      UPDATE dispensary_inventory
      SET is_approved = true, updated_at = CURRENT_TIMESTAMP
      WHERE id = $1
      RETURNING *
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update available quantity
  async updateQuantity(id, quantity) {
    const query = `
      UPDATE dispensary_inventory
      SET available_quantity = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING *
    `;
    
    try {
      const result = await db.query(query, [quantity, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Remove product from inventory
  async removeProduct(id) {
    const query = `
      DELETE FROM dispensary_inventory
      WHERE id = $1
      RETURNING id
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Check if product is in dispensary inventory
  async isProductInInventory(dispensaryId, productId) {
    const query = `
      SELECT * FROM dispensary_inventory
      WHERE dispensary_id = $1 AND product_id = $2
    `;
    
    try {
      const result = await db.query(query, [dispensaryId, productId]);
      return result.rows.length > 0;
    } catch (error) {
      throw error;
    }
  }
};

module.exports = DispensaryInventory;
