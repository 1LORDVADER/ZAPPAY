const db = require('../config/database');

// Compliance model with methods for database operations
const Compliance = {
  // Create a new compliance report
  async createReport(reportData) {
    const {
      report_type,
      report_date,
      report_data,
      submitted_by,
      status,
      submission_id
    } = reportData;
    
    const query = `
      INSERT INTO compliance_reports (
        report_type, report_date, report_data, submitted_by, status, submission_id
      )
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *
    `;
    
    const values = [
      report_type,
      report_date,
      report_data,
      submitted_by,
      status,
      submission_id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Find report by ID
  async findReportById(id) {
    const query = 'SELECT * FROM compliance_reports WHERE id = $1';
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Get reports by type and date range
  async getReportsByTypeAndDateRange(type, startDate, endDate) {
    const query = `
      SELECT * FROM compliance_reports
      WHERE report_type = $1
      AND report_date BETWEEN $2 AND $3
      ORDER BY report_date DESC
    `;
    
    try {
      const result = await db.query(query, [type, startDate, endDate]);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Update report status
  async updateReportStatus(id, status, submissionId) {
    const query = `
      UPDATE compliance_reports
      SET status = $1, submission_id = $2, updated_at = CURRENT_TIMESTAMP
      WHERE id = $3
      RETURNING *
    `;
    
    try {
      const result = await db.query(query, [status, submissionId, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Log Metrc sync
  async logMetrcSync(syncData) {
    const {
      entity_type,
      entity_id,
      sync_type,
      status,
      error_message,
      metrc_id
    } = syncData;
    
    const query = `
      INSERT INTO metrc_sync_logs (
        entity_type, entity_id, sync_type, status, error_message, metrc_id
      )
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *
    `;
    
    const values = [
      entity_type,
      entity_id,
      sync_type,
      status,
      error_message,
      metrc_id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Get Metrc sync logs by entity
  async getMetrcSyncLogsByEntity(entityType, entityId) {
    const query = `
      SELECT * FROM metrc_sync_logs
      WHERE entity_type = $1 AND entity_id = $2
      ORDER BY created_at DESC
    `;
    
    try {
      const result = await db.query(query, [entityType, entityId]);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Get failed Metrc syncs
  async getFailedMetrcSyncs(timeframe = '24 hours') {
    const query = `
      SELECT * FROM metrc_sync_logs
      WHERE status = 'failed'
      AND created_at > NOW() - INTERVAL '${timeframe}'
      ORDER BY created_at DESC
    `;
    
    try {
      const result = await db.query(query);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Create audit log
  async createAuditLog(logData) {
    const {
      user_id,
      action,
      entity_type,
      entity_id,
      details,
      ip_address,
      user_agent
    } = logData;
    
    const query = `
      INSERT INTO audit_logs (
        user_id, action, entity_type, entity_id, details, ip_address, user_agent
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *
    `;
    
    const values = [
      user_id,
      action,
      entity_type,
      entity_id,
      details,
      ip_address,
      user_agent
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Get audit logs by criteria
  async getAuditLogs(criteria) {
    const {
      user_id,
      action,
      entity_type,
      entity_id,
      start_date,
      end_date,
      limit = 100
    } = criteria;
    
    let query = `
      SELECT * FROM audit_logs
      WHERE 1=1
    `;
    
    const values = [];
    let paramIndex = 1;
    
    if (user_id) {
      query += ` AND user_id = $${paramIndex}`;
      values.push(user_id);
      paramIndex++;
    }
    
    if (action) {
      query += ` AND action = $${paramIndex}`;
      values.push(action);
      paramIndex++;
    }
    
    if (entity_type) {
      query += ` AND entity_type = $${paramIndex}`;
      values.push(entity_type);
      paramIndex++;
    }
    
    if (entity_id) {
      query += ` AND entity_id = $${paramIndex}`;
      values.push(entity_id);
      paramIndex++;
    }
    
    if (start_date) {
      query += ` AND created_at >= $${paramIndex}`;
      values.push(start_date);
      paramIndex++;
    }
    
    if (end_date) {
      query += ` AND created_at <= $${paramIndex}`;
      values.push(end_date);
      paramIndex++;
    }
    
    query += ` ORDER BY created_at DESC LIMIT $${paramIndex}`;
    values.push(limit);
    
    try {
      const result = await db.query(query, values);
      return result.rows;
    } catch (error) {
      throw error;
    }
  }
};

module.exports = Compliance;
