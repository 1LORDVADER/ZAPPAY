const db = require('../config/database');
const config = require('../config/config');

// Order model with methods for database operations
const Order = {
  // Create a new order
  async create(orderData) {
    const {
      consumer_id,
      dispensary_id,
      subtotal,
      excise_tax,
      local_tax,
      commission,
      total,
      payment_method,
      payment_status
    } = orderData;
    
    // Start a transaction
    const client = await db.getClient();
    
    try {
      await client.query('BEGIN');
      
      // Insert the order
      const orderQuery = `
        INSERT INTO orders (
          consumer_id, dispensary_id, status, subtotal, excise_tax,
          local_tax, commission, total, payment_method, payment_status
        )
        VALUES ($1, $2, 'pending', $3, $4, $5, $6, $7, $8, $9)
        RETURNING *
      `;
      
      const orderValues = [
        consumer_id,
        dispensary_id,
        subtotal,
        excise_tax,
        local_tax,
        commission,
        total,
        payment_method,
        payment_status
      ];
      
      const orderResult = await client.query(orderQuery, orderValues);
      const order = orderResult.rows[0];
      
      await client.query('COMMIT');
      return order;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  },
  
  // Add items to an order
  async addOrderItems(orderId, items) {
    // Start a transaction
    const client = await db.getClient();
    
    try {
      await client.query('BEGIN');
      
      for (const item of items) {
        const {
          product_id,
          farmer_id,
          quantity,
          price_per_unit,
          subtotal,
          metrc_package_id
        } = item;
        
        // Insert the order item
        const itemQuery = `
          INSERT INTO order_items (
            order_id, product_id, farmer_id, quantity,
            price_per_unit, subtotal, metrc_package_id
          )
          VALUES ($1, $2, $3, $4, $5, $6, $7)
          RETURNING *
        `;
        
        const itemValues = [
          orderId,
          product_id,
          farmer_id,
          quantity,
          price_per_unit,
          subtotal,
          metrc_package_id
        ];
        
        await client.query(itemQuery, itemValues);
        
        // Update product quantity
        const updateProductQuery = `
          UPDATE products
          SET quantity = quantity - $1, updated_at = CURRENT_TIMESTAMP
          WHERE id = $2
        `;
        
        await client.query(updateProductQuery, [quantity, product_id]);
        
        // Update dispensary inventory
        const updateInventoryQuery = `
          UPDATE dispensary_inventory
          SET available_quantity = available_quantity - $1, updated_at = CURRENT_TIMESTAMP
          WHERE product_id = $2 AND dispensary_id = (
            SELECT dispensary_id FROM orders WHERE id = $3
          )
        `;
        
        await client.query(updateInventoryQuery, [quantity, product_id, orderId]);
      }
      
      await client.query('COMMIT');
      return true;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  },
  
  // Find order by ID
  async findById(id) {
    const query = `
      SELECT o.*, cp.user_id as consumer_user_id, dp.business_name as dispensary_name
      FROM orders o
      LEFT JOIN consumer_profiles cp ON o.consumer_id = cp.id
      LEFT JOIN dispensary_profiles dp ON o.dispensary_id = dp.id
      WHERE o.id = $1
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Get order items
  async getOrderItems(orderId) {
    const query = `
      SELECT oi.*, p.name as product_name, p.category, p.strain_type, p.thc_content, p.cbd_content, p.unit,
             fp.business_name as farmer_name
      FROM order_items oi
      JOIN products p ON oi.product_id = p.id
      JOIN farmer_profiles fp ON oi.farmer_id = fp.id
      WHERE oi.order_id = $1
      ORDER BY oi.id
    `;
    
    try {
      const result = await db.query(query, [orderId]);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Update order status
  async updateStatus(id, status) {
    const query = `
      UPDATE orders
      SET status = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING *
    `;
    
    try {
      const result = await db.query(query, [status, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update payment status
  async updatePaymentStatus(id, paymentStatus) {
    const query = `
      UPDATE orders
      SET payment_status = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING *
    `;
    
    try {
      const result = await db.query(query, [paymentStatus, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Mark order as ready for pickup
  async markReadyForPickup(id, pickupTime) {
    const query = `
      UPDATE orders
      SET status = 'ready_for_pickup', pickup_time = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING *
    `;
    
    try {
      const result = await db.query(query, [pickupTime, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Complete pickup
  async completePickup(id) {
    const query = `
      UPDATE orders
      SET status = 'completed', pickup_completed_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
      WHERE id = $1
      RETURNING *
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Cancel order
  async cancelOrder(id) {
    // Start a transaction
    const client = await db.getClient();
    
    try {
      await client.query('BEGIN');
      
      // Get order items
      const itemsQuery = `
        SELECT * FROM order_items WHERE order_id = $1
      `;
      
      const itemsResult = await client.query(itemsQuery, [id]);
      const items = itemsResult.rows;
      
      // Get dispensary ID
      const orderQuery = `
        SELECT dispensary_id FROM orders WHERE id = $1
      `;
      
      const orderResult = await client.query(orderQuery, [id]);
      const dispensaryId = orderResult.rows[0].dispensary_id;
      
      // Return items to inventory
      for (const item of items) {
        // Update product quantity
        const updateProductQuery = `
          UPDATE products
          SET quantity = quantity + $1, updated_at = CURRENT_TIMESTAMP
          WHERE id = $2
        `;
        
        await client.query(updateProductQuery, [item.quantity, item.product_id]);
        
        // Update dispensary inventory
        const updateInventoryQuery = `
          UPDATE dispensary_inventory
          SET available_quantity = available_quantity + $1, updated_at = CURRENT_TIMESTAMP
          WHERE product_id = $2 AND dispensary_id = $3
        `;
        
        await client.query(updateInventoryQuery, [item.quantity, item.product_id, dispensaryId]);
      }
      
      // Update order status
      const updateOrderQuery = `
        UPDATE orders
        SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP
        WHERE id = $1
        RETURNING *
      `;
      
      const updateResult = await client.query(updateOrderQuery, [id]);
      
      await client.query('COMMIT');
      return updateResult.rows[0];
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  },
  
  // Get orders by consumer ID
  async getByConsumerId(consumerId) {
    const query = `
      SELECT o.*, dp.business_name as dispensary_name
      FROM orders o
      JOIN dispensary_profiles dp ON o.dispensary_id = dp.id
      WHERE o.consumer_id = $1
      ORDER BY o.created_at DESC
    `;
    
    try {
      const result = await db.query(query, [consumerId]);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Get orders by dispensary ID
  async getByDispensaryId(dispensaryId, status = null) {
    let query = `
      SELECT o.*, u.first_name, u.last_name
      FROM orders o
      JOIN consumer_profiles cp ON o.consumer_id = cp.id
      JOIN users u ON cp.user_id = u.id
      WHERE o.dispensary_id = $1
    `;
    
    const queryParams = [dispensaryId];
    
    if (status) {
      query += ` AND o.status = $2`;
      queryParams.push(status);
    }
    
    query += ` ORDER BY o.created_at DESC`;
    
    try {
      const result = await db.query(query, queryParams);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Get orders by farmer ID
  async getByFarmerId(farmerId) {
    const query = `
      SELECT o.id, o.status, o.created_at, o.pickup_completed_at,
             oi.quantity, oi.price_per_unit, oi.subtotal,
             p.name as product_name,
             dp.business_name as dispensary_name
      FROM orders o
      JOIN order_items oi ON o.id = oi.order_id
      JOIN products p ON oi.product_id = p.id
      JOIN dispensary_profiles dp ON o.dispensary_id = dp.id
      WHERE oi.farmer_id = $1
      ORDER BY o.created_at DESC
    `;
    
    try {
      const result = await db.query(query, [farmerId]);
      return result.rows;
    } catch (error) {
      throw error;
    }
  },
  
  // Update Metrc reporting status
  async updateMetrcReporting(id, reported, reportId) {
    const query = `
      UPDATE orders
      SET metrc_reported = $1, metrc_report_id = $2, updated_at = CURRENT_TIMESTAMP
      WHERE id = $3
      RETURNING *
    `;
    
    try {
      const result = await db.query(query, [reported, reportId, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Calculate commission
  calculateCommission(subtotal, taxes) {
    // Commission is 5.2% of (subtotal + taxes)
    const commissionBase = subtotal + taxes;
    return parseFloat((commissionBase * config.commission.rate).toFixed(2));
  },
  
  // Calculate taxes
  calculateTaxes(subtotal, location) {
    // Excise tax is 15%
    const exciseTax = parseFloat((subtotal * config.tax.exciseTaxRate).toFixed(2));
    
    // Local tax depends on location, default to 8.5%
    let localTaxRate = config.tax.defaultLocalTaxRate;
    
    // TODO: Implement location-based tax lookup
    
    const localTax = parseFloat((subtotal * localTaxRate).toFixed(2));
    
    return {
      exciseTax,
      localTax,
      totalTax: exciseTax + localTax
    };
  }
};

module.exports = Order;
