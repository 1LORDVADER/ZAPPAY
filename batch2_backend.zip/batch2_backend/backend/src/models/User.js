const db = require('../config/database');
const bcrypt = require('bcrypt');
const config = require('../config/config');

// User model with methods for database operations
const User = {
  // Create a new user
  async create(userData) {
    const { email, password, role, first_name, last_name, phone, date_of_birth } = userData;
    
    // Hash the password
    const hashedPassword = await bcrypt.hash(password, config.security.bcryptSaltRounds);
    
    const query = `
      INSERT INTO users (email, password, role, first_name, last_name, phone, date_of_birth)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING id, email, role, first_name, last_name, phone, date_of_birth, is_age_verified, is_active, created_at
    `;
    
    const values = [email, hashedPassword, role, first_name, last_name, phone, date_of_birth];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Find user by email
  async findByEmail(email) {
    const query = 'SELECT * FROM users WHERE email = $1';
    
    try {
      const result = await db.query(query, [email]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Find user by ID
  async findById(id) {
    const query = 'SELECT id, email, role, first_name, last_name, phone, date_of_birth, is_age_verified, is_active, created_at FROM users WHERE id = $1';
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update user
  async update(id, userData) {
    const { first_name, last_name, phone, is_active } = userData;
    
    const query = `
      UPDATE users
      SET first_name = $1, last_name = $2, phone = $3, is_active = $4, updated_at = CURRENT_TIMESTAMP
      WHERE id = $5
      RETURNING id, email, role, first_name, last_name, phone, date_of_birth, is_age_verified, is_active, created_at, updated_at
    `;
    
    const values = [first_name, last_name, phone, is_active, id];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update password
  async updatePassword(id, newPassword) {
    const hashedPassword = await bcrypt.hash(newPassword, config.security.bcryptSaltRounds);
    
    const query = `
      UPDATE users
      SET password = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING id
    `;
    
    try {
      const result = await db.query(query, [hashedPassword, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Verify age
  async verifyAge(id, isVerified) {
    const query = `
      UPDATE users
      SET is_age_verified = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING id, is_age_verified
    `;
    
    try {
      const result = await db.query(query, [isVerified, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Compare password for authentication
  async comparePassword(providedPassword, storedPassword) {
    return bcrypt.compare(providedPassword, storedPassword);
  }
};

module.exports = User;
