const db = require('../config/database');

// Consumer Profile model with methods for database operations
const ConsumerProfile = {
  // Create a new consumer profile
  async create(profileData) {
    const {
      user_id,
      address,
      city,
      state,
      zip_code,
      age_verification_method,
      age_verification_date,
      preferences
    } = profileData;
    
    const query = `
      INSERT INTO consumer_profiles (
        user_id, address, city, state, zip_code,
        age_verification_method, age_verification_date, preferences
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
    `;
    
    const values = [
      user_id,
      address,
      city,
      state,
      zip_code,
      age_verification_method,
      age_verification_date,
      preferences
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Find consumer profile by user ID
  async findByUserId(userId) {
    const query = 'SELECT * FROM consumer_profiles WHERE user_id = $1';
    
    try {
      const result = await db.query(query, [userId]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Find consumer profile by ID
  async findById(id) {
    const query = 'SELECT * FROM consumer_profiles WHERE id = $1';
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update consumer profile
  async update(id, profileData) {
    const {
      address,
      city,
      state,
      zip_code,
      preferences
    } = profileData;
    
    const query = `
      UPDATE consumer_profiles
      SET 
        address = $1,
        city = $2,
        state = $3,
        zip_code = $4,
        preferences = $5,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $6
      RETURNING *
    `;
    
    const values = [
      address,
      city,
      state,
      zip_code,
      preferences,
      id
    ];
    
    try {
      const result = await db.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Update age verification information
  async updateAgeVerification(id, method, date) {
    const query = `
      UPDATE consumer_profiles
      SET 
        age_verification_method = $1,
        age_verification_date = $2,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $3
      RETURNING id, age_verification_method, age_verification_date
    `;
    
    try {
      const result = await db.query(query, [method, date, id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Get consumer with user information
  async getConsumerWithUserInfo(id) {
    const query = `
      SELECT cp.*, u.email, u.first_name, u.last_name, u.phone, u.date_of_birth, u.is_age_verified
      FROM consumer_profiles cp
      JOIN users u ON cp.user_id = u.id
      WHERE cp.id = $1
    `;
    
    try {
      const result = await db.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },
  
  // Get consumers by location (city, state)
  async getByLocation(city, state) {
    const query = `
      SELECT cp.*, u.email, u.first_name, u.last_name
      FROM consumer_profiles cp
      JOIN users u ON cp.user_id = u.id
      WHERE u.is_active = true
      AND (cp.city = $1 OR $1 IS NULL)
      AND (cp.state = $2 OR $2 IS NULL)
      ORDER BY cp.created_at DESC
    `;
    
    try {
      const result = await db.query(query, [city, state]);
      return result.rows;
    } catch (error) {
      throw error;
    }
  }
};

module.exports = ConsumerProfile;
