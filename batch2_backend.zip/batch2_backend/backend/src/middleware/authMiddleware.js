const jwt = require('jsonwebtoken');
const config = require('../config/config');

// Authentication middleware
const authMiddleware = {
  // Verify JWT token
  verifyToken: (req, res, next) => {
    try {
      // Get token from header
      const authHeader = req.headers.authorization;
      if (!authHeader) {
        return res.status(401).json({ message: 'No authorization token provided' });
      }
      
      // Extract token (remove "Bearer " prefix)
      const token = authHeader.split(' ')[1];
      if (!token) {
        return res.status(401).json({ message: 'Invalid token format' });
      }
      
      // Verify token
      jwt.verify(token, config.jwt.secret, (err, decoded) => {
        if (err) {
          return res.status(401).json({ message: 'Invalid or expired token' });
        }
        
        // Add user info to request
        req.user = decoded;
        next();
      });
    } catch (error) {
      console.error('Auth middleware error:', error);
      res.status(500).json({ message: 'Authentication error', error: error.message });
    }
  },
  
  // Check if user is admin
  isAdmin: (req, res, next) => {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied: Admin role required' });
    }
    next();
  },
  
  // Check if user is farmer
  isFarmer: (req, res, next) => {
    if (req.user.role !== 'farmer' && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied: Farmer role required' });
    }
    next();
  },
  
  // Check if user is dispensary
  isDispensary: (req, res, next) => {
    if (req.user.role !== 'dispensary' && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied: Dispensary role required' });
    }
    next();
  },
  
  // Check if user is consumer
  isConsumer: (req, res, next) => {
    if (req.user.role !== 'consumer' && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Access denied: Consumer role required' });
    }
    next();
  },
  
  // Check if user is age verified
  isAgeVerified: (req, res, next) => {
    if (!req.user.is_age_verified && req.user.role === 'consumer') {
      return res.status(403).json({ message: 'Access denied: Age verification required' });
    }
    next();
  }
};

module.exports = authMiddleware;
