require('dotenv').config();
const app = require('./src/app');
const config = require('./src/config/config');

const PORT = config.server.port;

app.listen(PORT, '0.0.0.0', () => {
  console.log(`ZAPPAY API server running on port ${PORT}`);
  console.log(`Environment: ${config.server.env}`);
});
