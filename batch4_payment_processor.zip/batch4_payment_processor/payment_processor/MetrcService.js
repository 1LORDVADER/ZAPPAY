const axios = require('axios');
const config = require('../config/config');
const db = require('../config/database');
const { v4: uuidv4 } = require('uuid');

/**
 * Metrc Integration Service
 * Handles all interactions with the Metrc API for cannabis compliance tracking
 * Implements required endpoints for:
 * - Package tracking
 * - Transfer tracking
 * - Sales reporting
 * - Inventory management
 */
class MetrcService {
  constructor() {
    // Initialize Metrc API client with credentials from config
    this.apiKey = config.metrc.apiKey;
    this.baseUrl = config.metrc.baseUrl;
    this.vendorKey = config.metrc.vendorKey;
    this.userKey = config.metrc.userKey;
    
    // Initialize HTTP client with auth headers
    this.client = axios.create({
      baseURL: this.baseUrl,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${Buffer.from(`${this.vendorKey}:${this.userKey}`).toString('base64')}`
      }
    });
  }
  
  /**
   * Report a sale to Metrc
   * @param {Object} saleData - Sale information
   * @returns {Promise<Object>} Metrc response
   */
  async reportSale(saleData) {
    try {
      console.log('Reporting sale to Metrc:', saleData);
      
      // Format sale data for Metrc API
      const metrcSaleData = this.formatSaleForMetrc(saleData);
      
      // In production, this would make a real API call to Metrc
      // For development, we'll simulate the API call
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Log the simulated API call
      console.log('Metrc API call (simulated):', {
        endpoint: '/sales/v1/receipts',
        method: 'POST',
        data: metrcSaleData
      });
      
      // Generate a mock Metrc receipt ID
      const metrcReceiptId = `METRC-${Date.now()}-${Math.floor(Math.random() * 1000000)}`;
      
      // Store the compliance record in our database
      await this.storeComplianceRecord({
        type: 'sale',
        order_id: saleData.order_id,
        metrc_id: metrcReceiptId,
        data: metrcSaleData,
        status: 'reported'
      });
      
      // Return simulated response
      return {
        success: true,
        metrc_receipt_id: metrcReceiptId,
        message: 'Sale reported to Metrc successfully'
      };
      
      // In production, this would be:
      // const response = await this.client.post('/sales/v1/receipts', metrcSaleData);
      // return response.data;
    } catch (error) {
      console.error('Metrc sale reporting error:', error);
      
      // Store the failed compliance attempt
      await this.storeComplianceRecord({
        type: 'sale',
        order_id: saleData.order_id,
        data: saleData,
        status: 'failed',
        error_message: error.message
      });
      
      throw new Error(`Failed to report sale to Metrc: ${error.message}`);
    }
  }
  
  /**
   * Format sale data for Metrc API
   * @param {Object} saleData - Our internal sale data
   * @returns {Object} Metrc-formatted sale data
   */
  formatSaleForMetrc(saleData) {
    // Extract required fields and format according to Metrc API specs
    return {
      SalesDateTime: new Date().toISOString(),
      SalesCustomerType: "Consumer",
      PatientLicenseNumber: null,
      CaregiverLicenseNumber: null,
      IdentificationMethod: "DriverLicense",
      Packages: saleData.items.map(item => ({
        PackageLabel: item.metrc_package_id,
        Quantity: item.quantity,
        UnitOfMeasure: item.unit,
        TotalAmount: item.price * item.quantity
      })),
      Transactions: saleData.items.map(item => ({
        PackageLabel: item.metrc_package_id,
        Quantity: item.quantity,
        UnitOfMeasure: item.unit,
        TotalAmount: item.price * item.quantity,
        UnitPrice: item.price,
        CategoryName: item.category
      }))
    };
  }
  
  /**
   * Store compliance record in database
   * @param {Object} recordData - Compliance record data
   * @returns {Promise<Object>} Stored record
   */
  async storeComplianceRecord(recordData) {
    try {
      // Generate unique ID for compliance record
      const recordId = uuidv4();
      
      const query = `
        INSERT INTO compliance_records (
          id,
          type,
          order_id,
          metrc_id,
          data,
          status,
          error_message,
          created_at
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
        RETURNING *
      `;
      
      const values = [
        recordId,
        recordData.type,
        recordData.order_id,
        recordData.metrc_id || null,
        JSON.stringify(recordData.data),
        recordData.status,
        recordData.error_message || null
      ];
      
      const result = await db.query(query, values);
      
      return result.rows[0];
    } catch (error) {
      console.error('Error storing compliance record:', error);
      throw new Error(`Failed to store compliance record: ${error.message}`);
    }
  }
  
  /**
   * Get compliance records for an order
   * @param {string} orderId - Order ID
   * @returns {Promise<Array>} Compliance records
   */
  async getComplianceRecordsByOrderId(orderId) {
    try {
      const query = `
        SELECT * FROM compliance_records
        WHERE order_id = $1
        ORDER BY created_at DESC
      `;
      
      const result = await db.query(query, [orderId]);
      
      return result.rows;
    } catch (error) {
      console.error('Error getting compliance records:', error);
      throw new Error(`Failed to get compliance records: ${error.message}`);
    }
  }
  
  /**
   * Verify package in Metrc
   * @param {string} packageId - Metrc package ID
   * @returns {Promise<Object>} Package verification result
   */
  async verifyPackage(packageId) {
    try {
      console.log('Verifying package in Metrc:', packageId);
      
      // In production, this would make a real API call to Metrc
      // For development, we'll simulate the API call
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Log the simulated API call
      console.log('Metrc API call (simulated):', {
        endpoint: `/packages/v1/${packageId}`,
        method: 'GET'
      });
      
      // Return simulated response
      return {
        success: true,
        package_id: packageId,
        quantity: 100,
        unit_of_measure: 'Grams',
        package_type: 'Product',
        product_name: 'Sample Cannabis Product',
        product_category_name: 'Flower',
        is_testing_sample: false,
        is_production_batch: false,
        production_batch_number: null,
        product_requires_remediation: false,
        contains_remediated_product: false,
        remediation_date: null,
        received_testing_state: 'NotSubmitted',
        received_testing_status: 'NotSubmitted',
        is_on_hold: false,
        archived_date: null,
        finished_date: null,
        item: {
          id: 12345,
          name: 'Sample Cannabis Product',
          product_category_type: 'Flower',
          quantity_type: 'WeightBased',
          default_lab_testing_state: 'NotRequired',
          unit_of_measure: 'Grams',
          approval_status: 'Approved',
          strain_id: 6789,
          strain_name: 'Sample Strain'
        },
        lab_testing_state: 'NotRequired',
        lab_testing_status: 'NotSubmitted',
        is_trade_sample: false,
        is_test_sample: false,
        package_state: 'Active',
        source_harvest_names: null,
        source_package_labels: null,
        last_modified: new Date().toISOString()
      };
      
      // In production, this would be:
      // const response = await this.client.get(`/packages/v1/${packageId}`);
      // return response.data;
    } catch (error) {
      console.error('Metrc package verification error:', error);
      throw new Error(`Failed to verify package in Metrc: ${error.message}`);
    }
  }
  
  /**
   * Get active inventory from Metrc
   * @param {Object} filters - Optional filters
   * @returns {Promise<Array>} Active inventory
   */
  async getActiveInventory(filters = {}) {
    try {
      console.log('Getting active inventory from Metrc');
      
      // In production, this would make a real API call to Metrc
      // For development, we'll simulate the API call
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Build query parameters
      let queryParams = '';
      if (filters.lastModifiedStart) {
        queryParams += `lastModifiedStart=${filters.lastModifiedStart}&`;
      }
      if (filters.lastModifiedEnd) {
        queryParams += `lastModifiedEnd=${filters.lastModifiedEnd}&`;
      }
      
      // Log the simulated API call
      console.log('Metrc API call (simulated):', {
        endpoint: `/packages/v1/active?${queryParams}`,
        method: 'GET'
      });
      
      // Return simulated response with 5 sample packages
      return Array(5).fill(0).map((_, index) => ({
        id: 10000 + index,
        label: `METRC-PKG-${10000 + index}`,
        package_type: 'Product',
        source_harvest_names: null,
        quantity: 100 - (index * 10),
        unit_of_measure: 'Grams',
        item: {
          id: 1000 + index,
          name: `Sample Cannabis Product ${index + 1}`,
          product_category_type: index % 2 === 0 ? 'Flower' : 'Concentrate',
          strain_name: `Sample Strain ${index + 1}`
        },
        lab_testing_state: 'Passed',
        is_on_hold: false,
        package_state: 'Active',
        last_modified: new Date().toISOString()
      }));
      
      // In production, this would be:
      // const response = await this.client.get(`/packages/v1/active?${queryParams}`);
      // return response.data;
    } catch (error) {
      console.error('Metrc inventory error:', error);
      throw new Error(`Failed to get inventory from Metrc: ${error.message}`);
    }
  }
  
  /**
   * Sync inventory with Metrc
   * @returns {Promise<Object>} Sync result
   */
  async syncInventory() {
    try {
      console.log('Syncing inventory with Metrc');
      
      // Get active inventory from Metrc
      const metrcInventory = await this.getActiveInventory();
      
      // Update our local inventory with Metrc data
      const syncResults = {
        total: metrcInventory.length,
        updated: 0,
        created: 0,
        errors: 0
      };
      
      for (const item of metrcInventory) {
        try {
          // Check if item exists in our database
          const query = `
            SELECT id FROM products
            WHERE metrc_package_id = $1
          `;
          
          const result = await db.query(query, [item.label]);
          
          if (result.rows.length > 0) {
            // Update existing product
            const updateQuery = `
              UPDATE products
              SET 
                metrc_data = $1,
                quantity = $2,
                last_metrc_sync = NOW()
              WHERE metrc_package_id = $3
              RETURNING id
            `;
            
            await db.query(updateQuery, [
              JSON.stringify(item),
              item.quantity,
              item.label
            ]);
            
            syncResults.updated++;
          } else {
            // Create new product placeholder
            // In a real implementation, this would create a new product or notify admin
            console.log(`New Metrc package found: ${item.label}`);
            syncResults.created++;
          }
        } catch (error) {
          console.error(`Error syncing item ${item.label}:`, error);
          syncResults.errors++;
        }
      }
      
      // Log sync results
      console.log('Inventory sync completed:', syncResults);
      
      return {
        success: true,
        ...syncResults
      };
    } catch (error) {
      console.error('Metrc inventory sync error:', error);
      throw new Error(`Failed to sync inventory with Metrc: ${error.message}`);
    }
  }
  
  /**
   * Verify age and identity compliance
   * @param {Object} userData - User data for verification
   * @returns {Promise<Object>} Verification result
   */
  async verifyAgeAndIdentity(userData) {
    try {
      console.log('Verifying age and identity:', userData);
      
      // In production, this would integrate with ID verification service
      // For development, we'll simulate the verification
      
      // Simulate verification delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Check if user is at least 21 years old
      const birthDate = new Date(userData.date_of_birth);
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      
      const isOver21 = age >= 21;
      
      // Simulate ID verification (in production, this would call a real verification service)
      const idVerified = userData.id_number && userData.id_type;
      
      // Store verification record
      const verificationId = uuidv4();
      const query = `
        INSERT INTO identity_verifications (
          id,
          user_id,
          verification_type,
          id_type,
          id_number,
          date_of_birth,
          age,
          is_over_21,
          is_verified,
          verification_data,
          created_at
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW())
        RETURNING *
      `;
      
      const values = [
        verificationId,
        userData.user_id,
        'age_verification',
        userData.id_type,
        userData.id_number,
        userData.date_of_birth,
        age,
        isOver21,
        idVerified && isOver21,
        JSON.stringify({
          verification_method: 'internal',
          verification_timestamp: new Date().toISOString()
        })
      ];
      
      const result = await db.query(query, values);
      
      return {
        success: idVerified && isOver21,
        verification_id: verificationId,
        is_over_21: isOver21,
        id_verified: idVerified,
        age: age,
        message: idVerified && isOver21 
          ? 'Age and identity verified successfully' 
          : 'Verification failed'
      };
    } catch (error) {
      console.error('Age verification error:', error);
      throw new Error(`Failed to verify age and identity: ${error.message}`);
    }
  }
  
  /**
   * Verify business license
   * @param {Object} licenseData - License data for verification
   * @returns {Promise<Object>} Verification result
   */
  async verifyBusinessLicense(licenseData) {
    try {
      console.log('Verifying business license:', licenseData);
      
      // In production, this would integrate with state license verification API
      // For development, we'll simulate the verification
      
      // Simulate verification delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Check if license is expired
      const expiryDate = new Date(licenseData.expiry_date);
      const today = new Date();
      const isExpired = expiryDate < today;
      
      // Simulate license verification (in production, this would call a real verification service)
      const isValid = !isExpired && licenseData.license_number && licenseData.license_type;
      
      // Store verification record
      const verificationId = uuidv4();
      const query = `
        INSERT INTO license_verifications (
          id,
          user_id,
          license_type,
          license_number,
          license_authority,
          issue_date,
          expiry_date,
          is_expired,
          is_valid,
          verification_data,
          created_at
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW())
        RETURNING *
      `;
      
      const values = [
        verificationId,
        licenseData.user_id,
        licenseData.license_type,
        licenseData.license_number,
        licenseData.license_authority,
        licenseData.issue_date,
        licenseData.expiry_date,
        isExpired,
        isValid,
        JSON.stringify({
          verification_method: 'internal',
          verification_timestamp: new Date().toISOString()
        })
      ];
      
      const result = await db.query(query, values);
      
      return {
        success: isValid,
        verification_id: verificationId,
        is_valid: isValid,
        is_expired: isExpired,
        message: isValid 
          ? 'Business license verified successfully' 
          : isExpired 
            ? 'License is expired' 
            : 'License verification failed'
      };
    } catch (error) {
      console.error('License verification error:', error);
      throw new Error(`Failed to verify business license: ${error.message}`);
    }
  }
  
  /**
   * Generate compliance report
   * @param {Object} filters - Report filters
   * @returns {Promise<Object>} Compliance report
   */
  async generateComplianceReport(filters = {}) {
    try {
      console.log('Generating compliance report with filters:', filters);
      
      // Build WHERE clause based on filters
      let whereClause = '';
      const values = [];
      let valueIndex = 1;
      
      if (filters.start_date) {
        whereClause += whereClause ? ' AND ' : ' WHERE ';
        whereClause += `created_at >= $${valueIndex}`;
        values.push(filters.start_date);
        valueIndex++;
      }
      
      if (filters.end_date) {
        whereClause += whereClause ? ' AND ' : ' WHERE ';
        whereClause += `created_at <= $${valueIndex}`;
        values.push(filters.end_date);
        valueIndex++;
      }
      
      if (filters.type) {
        whereClause += whereClause ? ' AND ' : ' WHERE ';
        whereClause += `type = $${valueIndex}`;
        values.push(filters.type);
        valueIndex++;
      }
      
      if (filters.status) {
        whereClause += whereClause ? ' AND ' : ' WHERE ';
        whereClause += `status = $${valueIndex}`;
        values.push(filters.status);
        valueIndex++;
      }
      
      // Query for compliance records
      const recordsQuery = `
        SELECT * FROM compliance_records
        ${whereClause}
        ORDER BY created_at DESC
        LIMIT $${valueIndex}
      `;
      
      values.push(filters.limit || 100);
      
      const recordsResult = await db.query(recordsQuery, values);
      
      // Query for compliance statistics
      const statsQuery = `
        SELECT
          COUNT(*) as total_records,
          COUNT(CASE WHEN status = 'reported' THEN 1 END) as reported_count,
          COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_count,
          COUNT(CASE WHEN type = 'sale' THEN 1 END) as sales_count,
          COUNT(CASE WHEN type = 'transfer' THEN 1 END) as transfers_count,
          COUNT(CASE WHEN type = 'package' THEN 1 END) as packages_count
        FROM
          compliance_records
        ${whereClause}
      `;
      
      const statsResult = await db.query(statsQuery, values.slice(0, -1));
      
      return {
        records: recordsResult.rows,
        statistics: statsResult.rows[0],
        filters: filters
      };
    } catch (error) {
      console.error('Compliance report error:', error);
      throw new Error(`Failed to generate compliance report: ${error.message}`);
    }
  }
}

module.exports = new MetrcService();
