const db = require('../config/database');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcrypt');
const config = require('../config/config');

/**
 * Payment Processor Service
 * Handles all payment processing functionality including:
 * - Processing ACH payments
 * - Calculating platform fees (5.2%)
 * - Managing payment statuses
 * - Integration with banking partners
 */
class PaymentProcessor {
  /**
   * Process a new payment
   * @param {Object} paymentData - Payment information
   * @param {number} paymentData.amount - Total amount to charge
   * @param {string} paymentData.payment_method - Payment method (ach, cash)
   * @param {Object} paymentData.payment_details - Payment details for ACH
   * @param {number} paymentData.order_id - Associated order ID
   * @param {number} paymentData.user_id - User making the payment
   * @returns {Promise<Object>} Payment record
   */
  async processPayment(paymentData) {
    try {
      // Generate unique payment ID
      const paymentId = uuidv4();
      
      // Calculate platform fee (5.2% of total amount)
      const platformFee = parseFloat((paymentData.amount * 0.052).toFixed(2));
      
      // Calculate amount to farmer (total - platform fee)
      const farmerAmount = parseFloat((paymentData.amount - platformFee).toFixed(2));
      
      // Set initial payment status
      let paymentStatus = 'pending';
      
      // For cash payments, mark as pending until pickup
      if (paymentData.payment_method === 'cash') {
        paymentStatus = 'pending_cash';
      } 
      // For ACH payments, process through banking partner
      else if (paymentData.payment_method === 'ach') {
        // Validate ACH details
        this.validateAchDetails(paymentData.payment_details);
        
        // Process ACH payment through banking partner
        const achResult = await this.processAchPayment(paymentData);
        
        // Update payment status based on ACH result
        paymentStatus = achResult.success ? 'processing' : 'failed';
        
        // Store ACH transaction ID
        paymentData.transaction_id = achResult.transaction_id;
      }
      
      // Create payment record in database
      const query = `
        INSERT INTO payments (
          id, 
          order_id, 
          user_id, 
          amount, 
          platform_fee, 
          farmer_amount, 
          payment_method, 
          payment_details, 
          status, 
          transaction_id, 
          created_at
        ) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW())
        RETURNING *
      `;
      
      const values = [
        paymentId,
        paymentData.order_id,
        paymentData.user_id,
        paymentData.amount,
        platformFee,
        farmerAmount,
        paymentData.payment_method,
        JSON.stringify(this.sanitizePaymentDetails(paymentData.payment_details)),
        paymentStatus,
        paymentData.transaction_id || null
      ];
      
      const result = await db.query(query, values);
      
      // Return the payment record
      return result.rows[0];
    } catch (error) {
      console.error('Payment processing error:', error);
      throw new Error(`Failed to process payment: ${error.message}`);
    }
  }
  
  /**
   * Validate ACH payment details
   * @param {Object} achDetails - ACH payment details
   * @throws {Error} If validation fails
   */
  validateAchDetails(achDetails) {
    if (!achDetails) {
      throw new Error('ACH details are required');
    }
    
    if (!achDetails.account_name) {
      throw new Error('Account name is required');
    }
    
    if (!achDetails.account_number) {
      throw new Error('Account number is required');
    }
    
    if (!achDetails.routing_number) {
      throw new Error('Routing number is required');
    }
    
    // Validate routing number format (9 digits)
    if (!/^\d{9}$/.test(achDetails.routing_number)) {
      throw new Error('Routing number must be 9 digits');
    }
    
    if (!achDetails.account_type || !['checking', 'savings'].includes(achDetails.account_type)) {
      throw new Error('Valid account type (checking or savings) is required');
    }
  }
  
  /**
   * Process ACH payment through banking partner
   * @param {Object} paymentData - Payment data
   * @returns {Promise<Object>} ACH processing result
   */
  async processAchPayment(paymentData) {
    try {
      // In production, this would integrate with a cannabis-friendly banking partner
      // For development, we'll simulate the ACH processing
      
      // Simulate API call to banking partner
      console.log(`Processing ACH payment of $${paymentData.amount} for order ${paymentData.order_id}`);
      
      // Generate a mock transaction ID
      const transactionId = `ACH-${Date.now()}-${Math.floor(Math.random() * 1000000)}`;
      
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Simulate successful ACH processing (in production, this would be a real API call)
      return {
        success: true,
        transaction_id: transactionId,
        message: 'ACH payment initiated successfully'
      };
    } catch (error) {
      console.error('ACH processing error:', error);
      throw new Error(`Failed to process ACH payment: ${error.message}`);
    }
  }
  
  /**
   * Sanitize payment details for storage (mask sensitive information)
   * @param {Object} paymentDetails - Payment details
   * @returns {Object} Sanitized payment details
   */
  sanitizePaymentDetails(paymentDetails) {
    if (!paymentDetails) return null;
    
    // Create a copy to avoid modifying the original
    const sanitized = { ...paymentDetails };
    
    // Mask account number (keep last 4 digits)
    if (sanitized.account_number) {
      const length = sanitized.account_number.length;
      sanitized.account_number = `****${sanitized.account_number.substring(length - 4)}`;
    }
    
    return sanitized;
  }
  
  /**
   * Update payment status
   * @param {string} paymentId - Payment ID
   * @param {string} status - New payment status
   * @param {Object} additionalData - Additional data to update
   * @returns {Promise<Object>} Updated payment record
   */
  async updatePaymentStatus(paymentId, status, additionalData = {}) {
    try {
      // Validate status
      const validStatuses = [
        'pending', 'processing', 'completed', 'failed', 
        'refunded', 'pending_cash', 'cancelled'
      ];
      
      if (!validStatuses.includes(status)) {
        throw new Error(`Invalid payment status: ${status}`);
      }
      
      // Build update query
      let query = `
        UPDATE payments 
        SET status = $1, updated_at = NOW()
      `;
      
      const values = [status];
      let valueIndex = 2;
      
      // Add additional data to update
      if (additionalData) {
        Object.keys(additionalData).forEach(key => {
          query += `, ${key} = $${valueIndex}`;
          values.push(additionalData[key]);
          valueIndex++;
        });
      }
      
      // Complete query
      query += ` WHERE id = $${valueIndex} RETURNING *`;
      values.push(paymentId);
      
      // Execute update
      const result = await db.query(query, values);
      
      if (result.rows.length === 0) {
        throw new Error(`Payment with ID ${paymentId} not found`);
      }
      
      return result.rows[0];
    } catch (error) {
      console.error('Payment status update error:', error);
      throw new Error(`Failed to update payment status: ${error.message}`);
    }
  }
  
  /**
   * Get payment by ID
   * @param {string} paymentId - Payment ID
   * @returns {Promise<Object>} Payment record
   */
  async getPaymentById(paymentId) {
    try {
      const query = 'SELECT * FROM payments WHERE id = $1';
      const result = await db.query(query, [paymentId]);
      
      if (result.rows.length === 0) {
        throw new Error(`Payment with ID ${paymentId} not found`);
      }
      
      return result.rows[0];
    } catch (error) {
      console.error('Get payment error:', error);
      throw new Error(`Failed to get payment: ${error.message}`);
    }
  }
  
  /**
   * Get payments by order ID
   * @param {string} orderId - Order ID
   * @returns {Promise<Array>} Payment records
   */
  async getPaymentsByOrderId(orderId) {
    try {
      const query = 'SELECT * FROM payments WHERE order_id = $1 ORDER BY created_at DESC';
      const result = await db.query(query, [orderId]);
      
      return result.rows;
    } catch (error) {
      console.error('Get payments by order error:', error);
      throw new Error(`Failed to get payments for order: ${error.message}`);
    }
  }
  
  /**
   * Process refund for a payment
   * @param {string} paymentId - Payment ID
   * @param {number} amount - Refund amount (defaults to full payment amount)
   * @param {string} reason - Reason for refund
   * @returns {Promise<Object>} Refund record
   */
  async processRefund(paymentId, amount = null, reason = '') {
    try {
      // Get the original payment
      const payment = await this.getPaymentById(paymentId);
      
      // Only allow refunds for completed payments
      if (payment.status !== 'completed') {
        throw new Error(`Cannot refund payment with status: ${payment.status}`);
      }
      
      // If no amount specified, refund the full amount
      const refundAmount = amount || payment.amount;
      
      // Validate refund amount
      if (refundAmount <= 0 || refundAmount > payment.amount) {
        throw new Error(`Invalid refund amount: ${refundAmount}`);
      }
      
      // Generate refund ID
      const refundId = uuidv4();
      
      // Process refund through banking partner (for ACH payments)
      if (payment.payment_method === 'ach' && payment.transaction_id) {
        // In production, this would call the banking partner's API
        console.log(`Processing refund of $${refundAmount} for payment ${paymentId}`);
        
        // Simulate processing delay
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
      
      // Create refund record
      const query = `
        INSERT INTO refunds (
          id,
          payment_id,
          amount,
          reason,
          status,
          created_at
        )
        VALUES ($1, $2, $3, $4, $5, NOW())
        RETURNING *
      `;
      
      const values = [
        refundId,
        paymentId,
        refundAmount,
        reason,
        'completed'
      ];
      
      const result = await db.query(query, values);
      
      // Update original payment status
      await this.updatePaymentStatus(paymentId, 'refunded', {
        refund_id: refundId,
        refund_amount: refundAmount,
        refund_reason: reason
      });
      
      return result.rows[0];
    } catch (error) {
      console.error('Refund processing error:', error);
      throw new Error(`Failed to process refund: ${error.message}`);
    }
  }
  
  /**
   * Generate payment receipt
   * @param {string} paymentId - Payment ID
   * @returns {Promise<Object>} Receipt data
   */
  async generateReceipt(paymentId) {
    try {
      // Get payment with related order and user information
      const query = `
        SELECT 
          p.*,
          o.items,
          o.subtotal,
          o.excise_tax,
          o.local_tax,
          u.first_name,
          u.last_name,
          u.email
        FROM 
          payments p
        JOIN 
          orders o ON p.order_id = o.id
        JOIN 
          users u ON p.user_id = u.id
        WHERE 
          p.id = $1
      `;
      
      const result = await db.query(query, [paymentId]);
      
      if (result.rows.length === 0) {
        throw new Error(`Payment with ID ${paymentId} not found`);
      }
      
      const payment = result.rows[0];
      
      // Format receipt data
      const receipt = {
        receipt_id: `REC-${payment.id.substring(0, 8)}`,
        payment_id: payment.id,
        order_id: payment.order_id,
        date: new Date(payment.created_at).toISOString(),
        customer: {
          name: `${payment.first_name} ${payment.last_name}`,
          email: payment.email
        },
        items: payment.items,
        payment_method: payment.payment_method,
        payment_status: payment.status,
        subtotal: payment.subtotal,
        excise_tax: payment.excise_tax,
        local_tax: payment.local_tax,
        platform_fee: payment.platform_fee,
        total: payment.amount
      };
      
      return receipt;
    } catch (error) {
      console.error('Receipt generation error:', error);
      throw new Error(`Failed to generate receipt: ${error.message}`);
    }
  }
  
  /**
   * Get payment statistics
   * @param {Object} filters - Optional filters
   * @returns {Promise<Object>} Payment statistics
   */
  async getPaymentStats(filters = {}) {
    try {
      // Build WHERE clause based on filters
      let whereClause = '';
      const values = [];
      let valueIndex = 1;
      
      if (filters.start_date) {
        whereClause += whereClause ? ' AND ' : ' WHERE ';
        whereClause += `created_at >= $${valueIndex}`;
        values.push(filters.start_date);
        valueIndex++;
      }
      
      if (filters.end_date) {
        whereClause += whereClause ? ' AND ' : ' WHERE ';
        whereClause += `created_at <= $${valueIndex}`;
        values.push(filters.end_date);
        valueIndex++;
      }
      
      if (filters.payment_method) {
        whereClause += whereClause ? ' AND ' : ' WHERE ';
        whereClause += `payment_method = $${valueIndex}`;
        values.push(filters.payment_method);
        valueIndex++;
      }
      
      if (filters.status) {
        whereClause += whereClause ? ' AND ' : ' WHERE ';
        whereClause += `status = $${valueIndex}`;
        values.push(filters.status);
        valueIndex++;
      }
      
      // Query for payment statistics
      const query = `
        SELECT
          COUNT(*) as total_payments,
          SUM(amount) as total_amount,
          SUM(platform_fee) as total_platform_fee,
          SUM(farmer_amount) as total_farmer_amount,
          COUNT(CASE WHEN payment_method = 'ach' THEN 1 END) as ach_count,
          COUNT(CASE WHEN payment_method = 'cash' THEN 1 END) as cash_count,
          COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_count,
          COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
          COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_count
        FROM
          payments
        ${whereClause}
      `;
      
      const result = await db.query(query, values);
      
      return result.rows[0];
    } catch (error) {
      console.error('Payment stats error:', error);
      throw new Error(`Failed to get payment statistics: ${error.message}`);
    }
  }
}

module.exports = new PaymentProcessor();
