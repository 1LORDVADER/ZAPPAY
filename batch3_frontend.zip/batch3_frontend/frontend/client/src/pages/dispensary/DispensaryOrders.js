import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Box,
  Paper,
  Divider,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField
} from '@mui/material';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';
import VisibilityIcon from '@mui/icons-material/Visibility';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import PrintIcon from '@mui/icons-material/Print';

const DispensaryOrders = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [processingOrder, setProcessingOrder] = useState(false);
  const [pickupNotes, setPickupNotes] = useState('');
  
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        setLoading(true);
        
        // Build query parameters
        const params = new URLSearchParams();
        if (filter !== 'all') params.append('status', filter);
        
        const response = await axios.get(`/dispensaries/orders?${params.toString()}`);
        setOrders(response.data.orders);
        
        setError(null);
      } catch (err) {
        console.error('Error fetching orders:', err);
        setError('Failed to load orders. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchOrders();
  }, [filter]);
  
  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
  };
  
  const handleViewOrder = (orderId) => {
    navigate(`/dispensary/orders/${orderId}`);
  };
  
  const handleProcessOrder = (order) => {
    setSelectedOrder(order);
    setPickupNotes('');
    setDialogOpen(true);
  };
  
  const handleCloseDialog = () => {
    setDialogOpen(false);
    setSelectedOrder(null);
  };
  
  const handleMarkAsReady = async () => {
    if (!selectedOrder) return;
    
    try {
      setProcessingOrder(true);
      
      await axios.put(`/dispensaries/orders/${selectedOrder.id}/ready`, {
        pickup_notes: pickupNotes
      });
      
      // Update the order in the state
      setOrders(orders.map(order => 
        order.id === selectedOrder.id 
          ? { ...order, status: 'ready_for_pickup', pickup_notes: pickupNotes } 
          : order
      ));
      
      setDialogOpen(false);
      setSelectedOrder(null);
    } catch (err) {
      console.error('Error updating order:', err);
      setError('Failed to update order status. Please try again.');
    } finally {
      setProcessingOrder(false);
    }
  };
  
  const getStatusChip = (status) => {
    let color;
    let label = status.replace(/_/g, ' ');
    
    switch (status) {
      case 'pending':
        color = 'warning';
        break;
      case 'processing':
        color = 'info';
        break;
      case 'ready_for_pickup':
        color = 'success';
        break;
      case 'completed':
        color = 'success';
        break;
      case 'cancelled':
        color = 'error';
        break;
      default:
        color = 'default';
    }
    
    return (
      <Chip 
        label={label.charAt(0).toUpperCase() + label.slice(1)} 
        color={color} 
        size="small" 
      />
    );
  };
  
  if (loading) {
    return (
      <Container sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress />
      </Container>
    );
  }
  
  return (
    <Container>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Manage Orders
        </Typography>
        <Typography variant="body1" color="text.secondary">
          View and process customer orders
        </Typography>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      <Paper sx={{ p: 2, mb: 4 }}>
        <Box sx={{ display: 'flex', overflowX: 'auto', pb: 1 }}>
          <Button 
            variant={filter === 'all' ? 'contained' : 'outlined'} 
            onClick={() => handleFilterChange('all')}
            sx={{ mr: 1, whiteSpace: 'nowrap' }}
          >
            All Orders
          </Button>
          <Button 
            variant={filter === 'pending' ? 'contained' : 'outlined'} 
            onClick={() => handleFilterChange('pending')}
            color="warning"
            sx={{ mr: 1, whiteSpace: 'nowrap' }}
          >
            Pending
          </Button>
          <Button 
            variant={filter === 'processing' ? 'contained' : 'outlined'} 
            onClick={() => handleFilterChange('processing')}
            color="info"
            sx={{ mr: 1, whiteSpace: 'nowrap' }}
          >
            Processing
          </Button>
          <Button 
            variant={filter === 'ready_for_pickup' ? 'contained' : 'outlined'} 
            onClick={() => handleFilterChange('ready_for_pickup')}
            color="success"
            sx={{ mr: 1, whiteSpace: 'nowrap' }}
          >
            Ready for Pickup
          </Button>
          <Button 
            variant={filter === 'completed' ? 'contained' : 'outlined'} 
            onClick={() => handleFilterChange('completed')}
            color="success"
            sx={{ mr: 1, whiteSpace: 'nowrap' }}
          >
            Completed
          </Button>
          <Button 
            variant={filter === 'cancelled' ? 'contained' : 'outlined'} 
            onClick={() => handleFilterChange('cancelled')}
            color="error"
            sx={{ whiteSpace: 'nowrap' }}
          >
            Cancelled
          </Button>
        </Box>
      </Paper>
      
      {orders.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h6" gutterBottom>
            No orders found
          </Typography>
          <Typography variant="body1" color="text.secondary">
            {filter !== 'all' 
              ? `There are no orders with status "${filter.replace('_', ' ')}".` 
              : 'There are no orders in the system yet.'}
          </Typography>
        </Paper>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Order #</TableCell>
                <TableCell>Date</TableCell>
                <TableCell>Customer</TableCell>
                <TableCell>Items</TableCell>
                <TableCell>Total</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {orders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell>#{order.id}</TableCell>
                  <TableCell>{new Date(order.created_at).toLocaleDateString()}</TableCell>
                  <TableCell>{order.customer_name}</TableCell>
                  <TableCell>{order.items.length}</TableCell>
                  <TableCell>${order.total.toFixed(2)}</TableCell>
                  <TableCell>{getStatusChip(order.status)}</TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex' }}>
                      <IconButton 
                        color="primary" 
                        onClick={() => handleViewOrder(order.id)}
                        size="small"
                        title="View Order"
                      >
                        <VisibilityIcon />
                      </IconButton>
                      
                      {order.status === 'pending' && (
                        <IconButton 
                          color="info" 
                          onClick={() => handleProcessOrder(order)}
                          size="small"
                          title="Process Order"
                        >
                          <LocalShippingIcon />
                        </IconButton>
                      )}
                      
                      {(order.status === 'ready_for_pickup' || order.status === 'completed') && (
                        <IconButton 
                          color="default" 
                          size="small"
                          title="Print Receipt"
                        >
                          <PrintIcon />
                        </IconButton>
                      )}
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
      
      <Dialog open={dialogOpen} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle>Process Order #{selectedOrder?.id}</DialogTitle>
        <DialogContent>
          {selectedOrder && (
            <>
              <Box sx={{ mb: 3 }}>
                <Typography variant="subtitle1" gutterBottom>
                  Order Details
                </Typography>
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Customer
                    </Typography>
                    <Typography variant="body1">
                      {selectedOrder.customer_name}
                    </Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Date
                    </Typography>
                    <Typography variant="body1">
                      {new Date(selectedOrder.created_at).toLocaleDateString()}
                    </Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Total
                    </Typography>
                    <Typography variant="body1">
                      ${selectedOrder.total.toFixed(2)}
                    </Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography variant="body2" color="text.secondary">
                      Payment Method
                    </Typography>
                    <Typography variant="body1">
                      {selectedOrder.payment_method === 'ach' ? 'ACH Bank Transfer' : 'Cash on Pickup'}
                    </Typography>
                  </Grid>
                </Grid>
              </Box>
              
              <Typography variant="subtitle1" gutterBottom>
                Items
              </Typography>
              <TableContainer component={Paper} variant="outlined" sx={{ mb: 3 }}>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Product</TableCell>
                      <TableCell>Quantity</TableCell>
                      <TableCell align="right">Price</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {selectedOrder.items.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>{item.product_name}</TableCell>
                        <TableCell>{item.quantity} {item.unit}</TableCell>
                        <TableCell align="right">${item.subtotal.toFixed(2)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
              
              <TextField
                fullWidth
                label="Pickup Notes (Optional)"
                multiline
                rows={3}
                value={pickupNotes}
                onChange={(e) => setPickupNotes(e.target.value)}
                placeholder="Add any special instructions for customer pickup"
                variant="outlined"
              />
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button 
            onClick={handleMarkAsReady} 
            variant="contained" 
            color="primary"
            disabled={processingOrder}
            startIcon={<CheckCircleIcon />}
          >
            {processingOrder ? 'Processing...' : 'Mark as Ready for Pickup'}
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default DispensaryOrders;
