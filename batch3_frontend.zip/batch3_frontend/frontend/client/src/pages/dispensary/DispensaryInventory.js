import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Box,
  Paper,
  Divider,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';
import VisibilityIcon from '@mui/icons-material/Visibility';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';

const DispensaryInventory = () => {
  const { user } = useAuth();
  const [inventory, setInventory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState({
    category: '',
    strain_type: '',
    farmer: '',
    status: 'active'
  });
  
  // Categories and strain types for filters
  const categories = ['Flower', 'Edibles', 'Concentrates', 'Pre-rolls', 'Vapes', 'Tinctures', 'Topicals'];
  const strainTypes = ['Indica', 'Sativa', 'Hybrid', 'CBD'];
  const [farmers, setFarmers] = useState([]);
  
  useEffect(() => {
    const fetchInventory = async () => {
      try {
        setLoading(true);
        
        // Build query parameters
        const params = new URLSearchParams();
        if (filter.category) params.append('category', filter.category);
        if (filter.strain_type) params.append('strain_type', filter.strain_type);
        if (filter.farmer) params.append('farmer_id', filter.farmer);
        if (filter.status) params.append('status', filter.status);
        
        const response = await axios.get(`/dispensaries/inventory?${params.toString()}`);
        setInventory(response.data.inventory);
        
        // Get unique farmers from inventory
        const uniqueFarmers = [...new Set(response.data.inventory.map(item => item.farmer_id))];
        const farmerDetails = uniqueFarmers.map(farmerId => {
          const item = response.data.inventory.find(i => i.farmer_id === farmerId);
          return {
            id: farmerId,
            name: item.farmer_name
          };
        });
        setFarmers(farmerDetails);
        
        setError(null);
      } catch (err) {
        console.error('Error fetching inventory:', err);
        setError('Failed to load inventory. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchInventory();
  }, [filter]);
  
  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilter(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleUpdateInventory = async (productId, field, value) => {
    try {
      await axios.put(`/dispensaries/inventory/${productId}`, {
        [field]: value
      });
      
      // Update the inventory item in the state
      setInventory(inventory.map(item => 
        item.id === productId 
          ? { ...item, [field]: value } 
          : item
      ));
    } catch (err) {
      console.error('Error updating inventory:', err);
      setError('Failed to update inventory. Please try again.');
    }
  };
  
  const handleRemoveFromInventory = async (productId) => {
    if (window.confirm('Are you sure you want to remove this product from your inventory?')) {
      try {
        await axios.delete(`/dispensaries/inventory/${productId}`);
        
        // Remove the product from the state
        setInventory(inventory.filter(item => item.id !== productId));
      } catch (err) {
        console.error('Error removing product:', err);
        setError('Failed to remove product. Please try again.');
      }
    }
  };
  
  const getStockLevelChip = (quantity) => {
    let color;
    let label;
    
    if (quantity <= 0) {
      color = 'error';
      label = 'Out of Stock';
    } else if (quantity < 10) {
      color = 'warning';
      label = 'Low Stock';
    } else {
      color = 'success';
      label = 'In Stock';
    }
    
    return (
      <Chip 
        label={label} 
        color={color} 
        size="small" 
      />
    );
  };
  
  if (loading) {
    return (
      <Container sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress />
      </Container>
    );
  }
  
  return (
    <Container>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h4" component="h1">
          Inventory Management
        </Typography>
        <Button 
          variant="contained" 
          color="primary"
          startIcon={<AddIcon />}
          component={RouterLink}
          to="/dispensary/inventory/add"
        >
          Add New Products
        </Button>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      <Paper sx={{ p: 3, mb: 4 }}>
        <Typography variant="h6" gutterBottom>
          Filter Inventory
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6} md={3}>
            <FormControl fullWidth>
              <InputLabel id="category-label">Category</InputLabel>
              <Select
                labelId="category-label"
                id="category"
                name="category"
                value={filter.category}
                label="Category"
                onChange={handleFilterChange}
              >
                <MenuItem value="">All Categories</MenuItem>
                {categories.map((category) => (
                  <MenuItem key={category} value={category}>{category}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <FormControl fullWidth>
              <InputLabel id="strain-type-label">Strain Type</InputLabel>
              <Select
                labelId="strain-type-label"
                id="strain_type"
                name="strain_type"
                value={filter.strain_type}
                label="Strain Type"
                onChange={handleFilterChange}
              >
                <MenuItem value="">All Strain Types</MenuItem>
                {strainTypes.map((type) => (
                  <MenuItem key={type} value={type}>{type}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <FormControl fullWidth>
              <InputLabel id="farmer-label">Farmer</InputLabel>
              <Select
                labelId="farmer-label"
                id="farmer"
                name="farmer"
                value={filter.farmer}
                label="Farmer"
                onChange={handleFilterChange}
              >
                <MenuItem value="">All Farmers</MenuItem>
                {farmers.map((farmer) => (
                  <MenuItem key={farmer.id} value={farmer.id}>{farmer.name}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <FormControl fullWidth>
              <InputLabel id="status-label">Status</InputLabel>
              <Select
                labelId="status-label"
                id="status"
                name="status"
                value={filter.status}
                label="Status"
                onChange={handleFilterChange}
              >
                <MenuItem value="active">Active</MenuItem>
                <MenuItem value="inactive">Inactive</MenuItem>
                <MenuItem value="all">All</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
      </Paper>
      
      {inventory.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h6" gutterBottom>
            No products found
          </Typography>
          <Typography variant="body1" color="text.secondary" paragraph>
            {filter.category || filter.strain_type || filter.farmer || filter.status !== 'active' 
              ? 'Try adjusting your filters or add new products to your inventory.'
              : 'Get started by adding products to your inventory.'}
          </Typography>
          <Button 
            variant="contained" 
            color="primary"
            startIcon={<AddIcon />}
            component={RouterLink}
            to="/dispensary/inventory/add"
          >
            Add New Products
          </Button>
        </Paper>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Product</TableCell>
                <TableCell>Farmer</TableCell>
                <TableCell>Category</TableCell>
                <TableCell>Retail Price</TableCell>
                <TableCell>Quantity</TableCell>
                <TableCell>Stock Level</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {inventory.map((item) => (
                <TableRow key={item.id}>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      {item.images?.[0] && (
                        <Box 
                          component="img" 
                          src={item.images[0]} 
                          alt={item.name}
                          sx={{ width: 50, height: 50, mr: 2, objectFit: 'cover' }}
                        />
                      )}
                      <Box>
                        <Typography variant="subtitle2">{item.name}</Typography>
                        <Typography variant="body2" color="text.secondary">
                          {item.strain_type} • THC: {item.thc_content}%
                        </Typography>
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell>{item.farmer_name}</TableCell>
                  <TableCell>{item.category}</TableCell>
                  <TableCell>
                    <TextField
                      size="small"
                      value={item.retail_price}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (!isNaN(value) && value >= 0) {
                          handleUpdateInventory(item.id, 'retail_price', value);
                        }
                      }}
                      InputProps={{
                        startAdornment: <Box component="span" sx={{ mr: 0.5 }}>$</Box>,
                      }}
                      sx={{ width: '100px' }}
                    />
                  </TableCell>
                  <TableCell>
                    <TextField
                      size="small"
                      value={item.quantity}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (!isNaN(value) && value >= 0) {
                          handleUpdateInventory(item.id, 'quantity', value);
                        }
                      }}
                      InputProps={{
                        endAdornment: <Box component="span" sx={{ ml: 0.5 }}>{item.unit}s</Box>,
                      }}
                      sx={{ width: '100px' }}
                    />
                  </TableCell>
                  <TableCell>{getStockLevelChip(item.quantity)}</TableCell>
                  <TableCell>
                    <FormControl size="small" sx={{ minWidth: 120 }}>
                      <Select
                        value={item.status}
                        onChange={(e) => handleUpdateInventory(item.id, 'status', e.target.value)}
                      >
                        <MenuItem value="active">Active</MenuItem>
                        <MenuItem value="inactive">Inactive</MenuItem>
                      </Select>
                    </FormControl>
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: 'flex' }}>
                      <IconButton 
                        color="primary" 
                        component={RouterLink}
                        to={`/dispensary/inventory/${item.id}`}
                        size="small"
                        title="View Details"
                      >
                        <VisibilityIcon />
                      </IconButton>
                      <IconButton 
                        color="error" 
                        onClick={() => handleRemoveFromInventory(item.id)}
                        size="small"
                        title="Remove from Inventory"
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Container>
  );
};

export default DispensaryInventory;
