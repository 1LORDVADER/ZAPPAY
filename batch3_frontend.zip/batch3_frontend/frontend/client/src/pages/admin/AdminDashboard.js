import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Box,
  Paper,
  Divider,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  List,
  ListItem,
  ListItemText,
  ListItemIcon
} from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';
import DashboardIcon from '@mui/icons-material/Dashboard';
import PeopleIcon from '@mui/icons-material/People';
import InventoryIcon from '@mui/icons-material/Inventory';
import ReceiptIcon from '@mui/icons-material/Receipt';
import SecurityIcon from '@mui/icons-material/Security';
import SettingsIcon from '@mui/icons-material/Settings';
import BarChartIcon from '@mui/icons-material/BarChart';
import HelpIcon from '@mui/icons-material/Help';

const AdminDashboard = () => {
  const { user } = useAuth();
  const [dashboardData, setDashboardData] = useState({
    stats: {
      totalUsers: 0,
      totalFarmers: 0,
      totalDispensaries: 0,
      totalConsumers: 0,
      totalProducts: 0,
      totalOrders: 0,
      totalSales: 0,
      pendingVerifications: 0
    },
    recentUsers: [],
    recentOrders: []
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Fetch dashboard data
        const response = await axios.get('/admin/dashboard');
        setDashboardData(response.data);
        
        setError(null);
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Failed to load dashboard data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);
  
  if (loading) {
    return (
      <Container sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress />
      </Container>
    );
  }
  
  return (
    <Box sx={{ display: 'flex' }}>
      {/* Admin Sidebar */}
      <Box
        component="nav"
        sx={{
          width: { sm: 240 },
          flexShrink: 0,
          bgcolor: 'background.paper',
          borderRight: 1,
          borderColor: 'divider',
          height: '100vh',
          position: 'fixed'
        }}
      >
        <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
          <Typography variant="h6" component="div" sx={{ fontWeight: 'bold' }}>
            ZAPPAY
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Admin Panel
          </Typography>
        </Box>
        
        <List component="nav">
          <ListItem button component={RouterLink} to="/admin/dashboard" selected>
            <ListItemIcon>
              <DashboardIcon />
            </ListItemIcon>
            <ListItemText primary="Dashboard" />
          </ListItem>
          
          <ListItem button component={RouterLink} to="/admin/users">
            <ListItemIcon>
              <PeopleIcon />
            </ListItemIcon>
            <ListItemText primary="User Management" />
          </ListItem>
          
          <ListItem button component={RouterLink} to="/admin/products">
            <ListItemIcon>
              <InventoryIcon />
            </ListItemIcon>
            <ListItemText primary="Products" />
          </ListItem>
          
          <ListItem button component={RouterLink} to="/admin/orders">
            <ListItemIcon>
              <ReceiptIcon />
            </ListItemIcon>
            <ListItemText primary="Orders" />
          </ListItem>
          
          <ListItem button component={RouterLink} to="/admin/compliance">
            <ListItemIcon>
              <SecurityIcon />
            </ListItemIcon>
            <ListItemText primary="Compliance" />
          </ListItem>
          
          <ListItem button component={RouterLink} to="/admin/reports">
            <ListItemIcon>
              <BarChartIcon />
            </ListItemIcon>
            <ListItemText primary="Reports" />
          </ListItem>
          
          <Divider sx={{ my: 1 }} />
          
          <ListItem button component={RouterLink} to="/admin/settings">
            <ListItemIcon>
              <SettingsIcon />
            </ListItemIcon>
            <ListItemText primary="Settings" />
          </ListItem>
          
          <ListItem button component={RouterLink} to="/admin/help">
            <ListItemIcon>
              <HelpIcon />
            </ListItemIcon>
            <ListItemText primary="Help & Support" />
          </ListItem>
        </List>
      </Box>
      
      {/* Main Content */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          ml: { sm: '240px' },
          bgcolor: '#f5f5f5',
          minHeight: '100vh'
        }}
      >
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" component="h1" gutterBottom>
            Admin Dashboard
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Welcome back, {user?.first_name || 'Admin'}! Here's an overview of your platform.
          </Typography>
        </Box>
        
        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}
        
        <Grid container spacing={3} sx={{ mb: 4 }}>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Typography variant="h6" color="text.secondary" gutterBottom>
                  Total Users
                </Typography>
                <Typography variant="h4" component="div">
                  {dashboardData.stats.totalUsers}
                </Typography>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
                  <Typography variant="body2" color="text.secondary">
                    Farmers: {dashboardData.stats.totalFarmers}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Dispensaries: {dashboardData.stats.totalDispensaries}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Consumers: {dashboardData.stats.totalConsumers}
                  </Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Typography variant="h6" color="text.secondary" gutterBottom>
                  Total Products
                </Typography>
                <Typography variant="h4" component="div">
                  {dashboardData.stats.totalProducts}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                  Active product listings
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Typography variant="h6" color="text.secondary" gutterBottom>
                  Total Orders
                </Typography>
                <Typography variant="h4" component="div">
                  {dashboardData.stats.totalOrders}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                  Processed through platform
                </Typography>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Card sx={{ height: '100%' }}>
              <CardContent>
                <Typography variant="h6" color="text.secondary" gutterBottom>
                  Total Sales
                </Typography>
                <Typography variant="h4" component="div">
                  ${dashboardData.stats.totalSales.toFixed(2)}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                  Platform revenue: ${(dashboardData.stats.totalSales * 0.052).toFixed(2)}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
        
        <Grid container spacing={4}>
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 3, mb: 4 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">Recent Users</Typography>
                <Button 
                  component={RouterLink} 
                  to="/admin/users" 
                  color="primary"
                >
                  View All
                </Button>
              </Box>
              <Divider sx={{ mb: 2 }} />
              
              {dashboardData.recentUsers.length > 0 ? (
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>User</TableCell>
                        <TableCell>Type</TableCell>
                        <TableCell>Joined</TableCell>
                        <TableCell>Status</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {dashboardData.recentUsers.map((user) => (
                        <TableRow 
                          key={user.id}
                          hover
                          component={RouterLink}
                          to={`/admin/users/${user.id}`}
                          sx={{ 
                            textDecoration: 'none',
                            '&:hover': { cursor: 'pointer' }
                          }}
                        >
                          <TableCell>
                            <Box>
                              <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                                {user.first_name} {user.last_name}
                              </Typography>
                              <Typography variant="body2" color="text.secondary">
                                {user.email}
                              </Typography>
                            </Box>
                          </TableCell>
                          <TableCell>
                            <Chip 
                              label={user.role} 
                              color={
                                user.role === 'farmer' ? 'success' :
                                user.role === 'dispensary' ? 'info' :
                                user.role === 'consumer' ? 'default' :
                                'primary'
                              }
                              size="small"
                            />
                          </TableCell>
                          <TableCell>{new Date(user.created_at).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <Chip 
                              label={user.status} 
                              color={
                                user.status === 'active' ? 'success' :
                                user.status === 'pending' ? 'warning' :
                                user.status === 'suspended' ? 'error' :
                                'default'
                              }
                              size="small"
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              ) : (
                <Box sx={{ textAlign: 'center', py: 4 }}>
                  <Typography variant="body1" color="text.secondary">
                    No recent users found.
                  </Typography>
                </Box>
              )}
            </Paper>
            
            <Paper sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">Pending Verifications</Typography>
                <Chip 
                  label={dashboardData.stats.pendingVerifications} 
                  color={dashboardData.stats.pendingVerifications > 0 ? 'warning' : 'success'}
                />
              </Box>
              <Divider sx={{ mb: 2 }} />
              
              {dashboardData.stats.pendingVerifications > 0 ? (
                <Box>
                  <Typography variant="body1" paragraph>
                    There are {dashboardData.stats.pendingVerifications} users waiting for verification.
                  </Typography>
                  <Button 
                    variant="contained" 
                    color="primary"
                    component={RouterLink}
                    to="/admin/verifications"
                  >
                    Review Verifications
                  </Button>
                </Box>
              ) : (
                <Box sx={{ textAlign: 'center', py: 2 }}>
                  <Typography variant="body1" color="text.secondary">
                    No pending verifications.
                  </Typography>
                </Box>
              )}
            </Paper>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 3, mb: 4 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">Recent Orders</Typography>
                <Button 
                  component={RouterLink} 
                  to="/admin/orders" 
                  color="primary"
                >
                  View All
                </Button>
              </Box>
              <Divider sx={{ mb: 2 }} />
              
              {dashboardData.recentOrders.length > 0 ? (
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>Order #</TableCell>
                        <TableCell>Date</TableCell>
                        <TableCell>Customer</TableCell>
                        <TableCell>Amount</TableCell>
                        <TableCell>Status</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {dashboardData.recentOrders.map((order) => (
                        <TableRow 
                          key={order.id}
                          hover
                          component={RouterLink}
                          to={`/admin/orders/${order.id}`}
                          sx={{ 
                            textDecoration: 'none',
                            '&:hover': { cursor: 'pointer' }
                          }}
                        >
                          <TableCell>#{order.id}</TableCell>
                          <TableCell>{new Date(order.created_at).toLocaleDateString()}</TableCell>
                          <TableCell>{order.customer_name}</TableCell>
                          <TableCell>${order.total.toFixed(2)}</TableCell>
                          <TableCell>
                            <Chip 
                              label={order.status.replace('_', ' ')} 
                              color={
                                order.status === 'completed' ? 'success' :
                                order.status === 'ready_for_pickup' ? 'success' :
                                order.status === 'processing' ? 'info' :
                                order.status === 'pending' ? 'warning' :
                                'default'
                              }
                              size="small"
                            />
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              ) : (
                <Box sx={{ textAlign: 'center', py: 4 }}>
                  <Typography variant="body1" color="text.secondary">
                    No recent orders found.
                  </Typography>
                </Box>
              )}
            </Paper>
            
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Quick Actions
              </Typography>
              <Divider sx={{ mb: 2 }} />
              
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <Button 
                    variant="contained" 
                    color="primary"
                    fullWidth
                    component={RouterLink}
                    to="/admin/users/add"
                  >
                    Add New User
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Button 
                    variant="outlined"
                    fullWidth
                    component={RouterLink}
                    to="/admin/reports/generate"
                  >
                    Generate Report
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Button 
                    variant="outlined"
                    fullWidth
                    component={RouterLink}
                    to="/admin/compliance/audit"
                  >
                    Run Compliance Audit
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Button 
                    variant="outlined"
                    fullWidth
                    component={RouterLink}
                    to="/admin/settings"
                  >
                    System Settings
                  </Button>
                </Grid>
              </Grid>
            </Paper>
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
};

export default AdminDashboard;
