import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Box,
  Paper,
  Divider,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from '@mui/material';
import { Link as RouterLink, useParams } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import WarningIcon from '@mui/icons-material/Warning';
import ReceiptIcon from '@mui/icons-material/Receipt';

const AdminComplianceVerification = () => {
  const { user } = useAuth();
  const [verifications, setVerifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState({
    type: '',
    status: 'pending'
  });
  const [selectedVerification, setSelectedVerification] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [processingVerification, setProcessingVerification] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  
  useEffect(() => {
    const fetchVerifications = async () => {
      try {
        setLoading(true);
        
        // Build query parameters
        const params = new URLSearchParams();
        if (filter.type) params.append('type', filter.type);
        if (filter.status) params.append('status', filter.status);
        
        const response = await axios.get(`/admin/compliance/verifications?${params.toString()}`);
        setVerifications(response.data.verifications);
        
        setError(null);
      } catch (err) {
        console.error('Error fetching verifications:', err);
        setError('Failed to load verification data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchVerifications();
  }, [filter]);
  
  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilter(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleViewVerification = (verification) => {
    setSelectedVerification(verification);
    setRejectionReason('');
    setDialogOpen(true);
  };
  
  const handleCloseDialog = () => {
    setDialogOpen(false);
    setSelectedVerification(null);
  };
  
  const handleApproveVerification = async () => {
    if (!selectedVerification) return;
    
    try {
      setProcessingVerification(true);
      
      await axios.put(`/admin/compliance/verifications/${selectedVerification.id}/approve`);
      
      // Update the verification in the state
      setVerifications(verifications.map(v => 
        v.id === selectedVerification.id 
          ? { ...v, status: 'approved', verified_at: new Date().toISOString(), verified_by: user.id } 
          : v
      ));
      
      setDialogOpen(false);
      setSelectedVerification(null);
    } catch (err) {
      console.error('Error approving verification:', err);
      setError('Failed to approve verification. Please try again.');
    } finally {
      setProcessingVerification(false);
    }
  };
  
  const handleRejectVerification = async () => {
    if (!selectedVerification || !rejectionReason) return;
    
    try {
      setProcessingVerification(true);
      
      await axios.put(`/admin/compliance/verifications/${selectedVerification.id}/reject`, {
        rejection_reason: rejectionReason
      });
      
      // Update the verification in the state
      setVerifications(verifications.map(v => 
        v.id === selectedVerification.id 
          ? { 
              ...v, 
              status: 'rejected', 
              rejected_at: new Date().toISOString(), 
              rejected_by: user.id,
              rejection_reason: rejectionReason
            } 
          : v
      ));
      
      setDialogOpen(false);
      setSelectedVerification(null);
    } catch (err) {
      console.error('Error rejecting verification:', err);
      setError('Failed to reject verification. Please try again.');
    } finally {
      setProcessingVerification(false);
    }
  };
  
  const getStatusChip = (status) => {
    let color;
    let icon;
    
    switch (status) {
      case 'pending':
        color = 'warning';
        icon = <WarningIcon fontSize="small" />;
        break;
      case 'approved':
        color = 'success';
        icon = <CheckCircleIcon fontSize="small" />;
        break;
      case 'rejected':
        color = 'error';
        icon = <CancelIcon fontSize="small" />;
        break;
      default:
        color = 'default';
        icon = null;
    }
    
    return (
      <Chip 
        label={status.charAt(0).toUpperCase() + status.slice(1)} 
        color={color} 
        size="small" 
        icon={icon}
      />
    );
  };
  
  if (loading) {
    return (
      <Container sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress />
      </Container>
    );
  }
  
  return (
    <Box
      component="main"
      sx={{
        flexGrow: 1,
        p: 3,
        ml: { sm: '240px' },
        bgcolor: '#f5f5f5',
        minHeight: '100vh'
      }}
    >
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Compliance Verifications
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Review and process license and identity verification requests
        </Typography>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      <Paper sx={{ p: 3, mb: 4 }}>
        <Typography variant="h6" gutterBottom>
          Filter Verifications
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel id="type-label">User Type</InputLabel>
              <Select
                labelId="type-label"
                id="type"
                name="type"
                value={filter.type}
                label="User Type"
                onChange={handleFilterChange}
              >
                <MenuItem value="">All Types</MenuItem>
                <MenuItem value="farmer">Farmers</MenuItem>
                <MenuItem value="dispensary">Dispensaries</MenuItem>
                <MenuItem value="consumer">Consumers</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel id="status-label">Status</InputLabel>
              <Select
                labelId="status-label"
                id="status"
                name="status"
                value={filter.status}
                label="Status"
                onChange={handleFilterChange}
              >
                <MenuItem value="">All Statuses</MenuItem>
                <MenuItem value="pending">Pending</MenuItem>
                <MenuItem value="approved">Approved</MenuItem>
                <MenuItem value="rejected">Rejected</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
      </Paper>
      
      {verifications.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h6" gutterBottom>
            No verifications found
          </Typography>
          <Typography variant="body1" color="text.secondary">
            {filter.type || filter.status 
              ? 'Try adjusting your filters to see more results.'
              : 'There are no verification requests in the system.'}
          </Typography>
        </Paper>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>User</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Verification Type</TableCell>
                <TableCell>Submitted</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {verifications.map((verification) => (
                <TableRow key={verification.id}>
                  <TableCell>
                    <Box>
                      <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                        {verification.user_name}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {verification.user_email}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Chip 
                      label={verification.user_type} 
                      color={
                        verification.user_type === 'farmer' ? 'success' :
                        verification.user_type === 'dispensary' ? 'info' :
                        'default'
                      }
                      size="small"
                    />
                  </TableCell>
                  <TableCell>{verification.verification_type}</TableCell>
                  <TableCell>{new Date(verification.created_at).toLocaleDateString()}</TableCell>
                  <TableCell>{getStatusChip(verification.status)}</TableCell>
                  <TableCell>
                    <Button 
                      variant="outlined" 
                      size="small"
                      onClick={() => handleViewVerification(verification)}
                    >
                      Review
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
      
      <Dialog open={dialogOpen} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        {selectedVerification && (
          <>
            <DialogTitle>
              Review {selectedVerification.verification_type} Verification
            </DialogTitle>
            <DialogContent>
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Box sx={{ mb: 3 }}>
                    <Typography variant="subtitle1" gutterBottom>
                      User Information
                    </Typography>
                    <Paper variant="outlined" sx={{ p: 2 }}>
                      <Grid container spacing={2}>
                        <Grid item xs={6}>
                          <Typography variant="body2" color="text.secondary">
                            Name
                          </Typography>
                          <Typography variant="body1">
                            {selectedVerification.user_name}
                          </Typography>
                        </Grid>
                        <Grid item xs={6}>
                          <Typography variant="body2" color="text.secondary">
                            Email
                          </Typography>
                          <Typography variant="body1">
                            {selectedVerification.user_email}
                          </Typography>
                        </Grid>
                        <Grid item xs={6}>
                          <Typography variant="body2" color="text.secondary">
                            User Type
                          </Typography>
                          <Typography variant="body1">
                            {selectedVerification.user_type.charAt(0).toUpperCase() + selectedVerification.user_type.slice(1)}
                          </Typography>
                        </Grid>
                        <Grid item xs={6}>
                          <Typography variant="body2" color="text.secondary">
                            Joined
                          </Typography>
                          <Typography variant="body1">
                            {new Date(selectedVerification.user_created_at).toLocaleDateString()}
                          </Typography>
                        </Grid>
                      </Grid>
                    </Paper>
                  </Box>
                  
                  {selectedVerification.verification_type === 'license' && (
                    <Box sx={{ mb: 3 }}>
                      <Typography variant="subtitle1" gutterBottom>
                        License Information
                      </Typography>
                      <Paper variant="outlined" sx={{ p: 2 }}>
                        <Grid container spacing={2}>
                          <Grid item xs={6}>
                            <Typography variant="body2" color="text.secondary">
                              License Number
                            </Typography>
                            <Typography variant="body1">
                              {selectedVerification.license_number}
                            </Typography>
                          </Grid>
                          <Grid item xs={6}>
                            <Typography variant="body2" color="text.secondary">
                              License Type
                            </Typography>
                            <Typography variant="body1">
                              {selectedVerification.license_type}
                            </Typography>
                          </Grid>
                          <Grid item xs={6}>
                            <Typography variant="body2" color="text.secondary">
                              Issue Date
                            </Typography>
                            <Typography variant="body1">
                              {new Date(selectedVerification.license_issue_date).toLocaleDateString()}
                            </Typography>
                          </Grid>
                          <Grid item xs={6}>
                            <Typography variant="body2" color="text.secondary">
                              Expiration Date
                            </Typography>
                            <Typography variant="body1">
                              {new Date(selectedVerification.license_expiry_date).toLocaleDateString()}
                            </Typography>
                          </Grid>
                          <Grid item xs={12}>
                            <Typography variant="body2" color="text.secondary">
                              Issuing Authority
                            </Typography>
                            <Typography variant="body1">
                              {selectedVerification.license_authority}
                            </Typography>
                          </Grid>
                        </Grid>
                      </Paper>
                    </Box>
                  )}
                  
                  {selectedVerification.verification_type === 'identity' && (
                    <Box sx={{ mb: 3 }}>
                      <Typography variant="subtitle1" gutterBottom>
                        Identity Information
                      </Typography>
                      <Paper variant="outlined" sx={{ p: 2 }}>
                        <Grid container spacing={2}>
                          <Grid item xs={6}>
                            <Typography variant="body2" color="text.secondary">
                              ID Type
                            </Typography>
                            <Typography variant="body1">
                              {selectedVerification.id_type}
                            </Typography>
                          </Grid>
                          <Grid item xs={6}>
                            <Typography variant="body2" color="text.secondary">
                              ID Number
                            </Typography>
                            <Typography variant="body1">
                              {selectedVerification.id_number}
                            </Typography>
                          </Grid>
                          <Grid item xs={6}>
                            <Typography variant="body2" color="text.secondary">
                              Date of Birth
                            </Typography>
                            <Typography variant="body1">
                              {new Date(selectedVerification.date_of_birth).toLocaleDateString()}
                            </Typography>
                          </Grid>
                          <Grid item xs={6}>
                            <Typography variant="body2" color="text.secondary">
                              Age
                            </Typography>
                            <Typography variant="body1">
                              {selectedVerification.age} years
                            </Typography>
                          </Grid>
                        </Grid>
                      </Paper>
                    </Box>
                  )}
                  
                  {selectedVerification.status === 'rejected' && (
                    <Box sx={{ mb: 3 }}>
                      <Typography variant="subtitle1" gutterBottom>
                        Rejection Information
                      </Typography>
                      <Paper variant="outlined" sx={{ p: 2 }}>
                        <Grid container spacing={2}>
                          <Grid item xs={12}>
                            <Typography variant="body2" color="text.secondary">
                              Rejected By
                            </Typography>
                            <Typography variant="body1">
                              {selectedVerification.rejected_by_name}
                            </Typography>
                          </Grid>
                          <Grid item xs={12}>
                            <Typography variant="body2" color="text.secondary">
                              Rejected On
                            </Typography>
                            <Typography variant="body1">
                              {new Date(selectedVerification.rejected_at).toLocaleString()}
                            </Typography>
                          </Grid>
                          <Grid item xs={12}>
                            <Typography variant="body2" color="text.secondary">
                              Reason
                            </Typography>
                            <Typography variant="body1">
                              {selectedVerification.rejection_reason}
                            </Typography>
                          </Grid>
                        </Grid>
                      </Paper>
                    </Box>
                  )}
                </Grid>
                
                <Grid item xs={12} md={6}>
                  <Typography variant="subtitle1" gutterBottom>
                    Verification Documents
                  </Typography>
                  
                  {selectedVerification.documents.map((doc, index) => (
                    <Box key={index} sx={{ mb: 2 }}>
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        {doc.type}
                      </Typography>
                      <Box 
                        component="img"
                        src={doc.url}
                        alt={doc.type}
                        sx={{ 
                          width: '100%', 
                          maxHeight: '300px',
                          objectFit: 'contain',
                          border: '1px solid #eee',
                          borderRadius: 1
                        }}
                      />
                    </Box>
                  ))}
                  
                  {selectedVerification.status === 'pending' && (
                    <Box sx={{ mt: 3 }}>
                      <Typography variant="subtitle1" gutterBottom>
                        Verification Decision
                      </Typography>
                      <TextField
                        fullWidth
                        label="Rejection Reason (required if rejecting)"
                        multiline
                        rows={4}
                        value={rejectionReason}
                        onChange={(e) => setRejectionReason(e.target.value)}
                        sx={{ mb: 2 }}
                      />
                    </Box>
                  )}
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseDialog}>Close</Button>
              
              {selectedVerification.status === 'pending' && (
                <>
                  <Button 
                    onClick={handleRejectVerification} 
                    variant="outlined" 
                    color="error"
                    disabled={processingVerification || !rejectionReason}
                    startIcon={<CancelIcon />}
                  >
                    Reject
                  </Button>
                  <Button 
                    onClick={handleApproveVerification} 
                    variant="contained" 
                    color="success"
                    disabled={processingVerification}
                    startIcon={<CheckCircleIcon />}
                  >
                    Approve
                  </Button>
                </>
              )}
            </DialogActions>
          </>
        )}
      </Dialog>
    </Box>
  );
};

export default AdminComplianceVerification;
