import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Box,
  Paper,
  Divider,
  TextField,
  CircularProgress,
  Alert,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormHelperText,
  Input,
  IconButton
} from '@mui/material';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';
import PhotoCamera from '@mui/icons-material/PhotoCamera';
import DeleteIcon from '@mui/icons-material/Delete';

const FarmerAddProduct = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { id } = useParams(); // Will be undefined for new products
  const isEditing = !!id;
  
  const [product, setProduct] = useState({
    name: '',
    description: '',
    category: '',
    strain_type: '',
    thc_content: '',
    cbd_content: '',
    price: '',
    quantity: '',
    unit: 'gram',
    status: 'active'
  });
  
  const [images, setImages] = useState([]);
  const [imageFiles, setImageFiles] = useState([]);
  const [loading, setLoading] = useState(isEditing);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  
  // Categories and strain types
  const categories = ['Flower', 'Edibles', 'Concentrates', 'Pre-rolls', 'Vapes', 'Tinctures', 'Topicals'];
  const strainTypes = ['Indica', 'Sativa', 'Hybrid', 'CBD'];
  const units = ['gram', 'eighth', 'quarter', 'half', 'ounce', 'pound', 'each', 'pack'];
  
  // Fetch product data if editing
  useEffect(() => {
    const fetchProduct = async () => {
      if (isEditing) {
        try {
          setLoading(true);
          const response = await axios.get(`/farmers/products/${id}`);
          setProduct(response.data.product);
          setImages(response.data.product.images || []);
          setError(null);
        } catch (err) {
          console.error('Error fetching product:', err);
          setError('Failed to load product data. Please try again later.');
        } finally {
          setLoading(false);
        }
      }
    };
    
    fetchProduct();
  }, [id, isEditing]);
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProduct(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleNumberInputChange = (e) => {
    const { name, value } = e.target;
    // Allow only numbers and decimal point
    if (!isNaN(value) || value === '') {
      setProduct(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };
  
  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    
    // Preview images
    const newImageFiles = [...imageFiles, ...files];
    setImageFiles(newImageFiles);
    
    // Create object URLs for preview
    const newImageUrls = files.map(file => URL.createObjectURL(file));
    setImages([...images, ...newImageUrls]);
  };
  
  const handleRemoveImage = (index) => {
    const newImages = [...images];
    newImages.splice(index, 1);
    setImages(newImages);
    
    if (index < imageFiles.length) {
      const newImageFiles = [...imageFiles];
      newImageFiles.splice(index, 1);
      setImageFiles(newImageFiles);
    }
  };
  
  const validateForm = () => {
    const requiredFields = ['name', 'description', 'category', 'strain_type', 'price', 'quantity', 'unit'];
    const missingFields = requiredFields.filter(field => !product[field]);
    
    if (missingFields.length > 0) {
      setError(`Please fill in all required fields: ${missingFields.join(', ')}`);
      return false;
    }
    
    if (images.length === 0 && imageFiles.length === 0) {
      setError('Please upload at least one product image');
      return false;
    }
    
    return true;
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    try {
      setSubmitting(true);
      setError(null);
      setSuccess(null);
      
      // Create FormData object to handle file uploads
      const formData = new FormData();
      
      // Add product data
      Object.keys(product).forEach(key => {
        formData.append(key, product[key]);
      });
      
      // Add image files
      imageFiles.forEach(file => {
        formData.append('images', file);
      });
      
      let response;
      if (isEditing) {
        response = await axios.put(`/farmers/products/${id}`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        });
      } else {
        response = await axios.post('/farmers/products', formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        });
      }
      
      setSuccess(isEditing ? 'Product updated successfully!' : 'Product added successfully!');
      
      // Redirect after a short delay
      setTimeout(() => {
        navigate('/farmer/products');
      }, 2000);
    } catch (err) {
      console.error('Error submitting product:', err);
      setError(err.response?.data?.message || 'Failed to save product. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };
  
  if (loading) {
    return (
      <Container sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress />
      </Container>
    );
  }
  
  return (
    <Container>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          {isEditing ? 'Edit Product' : 'Add New Product'}
        </Typography>
        <Typography variant="body1" color="text.secondary">
          {isEditing 
            ? 'Update your product information below' 
            : 'Fill in the details below to add a new product to your inventory'}
        </Typography>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      {success && (
        <Alert severity="success" sx={{ mb: 3 }}>
          {success}
        </Alert>
      )}
      
      <Paper sx={{ p: 3 }}>
        <Box component="form" onSubmit={handleSubmit}>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom>
                Basic Information
              </Typography>
              <Divider sx={{ mb: 2 }} />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Product Name"
                name="name"
                value={product.name}
                onChange={handleInputChange}
                required
                helperText="Enter a descriptive name for your product"
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Description"
                name="description"
                value={product.description}
                onChange={handleInputChange}
                multiline
                rows={4}
                required
                helperText="Provide a detailed description of your product"
              />
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth required>
                <InputLabel id="category-label">Category</InputLabel>
                <Select
                  labelId="category-label"
                  id="category"
                  name="category"
                  value={product.category}
                  label="Category"
                  onChange={handleInputChange}
                >
                  {categories.map((category) => (
                    <MenuItem key={category} value={category}>{category}</MenuItem>
                  ))}
                </Select>
                <FormHelperText>Select the product category</FormHelperText>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth required>
                <InputLabel id="strain-type-label">Strain Type</InputLabel>
                <Select
                  labelId="strain-type-label"
                  id="strain_type"
                  name="strain_type"
                  value={product.strain_type}
                  label="Strain Type"
                  onChange={handleInputChange}
                >
                  {strainTypes.map((type) => (
                    <MenuItem key={type} value={type}>{type}</MenuItem>
                  ))}
                </Select>
                <FormHelperText>Select the strain type</FormHelperText>
              </FormControl>
            </Grid>
            
            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom sx={{ mt: 2 }}>
                Product Details
              </Typography>
              <Divider sx={{ mb: 2 }} />
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="THC Content (%)"
                name="thc_content"
                value={product.thc_content}
                onChange={handleNumberInputChange}
                type="number"
                inputProps={{ min: 0, max: 100, step: 0.1 }}
                helperText="Enter the THC percentage (e.g., 18.5)"
              />
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="CBD Content (%)"
                name="cbd_content"
                value={product.cbd_content}
                onChange={handleNumberInputChange}
                type="number"
                inputProps={{ min: 0, max: 100, step: 0.1 }}
                helperText="Enter the CBD percentage (e.g., 2.0)"
              />
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="Price"
                name="price"
                value={product.price}
                onChange={handleNumberInputChange}
                required
                InputProps={{
                  startAdornment: <Box component="span" sx={{ mr: 1 }}>$</Box>,
                }}
                helperText="Enter the price per unit"
              />
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <TextField
                fullWidth
                label="Quantity"
                name="quantity"
                value={product.quantity}
                onChange={handleNumberInputChange}
                required
                type="number"
                inputProps={{ min: 0, step: 1 }}
                helperText="Enter available quantity"
              />
            </Grid>
            
            <Grid item xs={12} sm={4}>
              <FormControl fullWidth required>
                <InputLabel id="unit-label">Unit</InputLabel>
                <Select
                  labelId="unit-label"
                  id="unit"
                  name="unit"
                  value={product.unit}
                  label="Unit"
                  onChange={handleInputChange}
                >
                  {units.map((unit) => (
                    <MenuItem key={unit} value={unit}>{unit}</MenuItem>
                  ))}
                </Select>
                <FormHelperText>Select the unit of measurement</FormHelperText>
              </FormControl>
            </Grid>
            
            <Grid item xs={12}>
              <FormControl fullWidth>
                <InputLabel id="status-label">Status</InputLabel>
                <Select
                  labelId="status-label"
                  id="status"
                  name="status"
                  value={product.status}
                  label="Status"
                  onChange={handleInputChange}
                >
                  <MenuItem value="active">Active</MenuItem>
                  <MenuItem value="inactive">Inactive</MenuItem>
                </Select>
                <FormHelperText>Set product visibility status</FormHelperText>
              </FormControl>
            </Grid>
            
            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom sx={{ mt: 2 }}>
                Product Images
              </Typography>
              <Divider sx={{ mb: 2 }} />
            </Grid>
            
            <Grid item xs={12}>
              <Box sx={{ mb: 2 }}>
                <input
                  accept="image/*"
                  style={{ display: 'none' }}
                  id="image-upload"
                  multiple
                  type="file"
                  onChange={handleImageUpload}
                />
                <label htmlFor="image-upload">
                  <Button
                    variant="outlined"
                    component="span"
                    startIcon={<PhotoCamera />}
                  >
                    Upload Images
                  </Button>
                </label>
                <FormHelperText>Upload high-quality images of your product (max 5 images)</FormHelperText>
              </Box>
              
              <Grid container spacing={2}>
                {images.map((image, index) => (
                  <Grid item xs={6} sm={4} md={3} key={index}>
                    <Box sx={{ position: 'relative' }}>
                      <img
                        src={image}
                        alt={`Product ${index + 1}`}
                        style={{ width: '100%', height: '150px', objectFit: 'cover', borderRadius: '4px' }}
                      />
                      <IconButton
                        sx={{
                          position: 'absolute',
                          top: 5,
                          right: 5,
                          bgcolor: 'rgba(0, 0, 0, 0.5)',
                          color: 'white',
                          '&:hover': {
                            bgcolor: 'rgba(0, 0, 0, 0.7)',
                          }
                        }}
                        size="small"
                        onClick={() => handleRemoveImage(index)}
                      >
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Box>
                  </Grid>
                ))}
              </Grid>
            </Grid>
            
            <Grid item xs={12} sx={{ mt: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                <Button 
                  variant="outlined" 
                  onClick={() => navigate('/farmer/products')}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  variant="contained" 
                  color="primary"
                  disabled={submitting}
                >
                  {submitting ? 'Saving...' : isEditing ? 'Update Product' : 'Add Product'}
                </Button>
              </Box>
            </Grid>
          </Grid>
        </Box>
      </Paper>
    </Container>
  );
};

export default FarmerAddProduct;
