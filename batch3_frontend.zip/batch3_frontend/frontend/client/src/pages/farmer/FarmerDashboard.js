import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Box,
  Paper,
  Divider,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip
} from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';

const FarmerDashboard = () => {
  const { user } = useAuth();
  const [dashboardData, setDashboardData] = useState({
    recentOrders: [],
    topProducts: [],
    stats: {
      totalSales: 0,
      pendingOrders: 0,
      totalProducts: 0,
      averageRating: 0
    }
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Fetch dashboard data
        const response = await axios.get('/farmers/dashboard');
        setDashboardData(response.data);
        
        setError(null);
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Failed to load dashboard data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);
  
  if (loading) {
    return (
      <Container sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress />
      </Container>
    );
  }
  
  return (
    <Container>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Farmer Dashboard
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Welcome back, {user?.first_name}! Here's an overview of your business.
        </Typography>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" color="text.secondary" gutterBottom>
                Total Sales
              </Typography>
              <Typography variant="h4" component="div">
                ${dashboardData.stats.totalSales.toFixed(2)}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                Lifetime sales
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" color="text.secondary" gutterBottom>
                Pending Orders
              </Typography>
              <Typography variant="h4" component="div">
                {dashboardData.stats.pendingOrders}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                Orders awaiting fulfillment
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" color="text.secondary" gutterBottom>
                Total Products
              </Typography>
              <Typography variant="h4" component="div">
                {dashboardData.stats.totalProducts}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                Active product listings
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="h6" color="text.secondary" gutterBottom>
                Average Rating
              </Typography>
              <Typography variant="h4" component="div">
                {dashboardData.stats.averageRating.toFixed(1)}/5.0
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                Based on customer reviews
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
      
      <Grid container spacing={4}>
        <Grid item xs={12} md={7}>
          <Paper sx={{ p: 3, mb: 4 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">Recent Orders</Typography>
              <Button 
                component={RouterLink} 
                to="/farmer/orders" 
                color="primary"
              >
                View All
              </Button>
            </Box>
            <Divider sx={{ mb: 2 }} />
            
            {dashboardData.recentOrders.length > 0 ? (
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Order #</TableCell>
                      <TableCell>Date</TableCell>
                      <TableCell>Dispensary</TableCell>
                      <TableCell>Amount</TableCell>
                      <TableCell>Status</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {dashboardData.recentOrders.map((order) => (
                      <TableRow 
                        key={order.id}
                        hover
                        component={RouterLink}
                        to={`/farmer/orders/${order.id}`}
                        sx={{ 
                          textDecoration: 'none',
                          '&:hover': { cursor: 'pointer' }
                        }}
                      >
                        <TableCell>#{order.id}</TableCell>
                        <TableCell>{new Date(order.created_at).toLocaleDateString()}</TableCell>
                        <TableCell>{order.dispensary_name}</TableCell>
                        <TableCell>${order.total.toFixed(2)}</TableCell>
                        <TableCell>
                          <Chip 
                            label={order.status.replace('_', ' ')} 
                            color={
                              order.status === 'completed' ? 'success' :
                              order.status === 'processing' ? 'info' :
                              order.status === 'pending' ? 'warning' :
                              'default'
                            }
                            size="small"
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            ) : (
              <Box sx={{ textAlign: 'center', py: 4 }}>
                <Typography variant="body1" color="text.secondary">
                  No recent orders found.
                </Typography>
              </Box>
            )}
          </Paper>
          
          <Paper sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">License Information</Typography>
              <Chip 
                label={user?.license_status || 'Verified'} 
                color={user?.license_status === 'verified' ? 'success' : 'warning'}
              />
            </Box>
            <Divider sx={{ mb: 2 }} />
            
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <Typography variant="body2" color="text.secondary">
                  License Number
                </Typography>
                <Typography variant="body1" gutterBottom>
                  {user?.license_number || 'CA-FARM-12345'}
                </Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="body2" color="text.secondary">
                  License Type
                </Typography>
                <Typography variant="body1" gutterBottom>
                  {user?.license_type || 'Cultivation - Small Outdoor'}
                </Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="body2" color="text.secondary">
                  Issue Date
                </Typography>
                <Typography variant="body1" gutterBottom>
                  {user?.license_issue_date ? new Date(user.license_issue_date).toLocaleDateString() : '01/15/2025'}
                </Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="body2" color="text.secondary">
                  Expiration Date
                </Typography>
                <Typography 
                  variant="body1" 
                  color={
                    user?.license_expiry_date && new Date(user.license_expiry_date) < new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) 
                      ? 'error.main' 
                      : 'inherit'
                  }
                  gutterBottom
                >
                  {user?.license_expiry_date ? new Date(user.license_expiry_date).toLocaleDateString() : '01/15/2026'}
                </Typography>
              </Grid>
            </Grid>
            
            {user?.license_expiry_date && new Date(user.license_expiry_date) < new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) && (
              <Alert severity="warning" sx={{ mt: 2 }}>
                Your license will expire soon. Please renew it to continue selling on our platform.
              </Alert>
            )}
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={5}>
          <Paper sx={{ p: 3, mb: 4 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">Top Products</Typography>
              <Button 
                component={RouterLink} 
                to="/farmer/products" 
                color="primary"
              >
                View All
              </Button>
            </Box>
            <Divider sx={{ mb: 2 }} />
            
            {dashboardData.topProducts.length > 0 ? (
              <Grid container spacing={2}>
                {dashboardData.topProducts.map((product) => (
                  <Grid item xs={12} key={product.id}>
                    <Card sx={{ display: 'flex', height: '100%' }}>
                      <Box sx={{ width: 80, height: 80, flexShrink: 0 }}>
                        <img
                          src={product.images?.[0] || '/placeholder-product.jpg'}
                          alt={product.name}
                          style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                        />
                      </Box>
                      <CardContent sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                        <Box>
                          <Typography variant="subtitle1">
                            {product.name}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {product.category} • {product.strain_type}
                          </Typography>
                        </Box>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 1 }}>
                          <Typography variant="body2" color="primary">
                            ${product.price.toFixed(2)} / {product.unit}
                          </Typography>
                          <Typography variant="body2">
                            {product.total_sold} sold
                          </Typography>
                        </Box>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            ) : (
              <Box sx={{ textAlign: 'center', py: 4 }}>
                <Typography variant="body1" color="text.secondary">
                  No products found.
                </Typography>
                <Button 
                  component={RouterLink} 
                  to="/farmer/products/add" 
                  variant="contained" 
                  color="primary"
                  sx={{ mt: 2 }}
                >
                  Add Product
                </Button>
              </Box>
            )}
          </Paper>
          
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Quick Actions
            </Typography>
            <Divider sx={{ mb: 2 }} />
            
            <Button 
              component={RouterLink} 
              to="/farmer/products/add" 
              variant="contained" 
              color="primary"
              fullWidth
              sx={{ mb: 2 }}
            >
              Add New Product
            </Button>
            
            <Button 
              component={RouterLink} 
              to="/farmer/orders" 
              variant="outlined"
              fullWidth
              sx={{ mb: 2 }}
            >
              Manage Orders
            </Button>
            
            <Button 
              component={RouterLink} 
              to="/farmer/profile" 
              variant="outlined"
              fullWidth
              sx={{ mb: 2 }}
            >
              Update Profile
            </Button>
            
            <Button 
              component={RouterLink} 
              to="/farmer/payouts" 
              variant="outlined"
              fullWidth
            >
              View Payouts
            </Button>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default FarmerDashboard;
