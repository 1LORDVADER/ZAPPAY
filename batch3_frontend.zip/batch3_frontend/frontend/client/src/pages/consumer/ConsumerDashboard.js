import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Box,
  Paper,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  CircularProgress,
  Alert
} from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import ShoppingBagIcon from '@mui/icons-material/ShoppingBag';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import FavoriteIcon from '@mui/icons-material/Favorite';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';

const ConsumerDashboard = () => {
  const { user } = useAuth();
  const [recentOrders, setRecentOrders] = useState([]);
  const [favoriteProducts, setFavoriteProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Fetch recent orders
        const ordersResponse = await axios.get('/orders/consumer');
        setRecentOrders(ordersResponse.data.orders.slice(0, 5));
        
        // Fetch favorite products
        const favoritesResponse = await axios.get('/consumers/favorites');
        setFavoriteProducts(favoritesResponse.data.favorites);
        
        setError(null);
      } catch (err) {
        console.error('Error fetching dashboard data:', err);
        setError('Failed to load dashboard data. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);
  
  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending':
        return <ShoppingBagIcon color="primary" />;
      case 'processing':
        return <LocalShippingIcon color="secondary" />;
      case 'completed':
        return <CheckCircleIcon color="success" />;
      default:
        return <ShoppingBagIcon />;
    }
  };
  
  if (loading) {
    return (
      <Container sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress />
      </Container>
    );
  }
  
  return (
    <Container>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Welcome back, {user?.first_name}!
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Here's an overview of your recent activity and favorite products.
        </Typography>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      <Grid container spacing={4}>
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3, mb: 4 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">Recent Orders</Typography>
              <Button 
                component={RouterLink} 
                to="/orders" 
                color="primary"
              >
                View All
              </Button>
            </Box>
            <Divider sx={{ mb: 2 }} />
            
            {recentOrders.length > 0 ? (
              <List>
                {recentOrders.map((order) => (
                  <React.Fragment key={order.id}>
                    <ListItem 
                      button 
                      component={RouterLink} 
                      to={`/orders/${order.id}`}
                      sx={{ borderRadius: 1 }}
                    >
                      <ListItemIcon>
                        {getStatusIcon(order.status)}
                      </ListItemIcon>
                      <ListItemText 
                        primary={`Order #${order.id}`} 
                        secondary={`${new Date(order.created_at).toLocaleDateString()} • ${order.dispensary_name}`} 
                      />
                      <Box>
                        <Typography variant="subtitle1" color="primary">
                          ${order.total.toFixed(2)}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                        </Typography>
                      </Box>
                    </ListItem>
                    <Divider component="li" />
                  </React.Fragment>
                ))}
              </List>
            ) : (
              <Box sx={{ textAlign: 'center', py: 4 }}>
                <Typography variant="body1" color="text.secondary">
                  You haven't placed any orders yet.
                </Typography>
                <Button 
                  component={RouterLink} 
                  to="/products" 
                  variant="contained" 
                  color="primary"
                  sx={{ mt: 2 }}
                >
                  Browse Products
                </Button>
              </Box>
            )}
          </Paper>
          
          <Paper sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">Favorite Products</Typography>
              <Button 
                component={RouterLink} 
                to="/favorites" 
                color="primary"
              >
                View All
              </Button>
            </Box>
            <Divider sx={{ mb: 2 }} />
            
            {favoriteProducts.length > 0 ? (
              <Grid container spacing={2}>
                {favoriteProducts.map((product) => (
                  <Grid item key={product.id} xs={12} sm={6}>
                    <Card sx={{ display: 'flex', height: '100%' }}>
                      <Box sx={{ width: 100, height: 100, flexShrink: 0 }}>
                        <img
                          src={product.images?.[0] || '/placeholder-product.jpg'}
                          alt={product.name}
                          style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                        />
                      </Box>
                      <CardContent sx={{ flexGrow: 1 }}>
                        <Typography variant="subtitle1" component={RouterLink} to={`/products/${product.id}`} sx={{ textDecoration: 'none', color: 'inherit' }}>
                          {product.name}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {product.farmer_name}
                        </Typography>
                        <Typography variant="body2" color="primary" sx={{ mt: 1 }}>
                          ${product.price.toFixed(2)} / {product.unit}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            ) : (
              <Box sx={{ textAlign: 'center', py: 4 }}>
                <Typography variant="body1" color="text.secondary">
                  You don't have any favorite products yet.
                </Typography>
                <Button 
                  component={RouterLink} 
                  to="/products" 
                  variant="contained" 
                  color="primary"
                  sx={{ mt: 2 }}
                >
                  Browse Products
                </Button>
              </Box>
            )}
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, mb: 4 }}>
            <Typography variant="h6" gutterBottom>
              Your Profile
            </Typography>
            <Divider sx={{ mb: 2 }} />
            
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2" color="text.secondary">
                Name
              </Typography>
              <Typography variant="body1">
                {user?.first_name} {user?.last_name}
              </Typography>
            </Box>
            
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2" color="text.secondary">
                Email
              </Typography>
              <Typography variant="body1">
                {user?.email}
              </Typography>
            </Box>
            
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2" color="text.secondary">
                Age Verification
              </Typography>
              <Typography variant="body1" color={user?.is_age_verified ? "success.main" : "error.main"}>
                {user?.is_age_verified ? "Verified" : "Not Verified"}
              </Typography>
            </Box>
            
            <Button 
              component={RouterLink} 
              to="/profile" 
              variant="outlined" 
              fullWidth
              sx={{ mt: 2 }}
            >
              Edit Profile
            </Button>
          </Paper>
          
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Quick Actions
            </Typography>
            <Divider sx={{ mb: 2 }} />
            
            <Button 
              component={RouterLink} 
              to="/products" 
              variant="contained" 
              color="primary"
              fullWidth
              sx={{ mb: 2 }}
            >
              Browse Products
            </Button>
            
            <Button 
              component={RouterLink} 
              to="/dispensaries" 
              variant="outlined"
              fullWidth
              sx={{ mb: 2 }}
            >
              Find Dispensaries
            </Button>
            
            <Button 
              component={RouterLink} 
              to="/orders" 
              variant="outlined"
              fullWidth
            >
              View Orders
            </Button>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default ConsumerDashboard;
