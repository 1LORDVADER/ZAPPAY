import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Box,
  Paper,
  Divider,
  CircularProgress,
  Alert,
  Stepper,
  Step,
  StepLabel,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  RadioGroup,
  Radio,
  FormControlLabel,
  FormLabel,
  FormHelperText
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useCart } from '../../contexts/CartContext';
import axios from 'axios';
import LockIcon from '@mui/icons-material/Lock';
import SecurityIcon from '@mui/icons-material/Security';

const PaymentProcessor = () => {
  const { user } = useAuth();
  const { cart, clearCart } = useCart();
  const navigate = useNavigate();
  
  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [orderSummary, setOrderSummary] = useState({
    subtotal: 0,
    exciseTax: 0,
    localTax: 0,
    platformFee: 0,
    total: 0,
    items: []
  });
  
  const [paymentMethod, setPaymentMethod] = useState('ach');
  const [achDetails, setAchDetails] = useState({
    accountName: '',
    accountNumber: '',
    routingNumber: '',
    accountType: 'checking'
  });
  
  const [selectedDispensary, setSelectedDispensary] = useState('');
  const [dispensaries, setDispensaries] = useState([]);
  const [pickupDate, setPickupDate] = useState('');
  const [pickupTime, setPickupTime] = useState('');
  const [specialInstructions, setSpecialInstructions] = useState('');
  
  const steps = ['Review Order', 'Select Dispensary', 'Payment Details', 'Confirmation'];
  
  useEffect(() => {
    // Calculate order summary
    if (cart && cart.items) {
      const subtotal = cart.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
      const exciseTax = subtotal * 0.15; // 15% excise tax
      const localTax = subtotal * 0.085; // 8.5% local tax
      const platformFee = (subtotal + exciseTax + localTax) * 0.052; // 5.2% platform fee
      const total = subtotal + exciseTax + localTax + platformFee;
      
      setOrderSummary({
        subtotal,
        exciseTax,
        localTax,
        platformFee,
        total,
        items: cart.items
      });
    }
    
    // Fetch available dispensaries
    const fetchDispensaries = async () => {
      try {
        const response = await axios.get('/dispensaries/available');
        setDispensaries(response.data.dispensaries);
      } catch (err) {
        console.error('Error fetching dispensaries:', err);
        setError('Failed to load available dispensaries. Please try again later.');
      }
    };
    
    fetchDispensaries();
  }, [cart]);
  
  const handleNext = () => {
    if (activeStep === 0) {
      // Validate cart is not empty
      if (!orderSummary.items.length) {
        setError('Your cart is empty. Please add products before proceeding.');
        return;
      }
    } else if (activeStep === 1) {
      // Validate dispensary selection
      if (!selectedDispensary) {
        setError('Please select a dispensary for pickup.');
        return;
      }
      if (!pickupDate || !pickupTime) {
        setError('Please select a pickup date and time.');
        return;
      }
    } else if (activeStep === 2) {
      // Validate payment details
      if (paymentMethod === 'ach') {
        if (!achDetails.accountName || !achDetails.accountNumber || !achDetails.routingNumber) {
          setError('Please fill in all required payment fields.');
          return;
        }
        if (achDetails.routingNumber.length !== 9) {
          setError('Routing number must be 9 digits.');
          return;
        }
      }
    }
    
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    setError(null);
  };
  
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
    setError(null);
  };
  
  const handlePaymentMethodChange = (event) => {
    setPaymentMethod(event.target.value);
  };
  
  const handleAchDetailsChange = (event) => {
    const { name, value } = event.target;
    setAchDetails({
      ...achDetails,
      [name]: value
    });
  };
  
  const handleDispensaryChange = (event) => {
    setSelectedDispensary(event.target.value);
  };
  
  const handlePlaceOrder = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const orderData = {
        dispensary_id: selectedDispensary,
        items: orderSummary.items.map(item => ({
          product_id: item.id,
          quantity: item.quantity,
          price: item.price
        })),
        payment_method: paymentMethod,
        payment_details: paymentMethod === 'ach' ? {
          account_name: achDetails.accountName,
          account_number: achDetails.accountNumber,
          routing_number: achDetails.routingNumber,
          account_type: achDetails.accountType
        } : null,
        pickup_date: pickupDate,
        pickup_time: pickupTime,
        special_instructions: specialInstructions,
        subtotal: orderSummary.subtotal,
        excise_tax: orderSummary.exciseTax,
        local_tax: orderSummary.localTax,
        platform_fee: orderSummary.platformFee,
        total: orderSummary.total
      };
      
      const response = await axios.post('/orders', orderData);
      
      // Clear the cart after successful order
      clearCart();
      
      // Move to confirmation step
      setActiveStep(3);
      
      // Store order ID for confirmation
      setOrderSummary({
        ...orderSummary,
        orderId: response.data.order_id
      });
      
    } catch (err) {
      console.error('Error placing order:', err);
      setError(err.response?.data?.message || 'Failed to place order. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const getStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Review Your Order
            </Typography>
            
            {orderSummary.items.length === 0 ? (
              <Alert severity="warning">
                Your cart is empty. Please add products before proceeding.
              </Alert>
            ) : (
              <>
                <TableContainer component={Paper} variant="outlined" sx={{ mb: 3 }}>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>Product</TableCell>
                        <TableCell>Farmer</TableCell>
                        <TableCell align="right">Price</TableCell>
                        <TableCell align="right">Quantity</TableCell>
                        <TableCell align="right">Subtotal</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {orderSummary.items.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell>
                            <Box sx={{ display: 'flex', alignItems: 'center' }}>
                              {item.image && (
                                <Box 
                                  component="img" 
                                  src={item.image} 
                                  alt={item.name}
                                  sx={{ width: 50, height: 50, mr: 2, objectFit: 'cover' }}
                                />
                              )}
                              <Box>
                                <Typography variant="body2">{item.name}</Typography>
                                <Typography variant="body2" color="text.secondary">
                                  {item.strain_type} • THC: {item.thc_content}%
                                </Typography>
                              </Box>
                            </Box>
                          </TableCell>
                          <TableCell>{item.farmer_name}</TableCell>
                          <TableCell align="right">${item.price.toFixed(2)}</TableCell>
                          <TableCell align="right">{item.quantity}</TableCell>
                          <TableCell align="right">${(item.price * item.quantity).toFixed(2)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
                
                <Grid container spacing={2}>
                  <Grid item xs={12} md={6}>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      Please note:
                    </Typography>
                    <Typography variant="body2" paragraph>
                      • All orders are for pickup only at licensed dispensaries
                    </Typography>
                    <Typography variant="body2" paragraph>
                      • You must be 21+ with valid ID to pickup your order
                    </Typography>
                    <Typography variant="body2" paragraph>
                      • Orders cannot be modified after submission
                    </Typography>
                  </Grid>
                  
                  <Grid item xs={12} md={6}>
                    <Paper variant="outlined" sx={{ p: 2 }}>
                      <Typography variant="h6" gutterBottom>
                        Order Summary
                      </Typography>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="body1">Subtotal</Typography>
                        <Typography variant="body1">${orderSummary.subtotal.toFixed(2)}</Typography>
                      </Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="body2" color="text.secondary">Excise Tax (15%)</Typography>
                        <Typography variant="body2" color="text.secondary">${orderSummary.exciseTax.toFixed(2)}</Typography>
                      </Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="body2" color="text.secondary">Local Tax (8.5%)</Typography>
                        <Typography variant="body2" color="text.secondary">${orderSummary.localTax.toFixed(2)}</Typography>
                      </Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="body2" color="text.secondary">Platform Fee (5.2%)</Typography>
                        <Typography variant="body2" color="text.secondary">${orderSummary.platformFee.toFixed(2)}</Typography>
                      </Box>
                      <Divider sx={{ my: 1 }} />
                      <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                        <Typography variant="h6">Total</Typography>
                        <Typography variant="h6">${orderSummary.total.toFixed(2)}</Typography>
                      </Box>
                    </Paper>
                  </Grid>
                </Grid>
              </>
            )}
          </Box>
        );
      
      case 1:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Select Pickup Location
            </Typography>
            
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <FormControl fullWidth required error={!selectedDispensary && error}>
                  <InputLabel id="dispensary-label">Dispensary</InputLabel>
                  <Select
                    labelId="dispensary-label"
                    id="dispensary"
                    value={selectedDispensary}
                    label="Dispensary"
                    onChange={handleDispensaryChange}
                  >
                    {dispensaries.map((dispensary) => (
                      <MenuItem key={dispensary.id} value={dispensary.id}>
                        {dispensary.name} - {dispensary.address}, {dispensary.city}
                      </MenuItem>
                    ))}
                  </Select>
                  <FormHelperText>Select a dispensary for pickup</FormHelperText>
                </FormControl>
              </Grid>
              
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Pickup Date"
                  type="date"
                  value={pickupDate}
                  onChange={(e) => setPickupDate(e.target.value)}
                  InputLabelProps={{
                    shrink: true,
                  }}
                  required
                  inputProps={{
                    min: new Date().toISOString().split('T')[0]
                  }}
                />
              </Grid>
              
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Pickup Time"
                  type="time"
                  value={pickupTime}
                  onChange={(e) => setPickupTime(e.target.value)}
                  InputLabelProps={{
                    shrink: true,
                  }}
                  required
                  inputProps={{
                    step: 1800 // 30 min intervals
                  }}
                />
              </Grid>
              
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Special Instructions (Optional)"
                  multiline
                  rows={3}
                  value={specialInstructions}
                  onChange={(e) => setSpecialInstructions(e.target.value)}
                  placeholder="Any special instructions for pickup"
                />
              </Grid>
              
              {selectedDispensary && (
                <Grid item xs={12}>
                  <Paper variant="outlined" sx={{ p: 2 }}>
                    <Typography variant="subtitle1" gutterBottom>
                      Selected Dispensary Information
                    </Typography>
                    
                    {dispensaries.filter(d => d.id === selectedDispensary).map((dispensary) => (
                      <Box key={dispensary.id}>
                        <Typography variant="body1" gutterBottom>
                          {dispensary.name}
                        </Typography>
                        <Typography variant="body2" paragraph>
                          {dispensary.address}<br />
                          {dispensary.city}, {dispensary.state} {dispensary.zip_code}
                        </Typography>
                        <Typography variant="body2" paragraph>
                          Phone: {dispensary.phone}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          Hours: {dispensary.hours}
                        </Typography>
                      </Box>
                    ))}
                  </Paper>
                </Grid>
              )}
            </Grid>
          </Box>
        );
      
      case 2:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Payment Method
            </Typography>
            
            <Box sx={{ mb: 3 }}>
              <FormControl component="fieldset">
                <RadioGroup
                  name="payment-method"
                  value={paymentMethod}
                  onChange={handlePaymentMethodChange}
                >
                  <FormControlLabel 
                    value="ach" 
                    control={<Radio />} 
                    label="ACH Bank Transfer (Secure)" 
                  />
                  <FormControlLabel 
                    value="cash" 
                    control={<Radio />} 
                    label="Cash on Pickup" 
                  />
                </RadioGroup>
              </FormControl>
            </Box>
            
            {paymentMethod === 'ach' && (
              <Paper variant="outlined" sx={{ p: 3, mb: 3 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <LockIcon color="primary" sx={{ mr: 1 }} />
                  <Typography variant="subtitle1">
                    Secure ACH Payment
                  </Typography>
                </Box>
                
                <Typography variant="body2" color="text.secondary" paragraph>
                  Your banking information is encrypted and securely processed through our payment system.
                </Typography>
                
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="Account Holder Name"
                      name="accountName"
                      value={achDetails.accountName}
                      onChange={handleAchDetailsChange}
                      required
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      label="Account Number"
                      name="accountNumber"
                      value={achDetails.accountNumber}
                      onChange={handleAchDetailsChange}
                      required
                      type="password"
                    />
                  </Grid>
                  <Grid item xs={12} sm={6}>
                    <TextField
                      fullWidth
                      label="Routing Number"
                      name="routingNumber"
                      value={achDetails.routingNumber}
                      onChange={handleAchDetailsChange}
                      required
                      inputProps={{ maxLength: 9 }}
                      helperText="9-digit routing number"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <FormControl fullWidth>
                      <InputLabel id="account-type-label">Account Type</InputLabel>
                      <Select
                        labelId="account-type-label"
                        id="accountType"
                        name="accountType"
                        value={achDetails.accountType}
                        label="Account Type"
                        onChange={handleAchDetailsChange}
                      >
                        <MenuItem value="checking">Checking</MenuItem>
                        <MenuItem value="savings">Savings</MenuItem>
                      </Select>
                    </FormControl>
                  </Grid>
                </Grid>
              </Paper>
            )}
            
            {paymentMethod === 'cash' && (
              <Paper variant="outlined" sx={{ p: 3, mb: 3 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Typography variant="subtitle1">
                    Cash Payment at Pickup
                  </Typography>
                </Box>
                
                <Typography variant="body2" paragraph>
                  You will pay the total amount of ${orderSummary.total.toFixed(2)} in cash when you pick up your order at the dispensary.
                </Typography>
                
                <Typography variant="body2" color="text.secondary">
                  Please note that exact change is appreciated.
                </Typography>
              </Paper>
            )}
            
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2, mt: 4 }}>
              <SecurityIcon color="primary" sx={{ mr: 1 }} />
              <Typography variant="subtitle1">
                Compliance Information
              </Typography>
            </Box>
            
            <Typography variant="body2" paragraph>
              By placing this order, you confirm that:
            </Typography>
            
            <Typography variant="body2" paragraph>
              • You are 21 years of age or older
            </Typography>
            
            <Typography variant="body2" paragraph>
              • You will present a valid government-issued ID at pickup
            </Typography>
            
            <Typography variant="body2" paragraph>
              • You understand that all sales are final and non-refundable
            </Typography>
            
            <Typography variant="body2" paragraph>
              • You agree to comply with all applicable state and local laws regarding cannabis purchase and possession
            </Typography>
          </Box>
        );
      
      case 3:
        return (
          <Box sx={{ textAlign: 'center', py: 3 }}>
            <Box sx={{ mb: 3 }}>
              <CheckCircleIcon color="success" sx={{ fontSize: 60 }} />
            </Box>
            
            <Typography variant="h5" gutterBottom>
              Order Placed Successfully!
            </Typography>
            
            <Typography variant="body1" paragraph>
              Your order #{orderSummary.orderId} has been received and is being processed.
            </Typography>
            
            <Typography variant="body1" paragraph>
              You will receive an email confirmation shortly.
            </Typography>
            
            <Box sx={{ mt: 4 }}>
              <Button 
                variant="contained" 
                color="primary"
                onClick={() => navigate('/orders')}
                sx={{ mr: 2 }}
              >
                View Your Orders
              </Button>
              
              <Button 
                variant="outlined"
                onClick={() => navigate('/products')}
              >
                Continue Shopping
              </Button>
            </Box>
          </Box>
        );
      
      default:
        return 'Unknown step';
    }
  };
  
  return (
    <Container>
      <Box sx={{ mb: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Checkout
        </Typography>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      <Paper sx={{ p: 3, mb: 4 }}>
        <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        
        <Box sx={{ mt: 2, mb: 4 }}>
          {getStepContent(activeStep)}
        </Box>
        
        <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
          {activeStep !== 0 && activeStep !== 3 && (
            <Button 
              onClick={handleBack}
              sx={{ mr: 1 }}
              disabled={loading}
            >
              Back
            </Button>
          )}
          
          {activeStep === steps.length - 1 ? (
            null
          ) : activeStep === steps.length - 2 ? (
            <Button
              variant="contained"
              color="primary"
              onClick={handlePlaceOrder}
              disabled={loading}
            >
              {loading ? 'Processing...' : 'Place Order'}
            </Button>
          ) : (
            <Button
              variant="contained"
              color="primary"
              onClick={handleNext}
            >
              Next
            </Button>
          )}
        </Box>
      </Paper>
    </Container>
  );
};

export default PaymentProcessor;
