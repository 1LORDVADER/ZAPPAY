import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Box,
  TextField,
  CircularProgress,
  Alert,
  Stepper,
  Step,
  StepLabel,
  Paper,
  Radio,
  RadioGroup,
  FormControlLabel,
  FormControl,
  FormLabel,
  Divider
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../../contexts/CartContext';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';

const ConsumerCheckout = () => {
  const { cart, calculateTotals, checkout, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [orderNumber, setOrderNumber] = useState(null);
  
  const [paymentMethod, setPaymentMethod] = useState('ach');
  const [dispensary, setDispensary] = useState(null);
  
  const steps = ['Review Order', 'Select Payment Method', 'Confirm Order'];
  
  const { 
    subtotal, 
    exciseTax, 
    localTax, 
    totalTax, 
    commission, 
    total, 
    itemCount 
  } = calculateTotals();
  
  // Redirect if cart is empty
  useEffect(() => {
    if (cart.items.length === 0 && !success) {
      navigate('/cart');
    }
  }, [cart.items.length, navigate, success]);
  
  // Redirect to login if not logged in
  useEffect(() => {
    if (!user) {
      navigate('/login');
    } else if (user.role !== 'consumer') {
      navigate('/');
    }
  }, [user, navigate]);
  
  // Fetch dispensary details
  useEffect(() => {
    const fetchDispensary = async () => {
      if (cart.dispensaryId) {
        try {
          const response = await axios.get(`/dispensaries/${cart.dispensaryId}`);
          setDispensary(response.data.dispensary);
        } catch (err) {
          console.error('Error fetching dispensary:', err);
          setError('Failed to load dispensary details. Please try again.');
        }
      }
    };
    
    fetchDispensary();
  }, [cart.dispensaryId]);
  
  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };
  
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };
  
  const handlePaymentMethodChange = (event) => {
    setPaymentMethod(event.target.value);
  };
  
  const handlePlaceOrder = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const checkoutData = {
        consumer_id: user.id,
        payment_method: paymentMethod
      };
      
      const order = await checkout(checkoutData);
      
      setOrderNumber(order.id);
      setSuccess(true);
      setActiveStep(3);
    } catch (err) {
      console.error('Checkout error:', err);
      setError(err.response?.data?.message || 'Failed to place order. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const handleContinueShopping = () => {
    navigate('/products');
  };
  
  const handleViewOrder = () => {
    navigate(`/orders/${orderNumber}`);
  };
  
  if (loading) {
    return (
      <Container sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress />
      </Container>
    );
  }
  
  return (
    <Container>
      <Typography variant="h4" component="h1" gutterBottom>
        Checkout
      </Typography>
      
      <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      {success ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h5" gutterBottom>
            Thank you for your order!
          </Typography>
          <Typography variant="body1" paragraph>
            Your order number is #{orderNumber}. We have sent you a confirmation email with order details.
          </Typography>
          <Typography variant="body1" paragraph>
            Your order is now being processed by the dispensary. You will receive a notification when it's ready for pickup.
          </Typography>
          <Box sx={{ mt: 4, display: 'flex', justifyContent: 'center', gap: 2 }}>
            <Button 
              variant="outlined" 
              onClick={handleContinueShopping}
            >
              Continue Shopping
            </Button>
            <Button 
              variant="contained" 
              color="primary"
              onClick={handleViewOrder}
            >
              View Order
            </Button>
          </Box>
        </Paper>
      ) : (
        <>
          {activeStep === 0 && (
            <Grid container spacing={4}>
              <Grid item xs={12} md={8}>
                <Paper sx={{ p: 3, mb: 3 }}>
                  <Typography variant="h6" gutterBottom>
                    Order Items
                  </Typography>
                  
                  {cart.items.map((item) => (
                    <Box key={item.id} sx={{ display: 'flex', mb: 2, pb: 2, borderBottom: '1px solid #eee' }}>
                      {item.image && (
                        <Box 
                          component="img" 
                          src={item.image} 
                          alt={item.name}
                          sx={{ width: 60, height: 60, mr: 2, objectFit: 'cover' }}
                        />
                      )}
                      <Box sx={{ flexGrow: 1 }}>
                        <Typography variant="subtitle1">{item.name}</Typography>
                        <Typography variant="body2" color="text.secondary">
                          {item.farmer_name} • {item.strain_type}
                        </Typography>
                        <Typography variant="body2">
                          ${item.price.toFixed(2)} x {item.quantity} = ${(item.price * item.quantity).toFixed(2)}
                        </Typography>
                      </Box>
                    </Box>
                  ))}
                </Paper>
                
                {dispensary && (
                  <Paper sx={{ p: 3 }}>
                    <Typography variant="h6" gutterBottom>
                      Pickup Location
                    </Typography>
                    <Typography variant="subtitle1">
                      {dispensary.business_name}
                    </Typography>
                    <Typography variant="body1">
                      {dispensary.business_address}
                    </Typography>
                    <Typography variant="body1">
                      {dispensary.city}, {dispensary.state} {dispensary.zip_code}
                    </Typography>
                    
                    <Box sx={{ mt: 2 }}>
                      <Typography variant="subtitle2" gutterBottom>
                        Pickup Instructions:
                      </Typography>
                      <Typography variant="body2">
                        {dispensary.pickup_instructions || 'Please bring your ID and order confirmation. You will be notified when your order is ready for pickup.'}
                      </Typography>
                    </Box>
                  </Paper>
                )}
              </Grid>
              
              <Grid item xs={12} md={4}>
                <Card sx={{ mb: 3 }}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Order Summary
                    </Typography>
                    
                    <Box sx={{ my: 2 }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="body1">Subtotal</Typography>
                        <Typography variant="body1">${subtotal.toFixed(2)}</Typography>
                      </Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="body2" color="text.secondary">Excise Tax (15%)</Typography>
                        <Typography variant="body2" color="text.secondary">${exciseTax.toFixed(2)}</Typography>
                      </Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="body2" color="text.secondary">Local Tax (8.5%)</Typography>
                        <Typography variant="body2" color="text.secondary">${localTax.toFixed(2)}</Typography>
                      </Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="body2" color="text.secondary">Platform Fee (5.2%)</Typography>
                        <Typography variant="body2" color="text.secondary">${commission.toFixed(2)}</Typography>
                      </Box>
                    </Box>
                    
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3, pt: 2, borderTop: '1px solid #eee' }}>
                      <Typography variant="h6">Total</Typography>
                      <Typography variant="h6">${total.toFixed(2)}</Typography>
                    </Box>
                  </CardContent>
                </Card>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Button 
                    variant="outlined" 
                    onClick={() => navigate('/cart')}
                  >
                    Back to Cart
                  </Button>
                  <Button 
                    variant="contained" 
                    color="primary"
                    onClick={handleNext}
                  >
                    Continue
                  </Button>
                </Box>
              </Grid>
            </Grid>
          )}
          
          {activeStep === 1 && (
            <Grid container spacing={4}>
              <Grid item xs={12} md={8}>
                <Paper sx={{ p: 3 }}>
                  <Typography variant="h6" gutterBottom>
                    Payment Method
                  </Typography>
                  
                  <FormControl component="fieldset" sx={{ width: '100%' }}>
                    <RadioGroup
                      aria-label="payment-method"
                      name="payment-method"
                      value={paymentMethod}
                      onChange={handlePaymentMethodChange}
                    >
                      <FormControlLabel 
                        value="ach" 
                        control={<Radio />} 
                        label={
                          <Box>
                            <Typography variant="subtitle1">ACH Bank Transfer</Typography>
                            <Typography variant="body2" color="text.secondary">
                              Secure direct bank transfer
                            </Typography>
                          </Box>
                        } 
                        sx={{ mb: 2, p: 1, border: '1px solid #eee', borderRadius: 1 }}
                      />
                      <FormControlLabel 
                        value="cash" 
                        control={<Radio />} 
                        label={
                          <Box>
                            <Typography variant="subtitle1">Cash on Pickup</Typography>
                            <Typography variant="body2" color="text.secondary">
                              Pay with cash when you pick up your order
                            </Typography>
                          </Box>
                        } 
                        sx={{ mb: 2, p: 1, border: '1px solid #eee', borderRadius: 1 }}
                      />
                    </RadioGroup>
                  </FormControl>
                  
                  {paymentMethod === 'ach' && (
                    <Box sx={{ mt: 3 }}>
                      <Typography variant="subtitle2" gutterBottom>
                        ACH Payment Information
                      </Typography>
                      <Typography variant="body2" paragraph>
                        You will be redirected to our secure payment processor to complete your ACH payment after confirming your order.
                      </Typography>
                      <Alert severity="info">
                        For security reasons, your payment information is processed by our secure payment provider and is not stored on our servers.
                      </Alert>
                    </Box>
                  )}
                </Paper>
              </Grid>
              
              <Grid item xs={12} md={4}>
                <Card sx={{ mb: 3 }}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Order Summary
                    </Typography>
                    
                    <Box sx={{ my: 2 }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="body1">Subtotal</Typography>
                        <Typography variant="body1">${subtotal.toFixed(2)}</Typography>
                      </Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="body2" color="text.secondary">Taxes</Typography>
                        <Typography variant="body2" color="text.secondary">${totalTax.toFixed(2)}</Typography>
                      </Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="body2" color="text.secondary">Platform Fee</Typography>
                        <Typography variant="body2" color="text.secondary">${commission.toFixed(2)}</Typography>
                      </Box>
                    </Box>
                    
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3, pt: 2, borderTop: '1px solid #eee' }}>
                      <Typography variant="h6">Total</Typography>
                      <Typography variant="h6">${total.toFixed(2)}</Typography>
                    </Box>
                  </CardContent>
                </Card>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Button 
                    variant="outlined" 
                    onClick={handleBack}
                  >
                    Back
                  </Button>
                  <Button 
                    variant="contained" 
                    color="primary"
                    onClick={handleNext}
                  >
                    Continue
                  </Button>
                </Box>
              </Grid>
            </Grid>
          )}
          
          {activeStep === 2 && (
            <Grid container spacing={4}>
              <Grid item xs={12} md={8}>
                <Paper sx={{ p: 3 }}>
                  <Typography variant="h6" gutterBottom>
                    Order Confirmation
                  </Typography>
                  
                  <Box sx={{ mb: 3 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      Pickup Location:
                    </Typography>
                    {dispensary && (
                      <>
                        <Typography variant="body1">
                          {dispensary.business_name}
                        </Typography>
                        <Typography variant="body2">
                          {dispensary.business_address}, {dispensary.city}, {dispensary.state} {dispensary.zip_code}
                        </Typography>
                      </>
                    )}
                  </Box>
                  
                  <Divider sx={{ my: 2 }} />
                  
                  <Box sx={{ mb: 3 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      Payment Method:
                    </Typography>
                    <Typography variant="body1">
                      {paymentMethod === 'ach' ? 'ACH Bank Transfer' : 'Cash on Pickup'}
                    </Typography>
                  </Box>
                  
                  <Divider sx={{ my: 2 }} />
                  
                  <Box sx={{ mb: 3 }}>
                    <Typography variant="subtitle2" gutterBottom>
                      Items:
                    </Typography>
                    {cart.items.map((item) => (
                      <Box key={item.id} sx={{ display: 'flex', mb: 1 }}>
                        <Typography variant="body2" sx={{ flexGrow: 1 }}>
                          {item.quantity}x {item.name}
                        </Typography>
                        <Typography variant="body2">
                          ${(item.price * item.quantity).toFixed(2)}
                        </Typography>
                      </Box>
                    ))}
                  </Box>
                  
                  <Alert severity="info" sx={{ mt: 3 }}>
                    By placing this order, you confirm that you are 21 years of age or older and will present valid ID when picking up your order.
                  </Alert>
                </Paper>
              </Grid>
              
              <Grid item xs={12} md={4}>
                <Card sx={{ mb: 3 }}>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Order Summary
                    </Typography>
                    
                    <Box sx={{ my: 2 }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="body1">Subtotal</Typography>
                        <Typography variant="body1">${subtotal.toFixed(2)}</Typography>
                      </Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="body2" color="text.secondary">Taxes</Typography>
                        <Typography variant="body2" color="text.secondary">${totalTax.toFixed(2)}</Typography>
                      </Box>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Typography variant="body2" color="text.secondary">Platform Fee</Typography>
                        <Typography variant="body2" color="text.secondary">${commission.toFixed(2)}</Typography>
                      </Box>
                    </Box>
                    
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3, pt: 2, borderTop: '1px solid #eee' }}>
                      <Typography variant="h6">Total</Typography>
                      <Typography variant="h6">${total.toFixed(2)}</Typography>
                    </Box>
                    
                    <Button 
                      variant="contained" 
                      color="primary" 
                      size="large" 
                      fullWidth
                      onClick={handlePlaceOrder}
                    >
                      Place Order
                    </Button>
                  </CardContent>
                </Card>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Button 
                    variant="outlined" 
                    onClick={handleBack}
                  >
                    Back
                  </Button>
                </Box>
              </Grid>
            </Grid>
          )}
        </>
      )}
    </Container>
  );
};

export default ConsumerCheckout;
