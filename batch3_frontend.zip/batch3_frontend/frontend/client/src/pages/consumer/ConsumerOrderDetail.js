import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Box,
  Paper,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  CircularProgress,
  Alert,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';

const ConsumerOrderDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [review, setReview] = useState({
    rating: 5,
    comment: ''
  });
  
  useEffect(() => {
    const fetchOrderDetails = async () => {
      try {
        setLoading(true);
        const response = await axios.get(`/orders/${id}`);
        setOrder(response.data.order);
        setError(null);
      } catch (err) {
        console.error('Error fetching order details:', err);
        setError('Failed to load order details. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchOrderDetails();
  }, [id]);
  
  const handleReviewChange = (e) => {
    const { name, value } = e.target;
    setReview(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleSubmitReview = async () => {
    try {
      await axios.post(`/orders/${id}/review`, review);
      // Refresh order data to show the review
      const response = await axios.get(`/orders/${id}`);
      setOrder(response.data.order);
      // Reset review form
      setReview({
        rating: 5,
        comment: ''
      });
    } catch (err) {
      console.error('Error submitting review:', err);
      setError('Failed to submit review. Please try again.');
    }
  };
  
  if (loading) {
    return (
      <Container sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress />
      </Container>
    );
  }
  
  if (error || !order) {
    return (
      <Container sx={{ py: 4 }}>
        <Alert severity="error">{error || 'Order not found'}</Alert>
        <Button 
          variant="contained" 
          onClick={() => navigate('/orders')}
          sx={{ mt: 2 }}
        >
          Back to Orders
        </Button>
      </Container>
    );
  }
  
  const getStatusColor = (status) => {
    switch (status) {
      case 'pending':
        return 'warning.main';
      case 'processing':
        return 'info.main';
      case 'ready_for_pickup':
        return 'success.main';
      case 'completed':
        return 'success.main';
      case 'cancelled':
        return 'error.main';
      default:
        return 'text.primary';
    }
  };
  
  return (
    <Container>
      <Box sx={{ mb: 4, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h4" component="h1">
          Order #{order.id}
        </Typography>
        <Button 
          variant="outlined" 
          onClick={() => navigate('/orders')}
        >
          Back to Orders
        </Button>
      </Box>
      
      <Grid container spacing={4}>
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3, mb: 4 }}>
            <Typography variant="h6" gutterBottom>
              Order Status
            </Typography>
            <Divider sx={{ mb: 2 }} />
            
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
              <Typography variant="body1" sx={{ mr: 1 }}>
                Current Status:
              </Typography>
              <Typography 
                variant="body1" 
                sx={{ 
                  fontWeight: 'bold', 
                  color: getStatusColor(order.status),
                  textTransform: 'uppercase'
                }}
              >
                {order.status.replace('_', ' ')}
              </Typography>
            </Box>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Order Placed
              </Typography>
              <Typography variant="body1">
                {new Date(order.created_at).toLocaleString()}
              </Typography>
            </Box>
            
            {order.status === 'ready_for_pickup' && (
              <Alert severity="success" sx={{ mb: 3 }}>
                Your order is ready for pickup at the dispensary. Please bring your ID and order confirmation.
              </Alert>
            )}
            
            {order.status === 'pending' && (
              <Alert severity="info" sx={{ mb: 3 }}>
                Your order is being processed by the dispensary. You will receive a notification when it's ready for pickup.
              </Alert>
            )}
            
            {order.status === 'cancelled' && (
              <Alert severity="error" sx={{ mb: 3 }}>
                This order has been cancelled. If you have any questions, please contact customer support.
              </Alert>
            )}
          </Paper>
          
          <Paper sx={{ p: 3, mb: 4 }}>
            <Typography variant="h6" gutterBottom>
              Order Items
            </Typography>
            <Divider sx={{ mb: 2 }} />
            
            <List>
              {order.items.map((item) => (
                <React.Fragment key={item.id}>
                  <ListItem sx={{ px: 0 }}>
                    <Box sx={{ display: 'flex', width: '100%' }}>
                      {item.image && (
                        <Box 
                          component="img" 
                          src={item.image} 
                          alt={item.product_name}
                          sx={{ width: 60, height: 60, mr: 2, objectFit: 'cover' }}
                        />
                      )}
                      <Box sx={{ flexGrow: 1 }}>
                        <Typography variant="subtitle1">{item.product_name}</Typography>
                        <Typography variant="body2" color="text.secondary">
                          {item.farmer_name} • {item.strain_type}
                        </Typography>
                        <Typography variant="body2">
                          ${item.price_per_unit.toFixed(2)} x {item.quantity} = ${item.subtotal.toFixed(2)}
                        </Typography>
                      </Box>
                    </Box>
                  </ListItem>
                  <Divider component="li" />
                </React.Fragment>
              ))}
            </List>
          </Paper>
          
          {order.status === 'completed' && !order.has_review && (
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Leave a Review
              </Typography>
              <Divider sx={{ mb: 2 }} />
              
              <Box component="form" sx={{ mt: 2 }}>
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel id="rating-label">Rating</InputLabel>
                  <Select
                    labelId="rating-label"
                    id="rating"
                    name="rating"
                    value={review.rating}
                    label="Rating"
                    onChange={handleReviewChange}
                  >
                    <MenuItem value={5}>5 - Excellent</MenuItem>
                    <MenuItem value={4}>4 - Very Good</MenuItem>
                    <MenuItem value={3}>3 - Good</MenuItem>
                    <MenuItem value={2}>2 - Fair</MenuItem>
                    <MenuItem value={1}>1 - Poor</MenuItem>
                  </Select>
                </FormControl>
                
                <TextField
                  fullWidth
                  id="comment"
                  name="comment"
                  label="Your Review"
                  multiline
                  rows={4}
                  value={review.comment}
                  onChange={handleReviewChange}
                  sx={{ mb: 2 }}
                />
                
                <Button 
                  variant="contained" 
                  color="primary"
                  onClick={handleSubmitReview}
                >
                  Submit Review
                </Button>
              </Box>
            </Paper>
          )}
          
          {order.has_review && (
            <Paper sx={{ p: 3 }}>
              <Typography variant="h6" gutterBottom>
                Your Review
              </Typography>
              <Divider sx={{ mb: 2 }} />
              
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Typography variant="body1" sx={{ mr: 1 }}>
                  Rating:
                </Typography>
                <Typography variant="body1" fontWeight="bold">
                  {order.review.rating}/5
                </Typography>
              </Box>
              
              <Typography variant="body1">
                {order.review.comment}
              </Typography>
              
              <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                Submitted on {new Date(order.review.created_at).toLocaleDateString()}
              </Typography>
            </Paper>
          )}
        </Grid>
        
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, mb: 4 }}>
            <Typography variant="h6" gutterBottom>
              Order Summary
            </Typography>
            <Divider sx={{ mb: 2 }} />
            
            <Box sx={{ mb: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body1">Subtotal</Typography>
                <Typography variant="body1">${order.subtotal.toFixed(2)}</Typography>
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2" color="text.secondary">Excise Tax (15%)</Typography>
                <Typography variant="body2" color="text.secondary">${order.excise_tax.toFixed(2)}</Typography>
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2" color="text.secondary">Local Tax (8.5%)</Typography>
                <Typography variant="body2" color="text.secondary">${order.local_tax.toFixed(2)}</Typography>
              </Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                <Typography variant="body2" color="text.secondary">Platform Fee (5.2%)</Typography>
                <Typography variant="body2" color="text.secondary">${order.commission.toFixed(2)}</Typography>
              </Box>
            </Box>
            
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3, pt: 2, borderTop: '1px solid #eee' }}>
              <Typography variant="h6">Total</Typography>
              <Typography variant="h6">${order.total.toFixed(2)}</Typography>
            </Box>
            
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Payment Method
              </Typography>
              <Typography variant="body1">
                {order.payment_method === 'ach' ? 'ACH Bank Transfer' : 'Cash on Pickup'}
              </Typography>
            </Box>
            
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Payment Status
              </Typography>
              <Typography 
                variant="body1" 
                sx={{ 
                  color: order.payment_status === 'completed' ? 'success.main' : 
                         order.payment_status === 'pending' ? 'warning.main' : 
                         'error.main'
                }}
              >
                {order.payment_status.charAt(0).toUpperCase() + order.payment_status.slice(1)}
              </Typography>
            </Box>
          </Paper>
          
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Pickup Information
            </Typography>
            <Divider sx={{ mb: 2 }} />
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Dispensary
              </Typography>
              <Typography variant="body1">
                {order.dispensary_name}
              </Typography>
            </Box>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Address
              </Typography>
              <Typography variant="body1">
                {order.dispensary_address}
              </Typography>
              <Typography variant="body1">
                {order.dispensary_city}, {order.dispensary_state} {order.dispensary_zip}
              </Typography>
            </Box>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="body2" color="text.secondary" gutterBottom>
                Pickup Instructions
              </Typography>
              <Typography variant="body1">
                {order.pickup_instructions || 'Please bring your ID and order confirmation. You will be notified when your order is ready for pickup.'}
              </Typography>
            </Box>
            
            {order.status === 'ready_for_pickup' && (
              <Button 
                variant="contained" 
                color="primary"
                fullWidth
              >
                Get Directions
              </Button>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default ConsumerOrderDetail;
