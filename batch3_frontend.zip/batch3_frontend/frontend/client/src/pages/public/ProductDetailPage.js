import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Box,
  TextField,
  CircularProgress,
  Alert,
  Paper,
  Divider,
  List,
  ListItem,
  ListItemText,
  Chip
} from '@mui/material';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { useCart } from '../../contexts/CartContext';
import { useAuth } from '../../contexts/AuthContext';

const ProductDetailPage = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [dispensaries, setDispensaries] = useState([]);
  const [selectedDispensary, setSelectedDispensary] = useState(null);
  const { addItem } = useCart();
  const { user } = useAuth();
  
  useEffect(() => {
    const fetchProduct = async () => {
      try {
        setLoading(true);
        const response = await axios.get(`/products/${id}`);
        setProduct(response.data.product);
        
        // Fetch dispensaries that carry this product
        const dispensariesResponse = await axios.get(`/products/${id}/dispensaries`);
        setDispensaries(dispensariesResponse.data.dispensaries);
        
        if (dispensariesResponse.data.dispensaries.length > 0) {
          setSelectedDispensary(dispensariesResponse.data.dispensaries[0].id);
        }
        
        setError(null);
      } catch (err) {
        console.error('Error fetching product:', err);
        setError('Failed to load product details. Please try again later.');
        setProduct(null);
      } finally {
        setLoading(false);
      }
    };
    
    fetchProduct();
  }, [id]);
  
  const handleQuantityChange = (event) => {
    const value = parseInt(event.target.value);
    if (value > 0 && value <= product.quantity) {
      setQuantity(value);
    }
  };
  
  const handleDispensaryChange = (dispensaryId) => {
    setSelectedDispensary(dispensaryId);
  };
  
  const handleAddToCart = () => {
    if (product && selectedDispensary) {
      addItem(product, quantity, selectedDispensary);
    }
  };
  
  if (loading) {
    return (
      <Container sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
        <CircularProgress />
      </Container>
    );
  }
  
  if (error || !product) {
    return (
      <Container sx={{ py: 4 }}>
        <Alert severity="error">{error || 'Product not found'}</Alert>
      </Container>
    );
  }
  
  return (
    <Container>
      <Grid container spacing={4}>
        <Grid item xs={12} md={6}>
          <Box sx={{ position: 'relative', width: '100%', pb: '100%' }}>
            <img
              src={product.images?.[0] || '/placeholder-product.jpg'}
              alt={product.name}
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                objectFit: 'cover',
                borderRadius: '8px'
              }}
            />
          </Box>
          <Grid container spacing={1} sx={{ mt: 1 }}>
            {product.images?.slice(1).map((image, index) => (
              <Grid item xs={3} key={index}>
                <Box sx={{ position: 'relative', width: '100%', pb: '100%' }}>
                  <img
                    src={image}
                    alt={`${product.name} ${index + 2}`}
                    style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover',
                      borderRadius: '4px'
                    }}
                  />
                </Box>
              </Grid>
            ))}
          </Grid>
        </Grid>
        
        <Grid item xs={12} md={6}>
          <Typography variant="h4" component="h1" gutterBottom>
            {product.name}
          </Typography>
          
          <Typography variant="subtitle1" color="text.secondary" gutterBottom>
            By {product.farmer_name}
          </Typography>
          
          <Box sx={{ display: 'flex', gap: 1, mb: 2 }}>
            <Chip 
              label={product.category} 
              color="primary" 
              variant="outlined" 
            />
            <Chip 
              label={product.strain_type} 
              color="secondary" 
              variant="outlined" 
            />
          </Box>
          
          <Typography variant="h5" color="primary" gutterBottom>
            ${product.price.toFixed(2)} / {product.unit}
          </Typography>
          
          <Box sx={{ my: 3 }}>
            <Typography variant="body1" paragraph>
              {product.description}
            </Typography>
          </Box>
          
          <Paper variant="outlined" sx={{ p: 2, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Product Details
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  THC Content
                </Typography>
                <Typography variant="body1">
                  {product.thc_content}%
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  CBD Content
                </Typography>
                <Typography variant="body1">
                  {product.cbd_content}%
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Category
                </Typography>
                <Typography variant="body1">
                  {product.category}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="body2" color="text.secondary">
                  Strain Type
                </Typography>
                <Typography variant="body1">
                  {product.strain_type}
                </Typography>
              </Grid>
            </Grid>
          </Paper>
          
          {user?.role === 'consumer' && (
            <>
              <Box sx={{ mb: 3 }}>
                <Typography variant="h6" gutterBottom>
                  Available at Dispensaries
                </Typography>
                <List component={Paper} variant="outlined">
                  {dispensaries.length > 0 ? (
                    dispensaries.map((dispensary) => (
                      <React.Fragment key={dispensary.id}>
                        <ListItem 
                          button 
                          selected={selectedDispensary === dispensary.id}
                          onClick={() => handleDispensaryChange(dispensary.id)}
                        >
                          <ListItemText 
                            primary={dispensary.business_name} 
                            secondary={`${dispensary.city}, ${dispensary.state}`} 
                          />
                          <Chip 
                            label={`${dispensary.available_quantity} available`} 
                            size="small" 
                            color={dispensary.available_quantity > 10 ? "success" : "warning"}
                          />
                        </ListItem>
                        <Divider />
                      </React.Fragment>
                    ))
                  ) : (
                    <ListItem>
                      <ListItemText primary="No dispensaries currently carry this product" />
                    </ListItem>
                  )}
                </List>
              </Box>
              
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                <TextField
                  label="Quantity"
                  type="number"
                  value={quantity}
                  onChange={handleQuantityChange}
                  InputProps={{ inputProps: { min: 1, max: product.quantity } }}
                  sx={{ width: '100px', mr: 2 }}
                />
                <Button 
                  variant="contained" 
                  color="primary" 
                  size="large"
                  disabled={!selectedDispensary || product.quantity === 0}
                  onClick={handleAddToCart}
                  sx={{ flexGrow: 1 }}
                >
                  Add to Cart
                </Button>
              </Box>
              
              {product.quantity === 0 && (
                <Alert severity="error">
                  This product is currently out of stock.
                </Alert>
              )}
            </>
          )}
          
          {!user && (
            <Alert severity="info">
              Please log in as a consumer to purchase this product.
            </Alert>
          )}
        </Grid>
      </Grid>
    </Container>
  );
};

export default ProductDetailPage;
