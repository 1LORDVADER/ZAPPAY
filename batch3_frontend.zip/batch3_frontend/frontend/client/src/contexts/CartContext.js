import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const CartContext = createContext();

export function useCart() {
  return useContext(CartContext);
}

export function CartProvider({ children }) {
  const [cart, setCart] = useState(() => {
    // Initialize cart from localStorage if available
    const savedCart = localStorage.getItem('cart');
    return savedCart ? JSON.parse(savedCart) : { items: [], dispensaryId: null };
  });
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  // Add item to cart
  const addItem = (product, quantity, dispensaryId) => {
    setError(null);
    
    // Check if adding from a different dispensary
    if (cart.dispensaryId && cart.dispensaryId !== dispensaryId && cart.items.length > 0) {
      setError('Items in your cart are from a different dispensary. Please clear your cart first.');
      return false;
    }
    
    setCart(prevCart => {
      // Check if item already exists in cart
      const existingItemIndex = prevCart.items.findIndex(item => item.id === product.id);
      
      if (existingItemIndex >= 0) {
        // Update quantity of existing item
        const updatedItems = [...prevCart.items];
        updatedItems[existingItemIndex] = {
          ...updatedItems[existingItemIndex],
          quantity: updatedItems[existingItemIndex].quantity + quantity
        };
        
        return {
          ...prevCart,
          items: updatedItems
        };
      } else {
        // Add new item
        return {
          dispensaryId,
          items: [
            ...prevCart.items,
            {
              id: product.id,
              name: product.name,
              price: product.price,
              quantity,
              image: product.images?.[0] || null,
              farmer_id: product.farmer_id,
              farmer_name: product.farmer_name,
              strain_type: product.strain_type,
              thc_content: product.thc_content,
              cbd_content: product.cbd_content,
              category: product.category,
              unit: product.unit
            }
          ]
        };
      }
    });
    
    return true;
  };

  // Update item quantity
  const updateQuantity = (productId, quantity) => {
    if (quantity <= 0) {
      removeItem(productId);
      return;
    }
    
    setCart(prevCart => {
      const updatedItems = prevCart.items.map(item => 
        item.id === productId ? { ...item, quantity } : item
      );
      
      return {
        ...prevCart,
        items: updatedItems
      };
    });
  };

  // Remove item from cart
  const removeItem = (productId) => {
    setCart(prevCart => {
      const updatedItems = prevCart.items.filter(item => item.id !== productId);
      
      // If cart is empty, reset dispensaryId
      const updatedDispensaryId = updatedItems.length > 0 ? prevCart.dispensaryId : null;
      
      return {
        dispensaryId: updatedDispensaryId,
        items: updatedItems
      };
    });
  };

  // Clear cart
  const clearCart = () => {
    setCart({ items: [], dispensaryId: null });
  };

  // Calculate cart totals
  const calculateTotals = () => {
    const subtotal = cart.items.reduce((total, item) => total + (item.price * item.quantity), 0);
    
    // Calculate taxes (these rates should match backend)
    const exciseTaxRate = 0.15; // 15% excise tax
    const localTaxRate = 0.085; // 8.5% local tax
    
    const exciseTax = subtotal * exciseTaxRate;
    const localTax = subtotal * localTaxRate;
    const totalTax = exciseTax + localTax;
    
    // Calculate commission (5.2% of subtotal + taxes)
    const commissionRate = 0.052;
    const commissionBase = subtotal + totalTax;
    const commission = commissionBase * commissionRate;
    
    // Calculate total
    const total = subtotal + totalTax + commission;
    
    return {
      subtotal: parseFloat(subtotal.toFixed(2)),
      exciseTax: parseFloat(exciseTax.toFixed(2)),
      localTax: parseFloat(localTax.toFixed(2)),
      totalTax: parseFloat(totalTax.toFixed(2)),
      commission: parseFloat(commission.toFixed(2)),
      total: parseFloat(total.toFixed(2)),
      itemCount: cart.items.reduce((count, item) => count + item.quantity, 0)
    };
  };

  // Checkout function
  const checkout = async (checkoutData) => {
    try {
      setLoading(true);
      setError(null);
      
      const totals = calculateTotals();
      
      const orderData = {
        consumer_id: checkoutData.consumer_id,
        dispensary_id: cart.dispensaryId,
        items: cart.items.map(item => ({
          product_id: item.id,
          quantity: item.quantity,
          price_per_unit: item.price,
          subtotal: item.price * item.quantity
        })),
        payment_method: checkoutData.payment_method
      };
      
      const response = await axios.post('/orders', orderData);
      
      // Clear cart after successful checkout
      clearCart();
      
      return response.data.order;
    } catch (err) {
      console.error('Checkout error:', err);
      setError(err.response?.data?.message || 'Checkout failed. Please try again.');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Context value
  const value = {
    cart,
    loading,
    error,
    addItem,
    updateQuantity,
    removeItem,
    clearCart,
    calculateTotals,
    checkout
  };

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
}
