import React from 'react';
import { AppBar, Toolbar, Typography, Button, IconButton, Badge, Box, Container, Menu, MenuItem } from '@mui/material';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import { useAuth } from '../../contexts/AuthContext';
import { useCart } from '../../contexts/CartContext';

const Navbar = () => {
  const { user, logout } = useAuth();
  const { cart, calculateTotals } = useCart();
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = React.useState(null);
  
  const { itemCount } = calculateTotals();
  
  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  
  const handleLogout = () => {
    logout();
    handleClose();
    navigate('/');
  };
  
  const handleProfileClick = () => {
    handleClose();
    
    // Navigate to appropriate dashboard based on user role
    if (user.role === 'consumer') {
      navigate('/profile');
    } else if (user.role === 'farmer') {
      navigate('/farmer/profile');
    } else if (user.role === 'dispensary') {
      navigate('/dispensary/profile');
    } else if (user.role === 'admin') {
      navigate('/admin');
    }
  };
  
  const handleDashboardClick = () => {
    handleClose();
    
    // Navigate to appropriate dashboard based on user role
    if (user.role === 'consumer') {
      navigate('/dashboard');
    } else if (user.role === 'farmer') {
      navigate('/farmer/dashboard');
    } else if (user.role === 'dispensary') {
      navigate('/dispensary/dashboard');
    } else if (user.role === 'admin') {
      navigate('/admin');
    }
  };

  return (
    <AppBar position="static">
      <Container maxWidth="xl">
        <Toolbar disableGutters>
          <Typography
            variant="h6"
            component={RouterLink}
            to="/"
            sx={{
              mr: 2,
              display: { xs: 'none', md: 'flex' },
              fontWeight: 700,
              color: 'inherit',
              textDecoration: 'none',
            }}
          >
            ZAPPAY
          </Typography>

          <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
            <Button
              component={RouterLink}
              to="/products"
              sx={{ my: 2, color: 'white', display: 'block' }}
            >
              Products
            </Button>
            <Button
              component={RouterLink}
              to="/dispensaries"
              sx={{ my: 2, color: 'white', display: 'block' }}
            >
              Dispensaries
            </Button>
            <Button
              component={RouterLink}
              to="/about"
              sx={{ my: 2, color: 'white', display: 'block' }}
            >
              About
            </Button>
          </Box>

          <Box sx={{ flexGrow: 0 }}>
            {user ? (
              <>
                {user.role === 'consumer' && (
                  <IconButton 
                    color="inherit" 
                    component={RouterLink} 
                    to="/cart"
                    sx={{ mr: 1 }}
                  >
                    <Badge badgeContent={itemCount} color="error">
                      <ShoppingCartIcon />
                    </Badge>
                  </IconButton>
                )}
                
                <IconButton
                  size="large"
                  aria-label="account of current user"
                  aria-controls="menu-appbar"
                  aria-haspopup="true"
                  onClick={handleMenu}
                  color="inherit"
                >
                  <AccountCircleIcon />
                </IconButton>
                <Menu
                  id="menu-appbar"
                  anchorEl={anchorEl}
                  anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'right',
                  }}
                  keepMounted
                  transformOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                  }}
                  open={Boolean(anchorEl)}
                  onClose={handleClose}
                >
                  <MenuItem onClick={handleDashboardClick}>Dashboard</MenuItem>
                  <MenuItem onClick={handleProfileClick}>Profile</MenuItem>
                  {user.role === 'consumer' && (
                    <MenuItem onClick={() => { handleClose(); navigate('/orders'); }}>
                      My Orders
                    </MenuItem>
                  )}
                  {user.role === 'farmer' && (
                    <>
                      <MenuItem onClick={() => { handleClose(); navigate('/farmer/products'); }}>
                        My Products
                      </MenuItem>
                      <MenuItem onClick={() => { handleClose(); navigate('/farmer/orders'); }}>
                        Orders
                      </MenuItem>
                      <MenuItem onClick={() => { handleClose(); navigate('/farmer/payouts'); }}>
                        Payouts
                      </MenuItem>
                    </>
                  )}
                  {user.role === 'dispensary' && (
                    <>
                      <MenuItem onClick={() => { handleClose(); navigate('/dispensary/inventory'); }}>
                        Inventory
                      </MenuItem>
                      <MenuItem onClick={() => { handleClose(); navigate('/dispensary/orders'); }}>
                        Orders
                      </MenuItem>
                    </>
                  )}
                  <MenuItem onClick={handleLogout}>Logout</MenuItem>
                </Menu>
              </>
            ) : (
              <>
                <Button 
                  color="inherit" 
                  component={RouterLink} 
                  to="/login"
                  sx={{ mr: 1 }}
                >
                  Login
                </Button>
                <Button 
                  color="inherit" 
                  variant="outlined" 
                  component={RouterLink} 
                  to="/register"
                >
                  Register
                </Button>
              </>
            )}
          </Box>
        </Toolbar>
      </Container>
    </AppBar>
  );
};

export default Navbar;
