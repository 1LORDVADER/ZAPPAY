import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';

// Layout components
import MainLayout from './layouts/MainLayout';
import AdminLayout from './layouts/AdminLayout';

// Public pages
import HomePage from './pages/public/HomePage';
import AboutPage from './pages/public/AboutPage';
import LoginPage from './pages/public/LoginPage';
import RegisterPage from './pages/public/RegisterPage';
import ProductsPage from './pages/public/ProductsPage';
import ProductDetailPage from './pages/public/ProductDetailPage';
import DispensariesPage from './pages/public/DispensariesPage';
import DispensaryDetailPage from './pages/public/DispensaryDetailPage';

// Consumer pages
import ConsumerDashboard from './pages/consumer/Dashboard';
import ConsumerProfile from './pages/consumer/Profile';
import ConsumerOrders from './pages/consumer/Orders';
import ConsumerOrderDetail from './pages/consumer/OrderDetail';
import ConsumerCart from './pages/consumer/Cart';
import ConsumerCheckout from './pages/consumer/Checkout';
import ConsumerAgeVerification from './pages/consumer/AgeVerification';

// Farmer pages
import FarmerDashboard from './pages/farmer/Dashboard';
import FarmerProfile from './pages/farmer/Profile';
import FarmerProducts from './pages/farmer/Products';
import FarmerAddProduct from './pages/farmer/AddProduct';
import FarmerEditProduct from './pages/farmer/EditProduct';
import FarmerOrders from './pages/farmer/Orders';
import FarmerPayouts from './pages/farmer/Payouts';

// Dispensary pages
import DispensaryDashboard from './pages/dispensary/Dashboard';
import DispensaryProfile from './pages/dispensary/Profile';
import DispensaryInventory from './pages/dispensary/Inventory';
import DispensaryOrders from './pages/dispensary/Orders';
import DispensaryOrderDetail from './pages/dispensary/OrderDetail';

// Admin pages
import AdminDashboard from './pages/admin/Dashboard';
import AdminUsers from './pages/admin/Users';
import AdminVerifications from './pages/admin/Verifications';
import AdminOrders from './pages/admin/Orders';
import AdminPayments from './pages/admin/Payments';
import AdminCompliance from './pages/admin/Compliance';
import AdminSettings from './pages/admin/Settings';

// Protected route component
const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, loading } = useAuth();
  
  if (loading) {
    return <div>Loading...</div>;
  }
  
  if (!user) {
    return <Navigate to="/login" />;
  }
  
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/" />;
  }
  
  return children;
};

// Age verification route
const AgeVerifiedRoute = ({ children }) => {
  const { user, loading } = useAuth();
  
  if (loading) {
    return <div>Loading...</div>;
  }
  
  if (!user) {
    return <Navigate to="/login" />;
  }
  
  if (user.role === 'consumer' && !user.is_age_verified) {
    return <Navigate to="/age-verification" />;
  }
  
  return children;
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<MainLayout />}>
            <Route index element={<HomePage />} />
            <Route path="about" element={<AboutPage />} />
            <Route path="login" element={<LoginPage />} />
            <Route path="register" element={<RegisterPage />} />
            <Route path="products" element={<ProductsPage />} />
            <Route path="products/:id" element={<ProductDetailPage />} />
            <Route path="dispensaries" element={<DispensariesPage />} />
            <Route path="dispensaries/:id" element={<DispensaryDetailPage />} />
            
            {/* Consumer routes */}
            <Route path="dashboard" element={
              <ProtectedRoute allowedRoles={['consumer']}>
                <ConsumerDashboard />
              </ProtectedRoute>
            } />
            <Route path="profile" element={
              <ProtectedRoute allowedRoles={['consumer']}>
                <ConsumerProfile />
              </ProtectedRoute>
            } />
            <Route path="orders" element={
              <ProtectedRoute allowedRoles={['consumer']}>
                <ConsumerOrders />
              </ProtectedRoute>
            } />
            <Route path="orders/:id" element={
              <ProtectedRoute allowedRoles={['consumer']}>
                <ConsumerOrderDetail />
              </ProtectedRoute>
            } />
            <Route path="cart" element={
              <ProtectedRoute allowedRoles={['consumer']}>
                <ConsumerCart />
              </ProtectedRoute>
            } />
            <Route path="checkout" element={
              <ProtectedRoute allowedRoles={['consumer']}>
                <AgeVerifiedRoute>
                  <ConsumerCheckout />
                </AgeVerifiedRoute>
              </ProtectedRoute>
            } />
            <Route path="age-verification" element={
              <ProtectedRoute allowedRoles={['consumer']}>
                <ConsumerAgeVerification />
              </ProtectedRoute>
            } />
            
            {/* Farmer routes */}
            <Route path="farmer/dashboard" element={
              <ProtectedRoute allowedRoles={['farmer']}>
                <FarmerDashboard />
              </ProtectedRoute>
            } />
            <Route path="farmer/profile" element={
              <ProtectedRoute allowedRoles={['farmer']}>
                <FarmerProfile />
              </ProtectedRoute>
            } />
            <Route path="farmer/products" element={
              <ProtectedRoute allowedRoles={['farmer']}>
                <FarmerProducts />
              </ProtectedRoute>
            } />
            <Route path="farmer/products/add" element={
              <ProtectedRoute allowedRoles={['farmer']}>
                <FarmerAddProduct />
              </ProtectedRoute>
            } />
            <Route path="farmer/products/edit/:id" element={
              <ProtectedRoute allowedRoles={['farmer']}>
                <FarmerEditProduct />
              </ProtectedRoute>
            } />
            <Route path="farmer/orders" element={
              <ProtectedRoute allowedRoles={['farmer']}>
                <FarmerOrders />
              </ProtectedRoute>
            } />
            <Route path="farmer/payouts" element={
              <ProtectedRoute allowedRoles={['farmer']}>
                <FarmerPayouts />
              </ProtectedRoute>
            } />
            
            {/* Dispensary routes */}
            <Route path="dispensary/dashboard" element={
              <ProtectedRoute allowedRoles={['dispensary']}>
                <DispensaryDashboard />
              </ProtectedRoute>
            } />
            <Route path="dispensary/profile" element={
              <ProtectedRoute allowedRoles={['dispensary']}>
                <DispensaryProfile />
              </ProtectedRoute>
            } />
            <Route path="dispensary/inventory" element={
              <ProtectedRoute allowedRoles={['dispensary']}>
                <DispensaryInventory />
              </ProtectedRoute>
            } />
            <Route path="dispensary/orders" element={
              <ProtectedRoute allowedRoles={['dispensary']}>
                <DispensaryOrders />
              </ProtectedRoute>
            } />
            <Route path="dispensary/orders/:id" element={
              <ProtectedRoute allowedRoles={['dispensary']}>
                <DispensaryOrderDetail />
              </ProtectedRoute>
            } />
          </Route>
          
          {/* Admin routes */}
          <Route path="/admin" element={
            <ProtectedRoute allowedRoles={['admin']}>
              <AdminLayout />
            </ProtectedRoute>
          }>
            <Route index element={<AdminDashboard />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="verifications" element={<AdminVerifications />} />
            <Route path="orders" element={<AdminOrders />} />
            <Route path="payments" element={<AdminPayments />} />
            <Route path="compliance" element={<AdminCompliance />} />
            <Route path="settings" element={<AdminSettings />} />
          </Route>
          
          {/* Catch-all route */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
