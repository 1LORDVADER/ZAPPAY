# ZAPPAY - Pilot Demo Guide

## Introduction
Welcome to the pilot demo of the ZAPPAY platform! This guide will help you navigate through the key features of the platform, focusing on the marketplace functionality, payment processor with 5.2% commission structure, and compliance integration.

## Demo Environment
The pilot demo is set up with sample data to simulate a real-world environment:
- Sample farmers with product listings
- Sample dispensaries with inventory
- Test consumer accounts
- Simulated Metrc compliance integration
- Fully functional payment processor (in test mode)

## Accessing the Demo
1. URL: https://zappay-demo.example.com
2. Login credentials:
   - Consumer: consumer@example.com / demo-password
   - Farmer: farmer@example.com / demo-password
   - Dispensary: dispensary@example.com / demo-password
   - Admin: admin@example.com / demo-password

## Key Features to Explore

### 1. Consumer Experience
1. **Browse Products**
   - Navigate to the Products page
   - Use filters to find products by category, strain type, or farmer
   - View detailed product information

2. **Shopping Cart**
   - Add products to your cart
   - Adjust quantities
   - View cart summary with subtotal, taxes, and platform fee

3. **Checkout Process**
   - Select a dispensary for pickup
   - Choose payment method (ACH or cash)
   - Review order summary with 5.2% platform fee calculation
   - Complete checkout and receive confirmation

4. **Order Management**
   - View order history
   - Check order status
   - View pickup details

### 2. Farmer Experience
1. **Product Management**
   - View existing products
   - Add new products with Metrc package IDs
   - Update product information and inventory

2. **Sales Dashboard**
   - View sales statistics
   - Track revenue and platform fees
   - Monitor product performance

3. **Compliance Features**
   - Verify Metrc package information
   - Sync inventory with Metrc
   - View compliance reports

### 3. Dispensary Experience
1. **Inventory Management**
   - View and manage available products
   - Update inventory quantities
   - Set retail prices

2. **Order Processing**
   - View incoming orders
   - Process orders for pickup
   - Mark orders as completed
   - Handle cash payments

3. **Compliance Reporting**
   - Report sales to Metrc
   - Verify customer age and identity
   - Generate compliance documentation

### 4. Admin Features
1. **User Management**
   - View and manage users
   - Verify business licenses
   - Handle compliance verification

2. **Platform Analytics**
   - View transaction statistics
   - Monitor platform fees collected
   - Track sales by region and product type

3. **Compliance Dashboard**
   - Monitor Metrc integration status
   - View compliance reports
   - Handle compliance issues

## Payment Processor Demo

### ACH Payment Flow
1. Log in as a consumer
2. Add products to cart
3. Proceed to checkout
4. Select "ACH Bank Transfer" as payment method
5. Enter test bank details:
   - Account Name: Test User
   - Account Number: 123456789
   - Routing Number: 123456789
   - Account Type: Checking
6. Complete checkout
7. Observe the 5.2% platform fee calculation

### Cash Payment Flow
1. Log in as a consumer
2. Add products to cart
3. Proceed to checkout
4. Select "Cash on Pickup" as payment method
5. Complete checkout
6. Log in as dispensary
7. View the pending order
8. Mark as "Ready for Pickup"
9. Mark payment as "Received" when simulating customer pickup

### Commission Structure Demonstration
1. Log in as admin
2. Navigate to "Platform Analytics"
3. View the breakdown of transactions:
   - Total transaction amount
   - 5.2% platform fee
   - Amount distributed to farmers
   - Taxes collected

## Compliance Features Demo

### Metrc Integration
1. Log in as farmer or dispensary
2. Navigate to "Compliance" section
3. View Metrc package information
4. Simulate reporting a sale to Metrc

### Age and Identity Verification
1. Log in as consumer
2. Navigate to "Profile" section
3. Complete the age verification process
4. Upload sample ID document

### Business License Verification
1. Log in as farmer or dispensary
2. Navigate to "License Management"
3. View current license status
4. Simulate license renewal process

## Feedback Collection
After exploring the platform, please provide feedback on:
1. User experience and interface design
2. Payment process flow
3. Compliance feature usability
4. Any issues or bugs encountered
5. Suggestions for improvements

## Support During Demo
If you encounter any issues or have questions during the demo, please contact:
- Technical Support: support@example.com
- Demo Coordinator: demo@example.com

Thank you for participating in the ZAPPAY platform pilot demo!
