#!/usr/bin/env node

/**
 * Test script for ZAPPAY Compliance Features
 * 
 * This script tests the Metrc integration and compliance functionality including:
 * - Sale reporting to Metrc
 * - Package verification
 * - Inventory synchronization
 * - Age and identity verification
 * - Business license verification
 * 
 * Run with: node test_compliance_features.js
 */

const MetrcService = require('../payment_processor/MetrcService');

// Test data
const testData = {
  orders: [
    {
      id: 'test-order-1',
      user_id: 'test-user-1',
      total: 100.00,
      items: [
        { 
          id: 'product-1', 
          name: 'Test Product 1', 
          price: 50.00, 
          quantity: 1,
          metrc_package_id: 'METRC-PKG-10001',
          unit: 'Grams',
          category: 'Flower'
        },
        { 
          id: 'product-2', 
          name: 'Test Product 2', 
          price: 50.00, 
          quantity: 1,
          metrc_package_id: 'METRC-PKG-10002',
          unit: 'Grams',
          category: 'Concentrate'
        }
      ]
    }
  ],
  identityVerification: {
    user_id: 'test-user-1',
    date_of_birth: '1990-01-01', // Over 21
    id_type: 'drivers_license',
    id_number: 'DL12345678'
  },
  underageIdentity: {
    user_id: 'test-user-2',
    date_of_birth: '2010-01-01', // Under 21
    id_type: 'drivers_license',
    id_number: 'DL87654321'
  },
  businessLicense: {
    user_id: 'test-farmer-1',
    license_type: 'cultivation',
    license_number: 'CULT12345',
    license_authority: 'California Department of Cannabis Control',
    issue_date: '2023-01-01',
    expiry_date: '2025-01-01' // Valid
  },
  expiredLicense: {
    user_id: 'test-farmer-2',
    license_type: 'cultivation',
    license_number: 'CULT54321',
    license_authority: 'California Department of Cannabis Control',
    issue_date: '2020-01-01',
    expiry_date: '2022-01-01' // Expired
  }
};

// Test results
const testResults = {
  passed: 0,
  failed: 0,
  total: 0
};

// Helper functions
function logSuccess(message) {
  console.log(`✅ PASS: ${message}`);
  testResults.passed++;
  testResults.total++;
}

function logFailure(message, error) {
  console.log(`❌ FAIL: ${message}`);
  if (error) {
    console.log(`   Error: ${error.message}`);
  }
  testResults.failed++;
  testResults.total++;
}

// Main test function
async function runTests() {
  console.log('🧪 Starting Compliance Features Tests');
  console.log('====================================');
  
  try {
    // Test 1: Report sale to Metrc
    console.log('\n📋 Test 1: Report Sale to Metrc');
    try {
      const result = await MetrcService.reportSale(testData.orders[0]);
      
      if (result && result.success) {
        logSuccess('Sale reported to Metrc successfully');
        
        // Verify Metrc receipt ID
        if (result.metrc_receipt_id) {
          logSuccess('Metrc receipt ID generated');
        } else {
          logFailure('No Metrc receipt ID generated');
        }
      } else {
        logFailure('Failed to report sale to Metrc');
      }
    } catch (error) {
      logFailure('Sale reporting threw an exception', error);
    }
    
    // Test 2: Verify package in Metrc
    console.log('\n📋 Test 2: Verify Package in Metrc');
    try {
      const packageId = testData.orders[0].items[0].metrc_package_id;
      const result = await MetrcService.verifyPackage(packageId);
      
      if (result && result.package_id === packageId) {
        logSuccess('Package verified in Metrc successfully');
        
        // Verify package details
        if (result.quantity && result.unit_of_measure) {
          logSuccess('Package details retrieved');
        } else {
          logFailure('Package details incomplete');
        }
      } else {
        logFailure('Failed to verify package in Metrc');
      }
    } catch (error) {
      logFailure('Package verification threw an exception', error);
    }
    
    // Test 3: Get active inventory from Metrc
    console.log('\n📋 Test 3: Get Active Inventory from Metrc');
    try {
      const inventory = await MetrcService.getActiveInventory();
      
      if (inventory && Array.isArray(inventory) && inventory.length > 0) {
        logSuccess('Retrieved active inventory from Metrc successfully');
        
        // Verify inventory items have required fields
        const firstItem = inventory[0];
        if (firstItem.id && firstItem.label && firstItem.quantity) {
          logSuccess('Inventory items have required fields');
        } else {
          logFailure('Inventory items missing required fields');
        }
      } else {
        logFailure('Failed to retrieve active inventory from Metrc');
      }
    } catch (error) {
      logFailure('Get active inventory threw an exception', error);
    }
    
    // Test 4: Sync inventory with Metrc
    console.log('\n📋 Test 4: Sync Inventory with Metrc');
    try {
      const result = await MetrcService.syncInventory();
      
      if (result && result.success) {
        logSuccess('Synced inventory with Metrc successfully');
        
        // Verify sync results
        if (result.total >= 0 && result.updated >= 0 && result.created >= 0) {
          logSuccess('Sync results contain required metrics');
        } else {
          logFailure('Sync results missing required metrics');
        }
      } else {
        logFailure('Failed to sync inventory with Metrc');
      }
    } catch (error) {
      logFailure('Sync inventory threw an exception', error);
    }
    
    // Test 5: Verify age and identity (over 21)
    console.log('\n📋 Test 5: Verify Age and Identity (Over 21)');
    try {
      const result = await MetrcService.verifyAgeAndIdentity(testData.identityVerification);
      
      if (result && result.success) {
        logSuccess('Age and identity verification successful');
        
        // Verify age check
        if (result.is_over_21 === true) {
          logSuccess('Age verification correctly identified user as over 21');
        } else {
          logFailure('Age verification failed to identify user as over 21');
        }
      } else {
        logFailure('Failed to verify age and identity');
      }
    } catch (error) {
      logFailure('Age and identity verification threw an exception', error);
    }
    
    // Test 6: Verify age and identity (under 21)
    console.log('\n📋 Test 6: Verify Age and Identity (Under 21)');
    try {
      const result = await MetrcService.verifyAgeAndIdentity(testData.underageIdentity);
      
      if (result) {
        // Should fail for underage users
        if (result.success === false && result.is_over_21 === false) {
          logSuccess('Age verification correctly rejected underage user');
        } else {
          logFailure('Age verification incorrectly approved underage user');
        }
      } else {
        logFailure('Failed to verify age and identity');
      }
    } catch (error) {
      logFailure('Age and identity verification threw an exception', error);
    }
    
    // Test 7: Verify business license (valid)
    console.log('\n📋 Test 7: Verify Business License (Valid)');
    try {
      const result = await MetrcService.verifyBusinessLicense(testData.businessLicense);
      
      if (result && result.success) {
        logSuccess('Business license verification successful');
        
        // Verify license validity
        if (result.is_valid === true && result.is_expired === false) {
          logSuccess('License verification correctly identified valid license');
        } else {
          logFailure('License verification failed to identify valid license');
        }
      } else {
        logFailure('Failed to verify business license');
      }
    } catch (error) {
      logFailure('Business license verification threw an exception', error);
    }
    
    // Test 8: Verify business license (expired)
    console.log('\n📋 Test 8: Verify Business License (Expired)');
    try {
      const result = await MetrcService.verifyBusinessLicense(testData.expiredLicense);
      
      if (result) {
        // Should fail for expired licenses
        if (result.success === false && result.is_expired === true) {
          logSuccess('License verification correctly rejected expired license');
        } else {
          logFailure('License verification incorrectly approved expired license');
        }
      } else {
        logFailure('Failed to verify business license');
      }
    } catch (error) {
      logFailure('Business license verification threw an exception', error);
    }
    
    // Test 9: Generate compliance report
    console.log('\n📋 Test 9: Generate Compliance Report');
    try {
      const report = await MetrcService.generateComplianceReport();
      
      if (report && report.records) {
        logSuccess('Generated compliance report successfully');
        
        // Verify report structure
        if (report.statistics && report.filters) {
          logSuccess('Compliance report has required sections');
        } else {
          logFailure('Compliance report missing required sections');
        }
      } else {
        logFailure('Failed to generate compliance report');
      }
    } catch (error) {
      logFailure('Generate compliance report threw an exception', error);
    }
    
  } catch (error) {
    console.error('Test suite error:', error);
  }
  
  // Print test summary
  console.log('\n📊 Test Summary');
  console.log('==============');
  console.log(`Total tests: ${testResults.total}`);
  console.log(`Passed: ${testResults.passed}`);
  console.log(`Failed: ${testResults.failed}`);
  console.log(`Success rate: ${Math.round((testResults.passed / testResults.total) * 100)}%`);
}

// Run the tests
runTests().catch(console.error);
